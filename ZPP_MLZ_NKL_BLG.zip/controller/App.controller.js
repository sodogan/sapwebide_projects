sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/syncStyleClass",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, Fragment, Filter, FilterOperator, MessageBox, syncStyleClass, MessageToast) {
	"use strict";

	return BaseController.extend("com.bozankaya.ZGR_MALZEME_NKL_BLG.controller.App", {

		onInit: function() {
			var that = this;
			var oModel = this.getModelAndSetHeaders("ZGR_MALZEME_NKL_BLG_SRV");

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.getView().byId('ListId').setVisible(false);
		},

		getTable: function() {
			return this.byId("ListId");
		},
		onSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Matnr", FilterOperator.Contains, sValue);
			oEvent.getSource().destroyItems();
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilter]);

		},

		onSearchAufnr: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Aufnr", FilterOperator.Contains, sValue);
			oEvent.getSource().destroyItems();
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilter]);
		},

		onPressMatnr: function() {
			debugger;
			var oView = this.getView();
			if (!this._pValueHelpDialog) {
				this._pValueHelpDialog = Fragment.load({
					id: oView.getId(),
					name: "com.bozankaya.ZGR_MALZEME_NKL_BLG.view.MatnrValueHelp",
					controller: this
				}).then(function(oDialogMatnr) {
					oDialogMatnr.setModel(oView.getModel());
					return oDialogMatnr;
				});
			}
			this._pValueHelpDialog.then(function(oDialogMatnr) {
				this._configValueHelpMatnrDialog(oDialogMatnr);
				oDialogMatnr.open();
			}.bind(this));
		},
		onPressAufnr: function() {
			var oView = this.getView();

			if (!this._pValueHelpAufnrDialog) {
				this._pValueHelpAufnrDialog = Fragment.load({
					id: oView.getId(),
					name: "com.bozankaya.ZGR_MALZEME_NKL_BLG.view.AufnrValueHelp",
					controller: this
				}).then(function(oDialogMAufnr) {
					oDialogMAufnr.setModel(oView.getModel());
					return oDialogMAufnr;
				});
			}
			this._pValueHelpAufnrDialog.then(function(oDialogMAufnr) {
				this._configValueHelpAufnrDialog(oDialogMAufnr);
				oDialogMAufnr.open();
			}.bind(this));
		},
		_configValueHelpMatnrDialog: function(oDialog) {
			oDialog.setMultiSelect(true);

			// clear the old search filter
			oDialog.getBinding("items").filter([]);

			// toggle compact style
			syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);
		},
		_configValueHelpAufnrDialog: function(oDialog) {
			oDialog.setMultiSelect(true);

			// clear the old search filter
			oDialog.getBinding("items").filter([]);

			// toggle compact style
			syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);
		},
		onValueHelpAufnrDialogClose: function(oEvent) {
			var aFilter = [];
			var that = this;
			var oModel = this.getModelAndSetHeaders("ZGR_MALZEME_NKL_BLG_SRV");
			var aContexts = oEvent.getParameter("selectedContexts");
			debugger;
			if (!aContexts || !aContexts.length) {
				return;
			}
			aContexts.forEach(function(item) {
				var obj = item.getObject();
				aFilter.push(new Filter("Aufnr", sap.ui.model.FilterOperator.EQ, obj.Aufnr));
			});
			var sPath = "/ListSet";

			if (aFilter.length > 0) {
				this.getView().byId("ListId").setVisible(true);

				oModel.read(sPath, {
					filters: aFilter,
					success: function(oData, oResponse) {
						that._setModel(oData.results, "ListModel");
					},
					error: function(oData, oResponse) {

						var sErrorMessage = JSON.parse(oData.responseText).error.message.value;
						MessageBox.error(sErrorMessage);
					}
				});

			}

		},
		onValueHelpDialogClose: function(oEvent) {

			var aFilter = [];
			var that = this;
			var oModel = this.getModelAndSetHeaders("ZGR_MALZEME_NKL_BLG_SRV");

			var aContexts = oEvent.getParameter("selectedContexts");
			debugger;
			if (!aContexts || !aContexts.length) {
				return;
			}
			aContexts.forEach(function(item) {
				var obj = item.getObject();
				aFilter.push(new Filter("Matnr", sap.ui.model.FilterOperator.EQ, obj.Matnr));
			});
			var sPath = "/ListSet";

			if (aFilter.length > 0) {
				this.getView().byId("ListId").setVisible(true);

				oModel.read(sPath, {
					filters: aFilter,
					success: function(oData, oResponse) {
						that._setModel(oData.results, "ListModel");
					},
					error: function(oData, oResponse) {

						var sErrorMessage = JSON.parse(oData.responseText).error.message.value;
						MessageBox.error(sErrorMessage);
					}
				});

			}
		}

	});

});