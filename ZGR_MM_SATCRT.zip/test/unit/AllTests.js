sap.ui.define([
	"com/grebo/ZGR_MM_SATCRT/test/unit/controller/Login.controller"
], function () {
	"use strict";
});