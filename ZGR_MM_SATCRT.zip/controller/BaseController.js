/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	'sap/m/MessageBox',
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, History, MessageToast, MessageBox, JSONModel, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("com.grebo.ZGR_MM_SATCRT.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},
		parseToFloat: function(pFloat) {
			return pFloat === "" ? 0.0 : parseFloat(pFloat).toFixed(2);
		},

		parseToInt: function(pInt) {
			return pInt === "" ? 0 : parseInt(pInt);
		},
		onMessage: function() {
			// create value help dialog
			if (!this._pMessage) {
				this._pMessage = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.Message",
					this
				);
				this.getView().addDependent(this._pMessage);
			}
			this._pMessage.open();
		},
		onCloseDialog: function() {
			this._pMessage.close();
		},
		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("Login", {}, true);
			}
		},
		onNavBackLaunch: function() {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Login");
		},
		showMessage: function(pMsg, pVals) {
			var sTempMessage = this.getResourceBundle().getText(pMsg, pVals);
			MessageToast.show(sTempMessage, {
				duration: 3000,
				closeOnBrowserNavigation: false,
				width: "25em"
			});
		},
		showSuccessMessage: function(pTitle, pMsg) {
			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText(pTitle);
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(pMsg);
			if (!pMBMessage) {
				pMBMessage = pMsg;
			}
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.SUCCESS,
					actions: [sap.m.MessageBox.Action.OK]
				}
			);
		},

		showErrorMessage: function(pTitle, pMsg) {

			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText(pTitle);
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(pMsg);
			if (!pMBMessage) {
				pMBMessage = pMsg;
			}
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.ERROR,
					actions: [sap.m.MessageBox.Action.OK]
				}
			);
		},

		showConfirmationDialog: function(sConfMsg, fAccptFunction, pEntriy) {
			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(sConfMsg);
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText("warnTitle");
			var that = this;
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: fAccptFunction.bind(that, pEntriy)
				}
			);
		},
		getModelAndSetHeaders: function(pDataSource) {
			var oModel, sServiceUrl;
			if (pDataSource) {
				sServiceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources[pDataSource].uri;
				oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			} else {
				oModel = this.getView().getModel();
			}
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			return oModel;
		},

		getValueAndSetValueState: function(pId) {
			var oInput = sap.ui.getCore().byId(pId);
			var sValue = oInput.getValue();
			if (sValue) {
				oInput.setValueState(sap.ui.core.ValueState.None);
			} else {
				oInput.setValueState(sap.ui.core.ValueState.Error);
			}
			return sValue;
		},

		_setModel: function(oData, sModel) {

			var oDataModel = new JSONModel();
			oDataModel.setData(oData);
			oDataModel.setSizeLimit(999999);
			this.getOwnerComponent().setModel(oDataModel, sModel);

			oDataModel.refresh();
		},
		_copyArray: function(array) {
			var arr2 = [];
			for (var i = 0; i < array.length; i++) {
				arr2.push(array[i]);
			}
			return arr2;
		},
		_errorMessages: function(oError, that) {
			var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
			var aMockMessages = [];

			if (oMessage.length > 0) {

				for (var i = 0; i < oMessage.length; i++) {
					var sMsg = oMessage[i].message;

					var oArray = {
						type: sap.ui.core.MessageType.Error,
						title: sMsg
					};
					aMockMessages.push(oArray);
				}
				that.getOwnerComponent().oMessageDialog.open(that, aMockMessages);

			}
		},
		getUserAuth: function() {
			var oHeader = this.getOwnerComponent().getModel("Header");
			if (oHeader) {
				if (oHeader.oData.Pernr === "") {
					this.urlRewrite();
				}
			} else {
				this.urlRewrite();
			}
		},

		urlRewrite: function() {
			// var oModelURL = this.getOwnerComponent().getModel();
			var oModelURL = this.getOwnerComponent().getModel();
			oModelURL.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			var oFilters = [];

			oFilters.push(new Filter("Appty", FilterOperator.EQ, '00'));
			oModelURL.read("/LoginUrlSet", {
				filters: oFilters,
				success: function(oData, oResponse) {
					if (oData.results.length > 0) {
						var oUrl = oData.results[0].Url;
					} else {
						var oUrl = "https://www.lupe.com.tr/";
					}
					window.open(oUrl, "_self");
				},
				error: function(oData, oResponse) {
					var oUrl = "https://www.lupe.com.tr/";
					window.open(oUrl, "_self");
				}
			});

			// var oModel = this.getModelAndSetHeaders("ZLP_LAUNCHPAD_LOJ_SRV");
			// var sPath = "/LoginUrlSet(LoginUrlSet='00')";
			// oModel.read(sPath, {
			// 	success: function (oData) {
			// 		if (oData.Url !== "") {
			// 			var oUrl = oData.Url;
			// 		} else {
			// 			var oUrl = "https://www.lupe.com.tr/";
			// 		}
			// 		// window.open(oUrl, "_self");
			// 	},
			// 	error: function (oError) {
			// 		var oUrl = "https://www.lupe.com.tr/";
			// 		// window.open(oUrl, "_self");
			// 	}
			// });

		},

	});

});