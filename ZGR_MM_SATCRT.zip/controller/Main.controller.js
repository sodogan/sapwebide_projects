sap.ui.define([
	"com/grebo/ZGR_MM_SATCRT/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/library",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Button",
	"sap/m/List",
	"sap/m/StandardListItem",
	"sap/m/Text",
	"sap/m/DialogType",
	"sap/m/Input",
	"sap/m/UploadCollectionParameter",
	'sap/m/MessageItem',
	'sap/m/MessageView',
	"../model/formatter"
], function(BaseController, JSONModel, MessageToast, Filter, Fragment, FilterOperator, MessageBox, mobileLibrary, Dialog,
	Label, Button, List, StandardListItem, Text, DialogType, Input, UploadCollectionParameter, MessageItem, MessageView, formatter) {
	"use strict";

	return BaseController.extend("com.grebo.ZGR_MM_SATCRT.controller.Main", {

		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.giib.ZLP_GIIB.view.Launch_3_1
		 */

		onInit: function() {

			var oSatyView = new JSONModel({
				tempSatno: ""
			});
			this.getOwnerComponent().setModel(oSatyView, "satyView");

			var data = {
				"List": [{
					"Line": "",
					"Desc": ""
				}]
			};
			var oModelExcelErr = new sap.ui.model.json.JSONModel(data);
			this.getOwnerComponent().setModel(oModelExcelErr, "ItemErr");

			//GUID için 
			// this.getUserAuth();

			this.getRouter().getRoute("Main").attachPatternMatched(this._setInitial, this);

		},
		_handleUploadFiles: function() {
			var oFileUploader = this.byId("idFileUploadAtt");
			oFileUploader.checkFileReadable().then(function() {
				oFileUploader.upload();
			}, function(error) {
				MessageToast.show("The file cannot be read. It may have changed.");
			}).then(function() {
				oFileUploader.clear();
			});
		},
		onChangeDokuman: function(oEvent) {
			var that = this;

			var file = oEvent.getParameter("files")[0];
			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename1 = file.name;
			var filename2 = function makeSortString(s) {
				var translate = {
					"İ": "i",
					"Ş": "S",
					"ş": "s",
					"Ö": "O",
					"ö": "o",
					"Ü": "U",
					"ü": "u",
					"ı": "i",
					"Ç": "C",
					"ç": "c",
					"Ğ": "G",
					"ğ": "g",
					" ": "_"
				};
				var translate_re = /[İŞşÖöÜüıÇçĞğ ]/g;
				return (s.replace(translate_re, function(match) {
					return translate[match];
				}));
			};
			var filename = filename2(filename1);
			var reader = new FileReader();
			var that = this;

			reader.onload = (function(theFile) {
				return function(evt) {
					// var oViewModel = that.getView().getModel();
					// oViewModel.setProperty("/busy", true);

					var oModel = that.getOwnerComponent().getModel("DataDocument");
					var aData = oModel.getData();

					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
					var base64 = evt.target.result.substring(base64Index);
					// *****************************

					var imgdata1 = {
						"Mimetype": BASE64_MARKER,
						"Filename": filename,
						"Content": base64
					};

					var Line = 0;

					for (var i = 0; i < aData.List.length; i++) {
						Line = aData.List[i].Line;
					}

					Line = Line + 1;

					var oNewEntry = new Object();
					oNewEntry.__metadata = oModel.getProperty("/0/__metadata");
					oNewEntry.Line = Line;
					oNewEntry.Filename = filename;
					oNewEntry.Filetype = BASE64_MARKER;
					oNewEntry.Filebasedata = base64;
					aData.List.push(oNewEntry);
					oModel.setData(aData);
					oModel.refresh();
					var imgdata = JSON.stringify(imgdata1);

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

		},
		onDeleteDocument: function(oEvent) {

			var oList = oEvent.getSource(),
				oItem = oEvent.getParameter("listItem"),
				sObject = oItem.getBindingContext("DataDocument").getObject();

			// after deletion put the focus back to the list
			oList.attachEventOnce("updateFinished", oList.focus, oList);

			var oModelDocument = this.getOwnerComponent().getModel("DataDocument");
			var aData = oModelDocument.getData();

			for (var i = 0; i < aData.List.length; i++) {
				if (aData.List[i].Line === sObject.Line) {
					aData.List.splice(i, 1);
				}
			}

			oModelDocument.setData(aData);
			oModelDocument.refresh();

		},
		onChangeModeField1: function() {

			var oSatHeaderModel = this.getOwnerComponent().getModel("oSatHeader");
			var sDataHeader = oSatHeaderModel.getData();

			var sKapsam = this.getView().byId("select2");
			var sKey = sKapsam.getSelectedKey();
			var KapsamTuru = this.getView().byId("KapsamTuruId");
			var Yatirim = this.getView().byId("YatirimId");
			var KapsamKey = this.getView().byId("select3");
			var sYatirimInput = this.getView().byId("Field3Id");
			sYatirimInput.setValue("");
			//Malzeme
			if (sKey === "2") {
				KapsamTuru.setVisible(false);
				Yatirim.setVisible(false);
				KapsamKey.setSelectedKey("0");

			} else if (sKey === "1") {
				KapsamTuru.setVisible(true);
				Yatirim.setVisible(true);
				KapsamKey.setSelectedKey("1");

			} else {
				KapsamTuru.setVisible(true);
				Yatirim.setVisible(true);
				KapsamKey.setSelectedKey("0");

			}
			oSatHeaderModel.setData(sDataHeader);
			oSatHeaderModel.refresh();

		},
		onChangeMode: function() {

			var oSatItemVisModel = this.getOwnerComponent().getModel("SatCrtItemVis");
			var sData = oSatItemVisModel.getData();

			var oSatHeaderModel = this.getOwnerComponent().getModel("oSatHeader");
			var sDataHeader = oSatHeaderModel.getData();

			var sTur = this.getView().byId("select1");
			var sKey = sTur.getSelectedKey();
			var slist = this.getView().byId("idList2");
			var sHesapTayini = this.getView().byId("idSelHesapTayin");
			var sKapsam = this.getView().byId("select2");
			var sKapsamTuru = this.getView().byId("select3");
			var sArgeAlım = this.getView().byId("select4");
			var sFormContainer02 = this.getView().byId("FormContainer02Id");

			var sKostlId = this.getView().byId("ItemKostlId");
			var sPosidId = this.getView().byId("ItemPosId");

			sHesapTayini.setSelectedKey("Z");
			sKapsam.setSelectedKey("0");
			sKapsamTuru.setSelectedKey("0");
			sArgeAlım.setSelectedKey("0");
			sKostlId.setVisible(true);
			sPosidId.setVisible(true);
			sData.MeinsVisible = true;
			sData.MatklVisible = true;
			sData.MatnrVisible = false;
			sData.MaktxVisible = true;
			//Yatırım
			if (sKey === "A") {
				sDataHeader.SatTuru = "A";
				slist.setVisible(false);

				sFormContainer02.setVisible(true);
				sDataHeader.Not1 = "";
				sDataHeader.Not2 = "";
				sDataHeader.Not3 = "";
				sDataHeader.Not4 = "";
				sDataHeader.Not5 = "";
				sDataHeader.Not6 = "";
				sDataHeader.Not7 = "";
				sDataHeader.Not8 = "";
				sDataHeader.Field2 = "";
				sDataHeader.Field3 = "";
				sDataHeader.Field4 = "";

				sDataHeader.Not1Vis = false;
				sDataHeader.Not2Vis = true;
			}
			//Malzeme
			else if (sKey === "B") {
				sDataHeader.SatTuru = "B";
				slist.setVisible(true);
				sFormContainer02.setVisible(false);

				sDataHeader.Not1 = "";
				sDataHeader.Not2 = "";
				sDataHeader.Not3 = "";
				sDataHeader.Not4 = "";
				sDataHeader.Not5 = "";
				sDataHeader.Not6 = "";
				sDataHeader.Not7 = "";
				sDataHeader.Not8 = "";
				sDataHeader.Field1 = "";
				sDataHeader.Field2 = "";
				sDataHeader.Field3 = "";
				sDataHeader.Field4 = "";
				sDataHeader.Not1Vis = true;
				sDataHeader.Not2Vis = false;

			}
			oSatHeaderModel.setData(sDataHeader);
			oSatHeaderModel.refresh();

			oSatItemVisModel.setData(sData);
			oSatItemVisModel.refresh();
			this._setInitialRecords();
		},
		onChangeHesapTayin: function() {
			var oSatItemVisModel = this.getOwnerComponent().getModel("SatCrtItemVis");
			var sData = oSatItemVisModel.getData();

			var oSatHeaderModel = this.getOwnerComponent().getModel("oSatHeader");
			var sDataHeader = oSatHeaderModel.getData();

			var sKey = this.getView().byId("idSelHesapTayin").getSelectedKey();
			var sKostlId = this.getView().byId("ItemKostlId");
			var sPosidId = this.getView().byId("ItemPosId");

			//Malzeme Kodlu
			if (sKey === "K") {
				sDataHeader.HesapTayini = "K";
				sKostlId.setVisible(false);
				sPosidId.setVisible(false);
				sData.MatnrVisible = true;
				sData.MeinsVisible = false;
				sData.MatklVisible = false;
				sData.MaktxVisible = false;
			}
			//Malzeme Kodsuz
			else if (sKey === "Z") {
				sDataHeader.HesapTayini = "Z";
				sKostlId.setVisible(true);
				sPosidId.setVisible(true);
				sData.MatnrVisible = false;
				sData.MeinsVisible = true;
				sData.MatklVisible = true;
				sData.MaktxVisible = true;

			}
			oSatItemVisModel.setData(sData);
			oSatItemVisModel.refresh();
			this._setInitialRecords();
		},

		_addrowUrun: function(results) {
			var oModel = this.getOwnerComponent().getModel("SatCrtItem");
			var aData = oModel.getData();

			// for (var i = 0; i < aData.results.length; i++) {
			// 	if (aData.results[i].Knttp === "") {
			// 		aData.results.splice(i, 1);
			// 		i = i - 1;
			// 		// this.getOwnerComponent().getModel("TableItems").refresh();
			// 	}
			// }

			var oNewEntry = new Object();

			oNewEntry.__metadata = results.__metadata;
			// oNewEntry.Matnr = results.Matnr;
			// oNewEntry.Maktx = results.Maktx;
			// oNewEntry.Matkl = results.Matkl;
			// oNewEntry.Wgbez60 = results.Wgbez60;
			// oNewEntry.Meins = results.Meins;

			oNewEntry.Bnfpo = "";
			oNewEntry.Matnr = results.Matnr;
			oNewEntry.Maktx = results.Maktx;
			oNewEntry.Maktxedit = false;
			oNewEntry.Anln1 = "";
			oNewEntry.Txt50 = "";
			oNewEntry.Txt50edit = false;
			oNewEntry.Menge = "0.000";
			oNewEntry.Meins = results.Meins;
			oNewEntry.Meinsedit = false;
			oNewEntry.Badattxt = "";
			oNewEntry.Badat = "";
			oNewEntry.Werks = 5000;
			oNewEntry.Werksedit = false;
			oNewEntry.Lgort = "";
			oNewEntry.Lgobe = "";
			oNewEntry.Posid = "";
			oNewEntry.Kostl = "";
			oNewEntry.Ltext = "";
			oNewEntry.Matkl = results.Matkl;
			oNewEntry.Wgbez60 = results.Wgbez60;
			oNewEntry.Wgbez60edit = false;

			aData.results.push(oNewEntry);
			oModel.setData(aData);
			oModel.refresh();

		},

		handleValueHelpWaers: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();

			this._sPath = oEvent.getSource().getBindingContext("SatCreateItem").getPath();
			this._oObject = oEvent.getSource().getBindingContext("SatCreateItem").getObject();

			// create value help dialog
			if (!this._valueHelpDialogWaers) {
				this._valueHelpDialogWaers = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogWaers",
					this
				);
				this.getView().addDependent(this._valueHelpDialogWaers);
			}

			// create a filter for the binding
			if (sInputValue) {
				var oFilter = new Filter("Waers", FilterOperator.Contains, sInputValue);
				this._valueHelpDialogWaers.getBinding("items").filter([oFilter]);
			} else {
				this._valueHelpDialogWaers.getBinding("items");
			}

			// open value help dialog filtered by the input value
			this._valueHelpDialogWaers.open(sInputValue);
		},

		_handleValueHelpSearchWaers: function(evt) {

			var sValue = evt.getParameter("value");
			var oFilter = new Filter("Waers", FilterOperator.Contains, sValue);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseWaers: function(evt) {

			var oModel = this.getOwnerComponent().getModel("SatCreateItem");

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());

			}

			oModel.refresh();
		},

		handleValueHelpMeins: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();

			this._sPath = oEvent.getSource().getBindingContext("SatCreateItem").getPath();
			this._oObject = oEvent.getSource().getBindingContext("SatCreateItem").getObject();

			// create value help dialog
			if (!this._valueHelpDialogMeins) {
				this._valueHelpDialogMeins = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogMeins",
					this
				);
				this.getView().addDependent(this._valueHelpDialogMeins);
			}

			// create a filter for the binding
			if (sInputValue) {
				var oFilter = new Filter("Msehi", FilterOperator.EQ, sInputValue);
				this._valueHelpDialogMeins.getBinding("items").filter([oFilter]);
			} else {
				this._valueHelpDialogMeins.getBinding("items");
			}

			// open value help dialog filtered by the input value
			this._valueHelpDialogMeins.open(sInputValue);
		},

		_handleValueHelpSearchMeins: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter("Msehi", FilterOperator.EQ, sValue);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseMeins: function(evt) {

			var oModel = this.getOwnerComponent().getModel("SatCreateItem");

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());

			}

			oModel.refresh();
		},

		handleValueHelpMatnr: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();

			this._sPath = oEvent.getSource().getBindingContext("SatCreateItem").getPath();
			this._oObject = oEvent.getSource().getBindingContext("SatCreateItem").getObject();

			// create value help dialog
			if (!this._valueHelpDialogMatnr) {
				this._valueHelpDialogMatnr = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogMatnr",
					this
				);
				this.getView().addDependent(this._valueHelpDialogMatnr);
			}

			// create a filter for the binding
			this._valueHelpDialogMatnr.getBinding("items").filter([
				new Filter(
					"Matnr",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)
			]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogMatnr.open(sInputValue);
		},

		_handleValueHelpSearchMatnr: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter("Matnr", FilterOperator.Contains, sValue);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseMatnr: function(evt) {

			var oModelItem = this.getOwnerComponent().getModel("SatCreateItem");

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				this._setMatnrDetail(oSelectedItem.getTitle());

			}

			oModelItem.refresh();
		},
		_setMatnrDetail: function(sMatnr) {
			var oModelItem = this.getOwnerComponent().getModel("SatCreateItem");
			var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");;
			var sPath = "/MatnrDetailSet";
			sPath = sPath + "(Matnr='" + sMatnr + "')";
			oModel.read(sPath, {
				success: function(oData) {
					oModelItem.setProperty(this._sPath + "/Matkl", oData.Matkl);
					oModelItem.setProperty(this._sPath + "/Meins", oData.Meins);
					oModelItem.refresh();

				}.bind(this),
				error: function(oError) {
					var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(sErrorMessage);
					oModelItem.refresh();
				}.bind(this)
			});
		},
		onMatnrChange: function(oEvent) {

			this._sPath = oEvent.getSource().getBindingContext("SatCreateItem").getPath();
			this._oObject = oEvent.getSource().getBindingContext("SatCreateItem").getObject();
			var sMatnr = oEvent.getSource().getValue();
			if (sMatnr !== "") {
				this._setMatnrDetail(sMatnr);
			}

		},

		handleValueHelpMatkl: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();

			this._sPath = oEvent.getSource().getBindingContext("SatCreateItem").getPath();
			this._oObject = oEvent.getSource().getBindingContext("SatCreateItem").getObject();

			// create value help dialog
			if (!this._valueHelpDialogMatkl) {
				this._valueHelpDialogMatkl = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogMatkl",
					this
				);
				this.getView().addDependent(this._valueHelpDialogMatkl);
			}

			// create a filter for the binding
			this._valueHelpDialogMatkl.getBinding("items").filter([
				new Filter(
					"Matkl",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)
			]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogMatkl.open(sInputValue);
		},

		_handleValueHelpSearchMatkl: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter("Matkl", FilterOperator.Contains, sValue);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseMatkl: function(evt) {

			var oModel = this.getOwnerComponent().getModel("SatCreateItem");

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());

			}

			oModel.refresh();
		},

		handleValueHelpPosid: function(oEvent) {

			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();

			// create value help dialog
			if (!this._valueHelpDialogPosid) {
				this._valueHelpDialogPosid = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogPosid",
					this
				);
				this.getView().addDependent(this._valueHelpDialogPosid);
			}

			// create a filter for the binding
			this._valueHelpDialogPosid.getBinding("items").filter([
				new Filter(
					"Pspnr",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)
			]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogPosid.open(sInputValue);
		},

		_handleValueHelpSearchPosid: function(evt) {

			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Pspnr",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClosePosid: function(evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());

			}
		},

		handleValueHelpKostl: function(oEvent) {

			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();

			// create value help dialog
			if (!this._valueHelpDialogKostl) {
				this._valueHelpDialogKostl = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogKostl",
					this
				);
				this.getView().addDependent(this._valueHelpDialogKostl);
			}

			// create a filter for the binding
			this._valueHelpDialogKostl.getBinding("items").filter([
				new Filter(
					"Ltext",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)
			]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogKostl.open(sInputValue);
		},

		_handleValueHelpSearchKostl: function(evt) {

			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Ltext",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseKostl: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				// oModel.setProperty(this._sPath + "/Kostl", oSelectedItem.getTitle());
				// oModel.setProperty(this._sPath + "/Ltext", oSelectedItem.getDescription());
			}
		},

		handleValueHelpTalepEden: function(oEvent) {

			var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();

			// create value help dialog
			if (!this._valueHelpDialogTalepEden) {
				this._valueHelpDialogTalepEden = sap.ui.xmlfragment(
					"com.grebo.ZGR_MM_SATCRT.view.DialogTalepEden",
					this
				);
				this.getView().addDependent(this._valueHelpDialogTalepEden);
			}

			// create a filter for the binding
			this._valueHelpDialogTalepEden.getBinding("items").filter([
				new Filter(
					"Dprkd",
					sap.ui.model.FilterOperator.Contains, sInputValue
				)
			]);

			// open value help dialog filtered by the input value
			this._valueHelpDialogTalepEden.open(sInputValue);
		},

		_handleValueHelpSearchTalepEden: function(evt) {

			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Dprkd",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().destroyItems();
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpCloseTalepEden: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				// oModel.setProperty(this._sPath + "/Kostl", oSelectedItem.getTitle());
				// oModel.setProperty(this._sPath + "/Ltext", oSelectedItem.getDescription());
			}
		},

		addRow: function(oArg) {

			var oModel = this.getOwnerComponent().getModel("SatCreateItem");
			var aData = oModel.getData();

			var oNewEntry = new Object();
			oNewEntry.__metadata = oModel.getProperty("/0/__metadata");
			oNewEntry.Bnfpo = "";
			oNewEntry.Matnr = "";
			oNewEntry.Maktx = "";
			oNewEntry.Matkl = "";
			oNewEntry.Menge = "";
			oNewEntry.Meins = "";
			oNewEntry.Preis = "";
			oNewEntry.Gswrt = "";
			oNewEntry.Waers = "";
			oNewEntry.Peinh = "";

			aData.push(oNewEntry);
			oModel.setData(aData);
			oModel.refresh();

		},

		DeleteRow: function(oEvent) {

			var oModel = this.getOwnerComponent().getModel("SatCreateItem");
			var tableDataList = oModel.getData();
			var oTable = this.byId("table1");
			var iIndexs = oTable.getSelectedIndices();
			var k = 0;
			var z = 0;
			var y = 0;
			z = iIndexs.length - 1;
			for (var i = 0; i < iIndexs.length; i++) {

				tableDataList.splice(iIndexs[i], 1);

				k = i + 1;
				y = y + 1;

				if (k <= z) {
					iIndexs[k] = iIndexs[k] - y;
				}
			}
			oModel.setData(tableDataList);
			oModel.refresh();
			oTable.clearSelection();
		},
		onPressKaydet: function() {
			this._dialogBusy.open();

			var oSatItemVisModel = this.getOwnerComponent().getModel("SatCrtItemVis");
			var sData = oSatItemVisModel.getData();

			var oSatHeaderModel = this.getOwnerComponent().getModel("oSatHeader");
			var sDataHeader = oSatHeaderModel.getData();

			var oSatLoginModel = this.getOwnerComponent().getModel("LoginModel");
			var sDataLogin = oSatLoginModel.getData();

			var oItemmodel = this.getView().getModel("SatCreateItem");
			var oItem = oItemmodel.oData;

			var oItemDocumentModel = this.getOwnerComponent().getModel("DataDocument");
			var oItemDocument = oItemDocumentModel.getData();

			var oError = '';

			var oModelErr = this.getOwnerComponent().getModel("ItemErr");
			var aDataErr = oModelErr.getData();
			var oNewEntryErr = new Object();

			for (var i = 0; i < aDataErr.List.length; i++) {
				aDataErr.List.splice(i, 1);
				i = i - 1;
			}

			var s = '';

			oModelErr.setData(aDataErr);
			oModelErr.refresh();

			if (sDataHeader.SatTuru === "A") { //Yatırım
				if (sDataHeader.Not2 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Not giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.Not3 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Kısa Açıklama giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.TeslimatTarihi === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Teslimat Tarihi boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.TalepEden === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Talep Eden boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.MasrafYeri === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Masraf Yeri boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}

				if (sDataHeader.Field1 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Ek bilgileri giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.Field1 === "Evet" && (sDataHeader.Field2 === "" || sDataHeader.Field3 === "")) {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Ek bilgileri giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.Field4 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Ek bilgileri giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
			} else if (sDataHeader.SatTuru === "B") { //Malzeme
				if (sDataHeader.Not1 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Not giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.Not8 === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Kısa Açıklama giriniz.";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.TeslimatTarihi === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Teslimat Tarihi boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.TalepEden === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Talep Eden boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				if (sDataHeader.HesapTayini === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Hesap Tayini boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}

				if (sDataHeader.HesapTayini === "Z" && sDataHeader.MasrafYeri === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Masraf Yeri boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}
				/*if (sDataHeader.HesapTayini === "Z" && sDataHeader.ProjeKodu === "") {
					oError = "X";
					oNewEntryErr.Line = "-";
					oNewEntryErr.Desc = "Proje kodu boş girilemez";
					aDataErr.List.push(oNewEntryErr);
					var oNewEntryErr = new Object();

				}*/

			}
			if (oError !== "X") {
				for (var i = 0; i < oItem.length; i++) {

					if (oItem[i].Matnr !== "" || oItem[i].Maktx !== "") {
						s = i + 1;

						if (oItem[i].Menge === '0.000' || oItem[i].Menge === '') {
							oError = "X";
							oNewEntryErr.Line = s;
							oNewEntryErr.Desc = "Miktar boş girilimez";
							aDataErr.List.push(oNewEntryErr);
							var oNewEntryErr = new Object();
						}
						if (oItem[i].Meins === "") {
							oError = "X";
							oNewEntryErr.Line = s;
							oNewEntryErr.Desc = "Ölçü birimi boş girilemez";
							aDataErr.List.push(oNewEntryErr);
							var oNewEntryErr = new Object();

						}
						if (oItem[i].Waers === "") {
							oError = "X";
							oNewEntryErr.Line = s;
							oNewEntryErr.Desc = "Para birimi boş girilimez";
							aDataErr.List.push(oNewEntryErr);
							var oNewEntryErr = new Object();
						}

					}
				}
			}

			oModelErr.setData(aDataErr);
			oModelErr.refresh();

			if (oError === 'X') {
				this._dialogBusy.close();
				if (!this.fixedSizeDialog) {
					this.fixedSizeDialog = new Dialog({
						title: "Hata Listesi",
						contentWidth: "550px",
						contentHeight: "300px",
						content: new List({
							items: {
								path: "ItemErr>/List",
								template: new StandardListItem({
									title: "Satır {ItemErr>Line}: {ItemErr>Desc}"
								})
							}
						}),
						endButton: new Button({
							text: "Kapat",
							press: function() {
								this._dialogBusy.close();
								this.fixedSizeDialog.close();
							}.bind(this)
						})
					});

					//to get access to the global model
					this.getView().addDependent(this.fixedSizeDialog);
				}

				this.fixedSizeDialog.open();

			} else if (s === '') {
				var that = this;
				var msg = "Talep için uygun hiç bir satır girilmedi. Stok kodu veya duran varlık metni giriniz. ";
				MessageBox.warning(msg, {
					onClose: function(sAction) {
						that._dialogBusy.close();
					}
				});

			} else {

				var oSaveData = {};
				var aSaveData = [];

				for (var t = 0; t < oItem.length; t++) {
					oSaveData = {};
					oSaveData.Bnfpo = oItem[t].Bnfpo;
					oSaveData.Matnr = oItem[t].Matnr;
					oSaveData.Maktx = oItem[t].Maktx;
					oSaveData.Matkl = oItem[t].Matkl;
					oSaveData.Menge = oItem[t].Menge;
					oSaveData.Meins = oItem[t].Meins;
					oSaveData.Preis = oItem[t].Preis;
					oSaveData.Gswrt = oItem[t].Gswrt;
					oSaveData.Waers = oItem[t].Waers;
					oSaveData.Peinh = oItem[t].Peinh;
					oSaveData.Loekz = oItem[t].Loekz;
					aSaveData.push(oSaveData);
				}

				var aArray = {
					results: aSaveData
				};

				var jsonDataDocument = JSON.stringify(oItemDocument);
				var encodedStringDocument = btoa(unescape(encodeURIComponent(jsonDataDocument)));

				var jsonData = JSON.stringify(aArray);
				var encodedString = btoa(unescape(encodeURIComponent(jsonData)));

				this.oCreateArray = {};
				this.oCreateArray.Documents = encodedStringDocument;
				this.oCreateArray.Items = encodedString;
				this.oCreateArray.Banfntemp = " ";
				this.oCreateArray.Pernr = sDataLogin.pernr;
				this.oCreateArray.SatTuru = sDataHeader.SatTuru;
				this.oCreateArray.TeslimatTarihi = sDataHeader.TeslimatTarihi;
				this.oCreateArray.TalepEden = sDataHeader.TalepEden;
				this.oCreateArray.MasrafYeri = sDataHeader.MasrafYeri;
				this.oCreateArray.HesapTayini = sDataHeader.HesapTayini;
				this.oCreateArray.ProjeKodu = sDataHeader.ProjeKodu;
				this.oCreateArray.Not1 = sDataHeader.Not1;
				this.oCreateArray.Not2 = sDataHeader.Not2;
				this.oCreateArray.Not3 = sDataHeader.Not3;
				this.oCreateArray.Not4 = sDataHeader.Not4;
				this.oCreateArray.Not5 = sDataHeader.Not5;
				this.oCreateArray.Not6 = sDataHeader.Not6;
				this.oCreateArray.Not7 = sDataHeader.Not7;
				this.oCreateArray.Not8 = sDataHeader.Not8;
				this.oCreateArray.Field1 = sDataHeader.Field1;
				this.oCreateArray.Field2 = sDataHeader.Field2;
				this.oCreateArray.Field3 = sDataHeader.Field3;
				this.oCreateArray.Field4 = sDataHeader.Field4;

				oItemmodel.refresh();
				this._saveData(this.oCreateArray);

			}

		},

		_saveData: function(pData) {

			var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");
	
			var sPath = "/SATCreateAllSet";

			oModel.create(sPath, pData, {
				success: function(oData, oResponse) {
					var that = this;
					this._dialogBusy.close();
					var sCompleteMessage = oResponse.headers["sap-message"];
					var oMessage = JSON.parse(sCompleteMessage);
					var aSuccMessage = oMessage.message.split("++");
					var msg = "";
					for (var k = 0; k < aSuccMessage.length; k++) {
						msg = msg + aSuccMessage[k] + "\n";
					}

					MessageBox.success(msg, {
						onClose: function(sAction) {
							that._setInitial();
						}
					});

				}.bind(this),
				error: function(oError, oResponse) {
					this._dialogBusy.close();
					var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
					var aMessages = [];
					if (oMessage.length > 0) {
						for (var i = 0; i < oMessage.length; i++) {
							var sMsg = oMessage[i].message;
							var sType = oMessage[i].severity;
							sType = formatter.convertToLowerCase(sType);
							sType = sType === "Info" ? "Information" : sType;
							sType = sType === "" ? "Success" : sType;

							var oArray = {
								type: sType,
								title: sMsg
									// additionalText :
									// description : 
							};
							aMessages.push(oArray);
						}
						var MessageModel = this.getOwnerComponent().getModel("message");

						MessageModel.setData(aMessages);
						this.onMessage();

					} else {
						this.showMessage("noDataMsg");
					}

				}.bind(this)
			});

		},

		onPressStok: function(oEvent) {

			var oObject = oEvent.getSource().getBindingContext("SatCrtItem").getObject();
			var oFilter1 = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, oObject.Matnr);
			// if (!this.oFixedSizeDialog) {
			this.oFixedSizeDialog = new Dialog({
				title: "Malzeme Stok Durumu",
				contentWidth: "550px",
				contentHeight: "300px",
				content: new List({
					items: {
						path: "/SATCrtStokSet",
						template: new StandardListItem({
							title: "{Lgort}-{Lgobe}",
							description: "{Labst} {Meins}"
						}),
						filters: [oFilter1]
					}
				}),
				endButton: new Button({
					text: "Kapat",
					press: function() {
						this.oFixedSizeDialog.close();
					}.bind(this)
				})
			});

			//to get access to the controller's model
			this.getView().addDependent(this.oFixedSizeDialog);
			// }

			this.oFixedSizeDialog.open();

			// var sInputValue = oEvent.getSource().getValue();
			// this.inputId = oEvent.getSource().getId();
			// this._sPath = oEvent.getSource().getBindingContext("SatCrtItem").getPath();
			// this._oObject = oEvent.getSource().getBindingContext("SatCrtItem").getObject();
			// create value help dialog
			// if (!this._valueHelpDialogStok) {
			// 	this._valueHelpDialogStok = sap.ui.xmlfragment(
			// 		"com.giib.ZLP_LOJ_APP.view.L_3_1_DialogStok",
			// 		this
			// 	);
			// 	this.getView().addDependent(this._valueHelpDialogStok);
			// }

			// // create a filter for the binding
			// this._valueHelpDialogStok.getBinding("items").filter([
			// 	new Filter(
			// 		"Matnr",
			// 		sap.ui.model.FilterOperator.Contains, oObject.Matnr
			// 	)
			// ]);

			// // open value help dialog filtered by the input value
			// this._valueHelpDialogStok.open(oObject.Matnr);

		},
		onSelectionChange: function(oEvent) {
			var aList = this._getSelectedItems();

			/*var oView = this.getOwnerComponent().getModel("satyView");

			if (aList.length !== 0) {
				oView.setProperty("/enable", true);
			} else {
				oView.setProperty("/enable", false);
			}
			oView.refresh();*/

		},
		_getSelectedItems: function() {
			var aSelIndices = this.getView().byId("table1").getSelectedIndices();
			var aItem = this.getView().getModel("SatCreateItem").getData();
			var aList = [];

			for (var i = 0; i < aSelIndices.length; i++) {
				aList.push(aItem[aSelIndices[i]]);
			}

			return aList;
		},
		_checkListe: function(aList) {
			var aVisComp = this.getOwnerComponent().getModel("SatCrtItemVis").getData();
			for (var i = 0; i < aList.length; i++) {
				if ((aVisComp.Anln1vis === true && aList[i].Anln1 === "") ||
					(aVisComp.Matnrvis === true && aList[i].Matnr === "") ||
					(aVisComp.Lgortvis === true && aList[i].Lgort === "") ||
					(aVisComp.Posidvis === true && aList[i].Posid === "") ||
					(aVisComp.Kostlvis === true && aList[i].Kostl === "") ||
					(aVisComp.Ltextvis === true && aList[i].Ltext === "") ||
					(aVisComp.Matklvis === true && aList[i].Matkl === "") ||
					(aVisComp.Ltextvis === true && aList[i].Ltext === "") ||
					(aList[i].Badattxt === "") ||
					parseFloat(aList[i].Menge) === 0) {
					return true;
				}
			}
			return false;
		},
		_setInitial: function() {
			var dialogBusy = new sap.m.BusyDialog();
			dialogBusy.setText("İşlem sürüyor, lütfen bekleyiniz..");
			this._dialogBusy = dialogBusy;
			this._dialogBusy.open();

			var dataDocument = {
				"List": []
			};

			var oModelDocument = new sap.ui.model.json.JSONModel(dataDocument);
			this.getOwnerComponent().setModel(oModelDocument, "DataDocument");

			var oSatHeaderJson = new JSONModel({
				SatTuru: "",
				TeslimatTarihi: "",
				TalepEden: "",
				MasrafYeri: "",
				HesapTayini: "",
				ProjeKodu: "",
				Not1: "", //Notlar				
				Not2: "", //Yatırım kısa açıklaması
				Not3: "", //Notlar ve ek harcamalar
				Not4: "", //Gerekçesi
				Not5: "", //Yapılmaması durumunda riskler
				Not6: "", //Yatırımın alanları
				Not7: "", //Teknik Özellikler
				Field1: "", //Yatırım teşvik kapsamında mı ?
				Field2: "", //Kapsam Türü
				Field3: "", //Yatırım teşvik No ve Açk.
				Field4: "", //Arge Makine Techizat Alımı mı?
				Not1Vis: true, //Notlar
				Not2Vis: true, //Yatırım kısa açıklaması
				Not3Vis: true, //Notlar ve ek harcamalar
				Not4Vis: true, //Gerekçesi
				Not5Vis: true, //Yapılmaması durumunda riskler
				Not6Vis: true, //Yatırımın alanları
				Not7Vis: true //Teknik Özellikler

			});
			this.getOwnerComponent().setModel(oSatHeaderJson, "oSatHeader");

			var oSatCrtItemVis = new JSONModel({
				BnfpoVisible: false,
				MatnrVisible: true,
				MaktxVisible: true,
				MatklVisible: true,
				MengeVisible: true,
				MeinsVisible: true,
				PreisVisible: true,
				GswrtVisible: true,
				WaersVisible: true,
				PeinhVisible: true
			});
			this.getOwnerComponent().setModel(oSatCrtItemVis, "SatCrtItemVis");

			this._setInitialRecords();
			this.onChangeMode();
			this.onChangeHesapTayin();

			// this.setTempSatno();
			this._handleUploadFiles();
			// this._getDocument(this.getView().getModel("satyView").getProperty("/tempSatno"));

		},
		_setInitialRecords: function() {
			var oModelSatCrtItem = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");;

			oModelSatCrtItem.read("/SatCreateSet", {
				success: function(oData, oResponse) {
					this._dialogBusy.close();
					this._setModel(oData.results, "SatCreateItem");

				}.bind(this),
				error: function(oData, oResponse) {
					this._dialogBusy.close();
					var sErrorMessage = JSON.parse(oData.responseText).error.message.value;
					MessageBox.error(sErrorMessage);

				}
			});

		},

		// _getDocument: function(sBanfn) {
		// 	var sCatid = "BO";
		// 	var sTypeid = "ZLPFIO";
		// 	var aFilter = [];
		// 	aFilter.push(new Filter("Typeid", FilterOperator.EQ, sTypeid));
		// 	aFilter.push(new Filter("Catid", FilterOperator.EQ, sCatid));
		// 	aFilter.push(new Filter("Instid", FilterOperator.EQ, sBanfn));

		// 	this.getView().byId("uploadCollection").getBinding("items").filter(aFilter);
		// },

		setSelafnam: function() {
			var oHeader = this.getOwnerComponent().getModel("Header").getData();
			var aFilter = [];
			aFilter.push(new Filter("Pernr", FilterOperator.EQ, oHeader.pernr));
			// oAfnamList.getBinding("items").filter(aFilter);
			var that = this;
			var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");;
			oModel.read("/SATCrtDepartmanSet", {
				filters: aFilter,
				success: function(oData) {
					var sSelafnam = oData.results[0].Selafnam;

					var oView = that.getView().getModel("satyView");
					oView.setProperty("/Selafnam", sSelafnam);
				},
				error: function() {}
			});
		},
		// setTempSatno: function() {
		// 	var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");;
		// 	var sApptype = "03";
		// 	var sPath = "/TempNumberSet(Apptype='" + sApptype + "')";
		// 	oModel.read(sPath, {
		// 		success: function(oData) {
		// 			var sTempSatno = oData.Banfn;
		// 			var oView = this.getView().getModel("satyView");
		// 			oView.setProperty("/tempSatno", sTempSatno);
		// 		}.bind(this),
		// 		error: function() {
		// 			// dosya eklemesini engelle
		// 		}
		// 	});

		// },

		// onFilenameLengthExceed: function() {
		// 	var pMessage = this.getView().getModel("i18n").getResourceBundle().getText("ucCheckFileName");
		// 	MessageBox.error(pMessage, {
		// 		onClose: function(sAction) {}
		// 	});
		// },

		// onFileSizeExceed: function() {
		// 	var pMessage = this.getView().getModel("i18n").getResourceBundle().getText("ucCheckFileSize");
		// 	MessageBox.error(pMessage, {
		// 		onClose: function(sAction) {}
		// 	});

		// },

		// onUploadTerminated: function() {
		// 	var pMessage = this.getView().getModel("i18n").getResourceBundle().getText("ucFileUploadFailed");
		// 	MessageBox.error(pMessage, {
		// 		onClose: function(sAction) {}
		// 	});

		// },

		// onBeforeUploadStarts: function(oEvent) {
		// 	var sFileName = formatter.replaceTRCharacters(oEvent.getParameter("fileName"));
		// 	var oCustomerHeaderSlug = new UploadCollectionParameter({
		// 		name: "slug",
		// 		value: sFileName
		// 	});
		// 	oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

		// 	var sTypeid = "ZLPFIO";
		// 	var oCustomerHeaderType = new UploadCollectionParameter({
		// 		name: "typeid",
		// 		value: sTypeid
		// 	});
		// 	oEvent.getParameters().addHeaderParameter(oCustomerHeaderType);

		// 	var sCatid = "BO";
		// 	var oCustomerHeaderCatid = new UploadCollectionParameter({
		// 		name: "catid",
		// 		value: sCatid
		// 	});
		// 	oEvent.getParameters().addHeaderParameter(oCustomerHeaderCatid);

		// 	var sTmpBanfn = this.getView().getModel("satyView").getProperty("/tempSatno");
		// 	var oCustomerHeaderInstid = new UploadCollectionParameter({
		// 		name: "instid",
		// 		value: sTmpBanfn
		// 	});
		// 	oEvent.getParameters().addHeaderParameter(oCustomerHeaderInstid);
		// },

		// onUploadChange: function(oEvent) {
		// 	var sServiceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["ZGR_MM_001_FIORI_SRV_01"].uri;
		// 	sServiceUrl += "DocumentSet";

		// 	var oUploadCollection = oEvent.getSource();
		// 	oUploadCollection.setUploadUrl(sServiceUrl);

		// 	// var oModel = this.getView().getModel();
		// 	var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");;
		// 	oModel.refreshSecurityToken();
		// 	var oHeaders = oModel.oHeaders;
		// 	var csrfToken = oHeaders['x-csrf-token'];

		// 	var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
		// 		name: "x-csrf-token",
		// 		value: csrfToken
		// 	});
		// 	oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

		// 	/*var oRequsetedWithX = new sap.m.UploadCollectionParameter({
		// 		name: "X-Requested-With",
		// 		value: "X"
		// 	});
		// 	oUploadCollection.addHeaderParameter(oRequsetedWithX);*/
		// },

		// onUploadComplete: function(oEvent) {
		// 	var sFileName = oEvent.getParameter("files")[0].fileName;
		// 	var sStatus = oEvent.getParameter("files")[0].status;

		// 	var sTypeid = "ZLPFIO";
		// 	var sCatid = "BO";
		// 	var sTmpBanfn = this.getView().getModel("satyView").getProperty("/tempSatno");

		// 	if (sStatus === 201) {

		// 		MessageBox.success(sFileName, {
		// 			onClose: function(sAction) {

		// 			}
		// 		});
		// 		// this.showSuccessMessage("ucFileUploadSucs", [sFileName]);
		// 		var oUploadCollection = oEvent.getSource();
		// 		var oTemplate = oUploadCollection.getBindingInfo("items").template;
		// 		oUploadCollection.unbindAggregation("items");

		// 		var aFilter = [];
		// 		aFilter.push(new Filter("Typeid", FilterOperator.EQ, sTypeid));
		// 		aFilter.push(new Filter("Catid", FilterOperator.EQ, sCatid));
		// 		aFilter.push(new Filter("Instid", FilterOperator.EQ, sTmpBanfn));
		// 		oUploadCollection.bindItems({
		// 			path: "/DocumentSet",
		// 			template: oTemplate,
		// 			filters: aFilter,
		// 			events: {
		// 				dataRequested: function() {},
		// 				dataReceived: function() {
		// 					this._setNumberOfAttachmentsText(oUploadCollection.getItems().length);
		// 				}.bind(this)
		// 			}
		// 		});
		// 	} else {
		// 		this.showErrorMessage("ucFileUploadErr", [sFileName]);
		// 	}
		// },

		// onFileDeleted: function(oEvent) {
		// 	var that = this;
		// 	var oItem = oEvent.getParameters().item;
		// 	var oObject = oItem.getBindingContext().getObject();

		// 	var sPath = "/DocumentSet(Instid='" + oObject.Instid + "',Attaid='" + oObject.Attaid + "',Typeid='" + oObject.Typeid + "',Catid='" +
		// 		oObject.Catid + "')";
		// 	this.getView().getModel().remove(sPath, {
		// 		success: function() {},
		// 		error: function(oError) {
		// 			var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
		// 			that.showErrorMessage("loginErrorTitle", sErrorMessage);
		// 		}
		// 	});
		// },

		onDataReceivedUC: function(oData) {
			var iTotalItems = oData.getParameter("data").results.length;
			this._setNumberOfAttachmentsText(iTotalItems);
		},

		_setNumberOfAttachmentsText: function(iTotalItems) {
			var oUploadCollection = this.getView().byId("uploadCollection");
			var sTitle = this.getResourceBundle().getText("ucAttachTitle", [iTotalItems]);
			oUploadCollection.setNumberOfAttachmentsText(sTitle);
		}

	});

});