sap.ui.define([], function() {
	"use strict";

	return {
		
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		convertToEdmTime: function(dTime) {
			var oTimeFormat = sap.ui.core.format.DateFormat
				.getTimeInstance({
					pattern: dTime
				});
			var aTempTimeArray = oTimeFormat.format(new Date(dTime)).split(":");
			if (aTempTimeArray.length === 3) {
				dTime = aTempTimeArray[0] + aTempTimeArray[1] + aTempTimeArray[2];
			} else {
				dTime = null;
			}
			return dTime;
		},
		replaceTRCharacters: function(sText) {
			var iMaxLength = 50;

			sText = sText.replaceAll("ü", "u");
			sText = sText.replaceAll("ı", "i");
			sText = sText.replaceAll("ö", "o");
			sText = sText.replaceAll("ü", "u");
			sText = sText.replaceAll("ş", "s");
			sText = sText.replaceAll("ğ", "g");
			sText = sText.replaceAll("ç", "c");
			sText = sText.replaceAll("Ü", "U");
			sText = sText.replaceAll("İ", "I");
			sText = sText.replaceAll("Ö", "O");
			sText = sText.replaceAll("Ü", "U");
			sText = sText.replaceAll("Ş", "S");
			sText = sText.replaceAll("Ğ", "G");
			sText = sText.replaceAll("Ç", "C");

			if (sText.length > iMaxLength) {
				sText = sText.substring(0, iMaxLength);
			}
			return sText;
		},
		currencyMethod: function(val) {
			var amount = parseFloat(val);
			var finalResult = amount.toLocaleString('TRY', {
				style: 'currency',
				currency: 'USD'
			});
			return finalResult.replace("$", '');
		},
		convertCurr: function(sValue) {
			var oCurrency = new sap.ui.model.type.Currency({
				showMeasure: false
			});
			var result = oCurrency.formatValue([sValue, 'TRY'], "string");
			return result;
		},
		convertDurumToState: function(pDurum) {

			if (pDurum === "4") {
				return sap.ui.core.ValueState.Error;
			} else if (pDurum === "2") {
				return sap.ui.core.ValueState.Warning;
			} else if (pDurum === "3") {
				return sap.ui.core.ValueState.Error;
			} else if (pDurum === "1") {
				return sap.ui.core.ValueState.Success;
			} else {
				return sap.ui.core.ValueState.None;
			}

		},

		convertDurumToIcon: function(pDurum) {

			if (pDurum === "1") {
				return 'sap-icon://alert';
			} else if (pDurum === "2") {
				return 'sap-icon://alert';
			} else if (pDurum === "3") {
				return 'sap-icon://alert';
			} else if (pDurum === "4") {
				return 'sap-icon://alert';
			} else {
				return 'sap-icon://alert';
			}

		},
		formatNumber: function(sValue) {
			return +sValue;
		},
		formatEDMTime: function(time) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm:ss"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var timeStr = timeFormat.format(new Date(time.ms + TZOffsetMs));
			return timeStr;
		},

		convertToLowerCase: function(pValue) {
			if (pValue) {
				pValue = pValue.toLowerCase();
				var firstLetter = pValue.substring(0, 1).toUpperCase();
				pValue = pValue.slice(1);
				return firstLetter + pValue;
			}
		},

		convertOncelikToState: function(pOncelik) {

			if (pOncelik === "ACIL" || pOncelik === "ACİL" || pOncelik === "acil" || pOncelik === "Acil" || pOncelik === "acıl") {
				return sap.ui.core.ValueState.Error;
			} else if (pOncelik === "YUKSEK" || pOncelik === "YÜKSEK" || pOncelik === "yüksek" || pOncelik === "Yüksek" || pOncelik === "yuksek") {
				return sap.ui.core.ValueState.Warning;
			} else if (pOncelik === "ORTA" || pOncelik === "orta" || pOncelik === "Orta") {
				return sap.ui.core.ValueState.None;
			} else if (pOncelik === "DÜŞÜK" || pOncelik === "DUŞUK" || pOncelik === "DÜSÜK" || pOncelik === "DUSUK" || pOncelik === "dusuk" ||
				pOncelik === "düsük" || pOncelik === "düşük" || pOncelik === "Düşük" || pOncelik === "Düsük") {
				return sap.ui.core.ValueState.Success;
			} else {
				return sap.ui.core.ValueState.Error;
			}

		},

		convertOncelikToIcon: function(pOncelik) {

			if (pOncelik === "ACIL" || pOncelik === "ACİL" || pOncelik === "acil" || pOncelik === "Acil" || pOncelik === "acıl") {
				return 'sap-icon://status-error';
			} else if (pOncelik === "YUKSEK" || pOncelik === "YÜKSEK" || pOncelik === "yüksek" || pOncelik === "Yüksek" || pOncelik === "yuksek") {
				return 'sap-icon://status-critical';
			} else if (pOncelik === "ORTA" || pOncelik === "orta" || pOncelik === "Orta") {
				return 'sap-icon://status-inactive';
			} else if (pOncelik === "DÜŞÜK" || pOncelik === "DUŞUK" || pOncelik === "DÜSÜK" || pOncelik === "DUSUK" || pOncelik === "dusuk" ||
				pOncelik === "düsük" || pOncelik === "düşük" || pOncelik === "Düşük" || pOncelik === "Düsük") {
				return 'sap-icon://status-positive';
			} else {
				return 'sap-icon://bell';
			}

		},

		determineEditBtnEnabled: function(pDurum) {
			return pDurum === "Tamamlandı" ? false : true;
		},

		convAciliyetToState: function(bAciliyet) {
			return bAciliyet ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.Success;
		},
		yetkiVarmi: function(bYetki) {
			if (!bYetki) {
				return sap.m.LoadState.Disabled;
			}
		}

	};

});