/*global location */
sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/bozankaya/model/formatter",
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/FileSizeFormat"
], function(BaseController, JSONModel, formatter, MessageToast, UploadCollectionParameter, FileSizeFormat) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");

			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("masterSet", {
					Ticketno: sObjectId

				});
				this._bindView("/" + sObjectPath);
				 
			}.bind(this));
  
         
         var list,
            binding,
            filter;
            list = this.getView().byId("idList");
            filter = new sap.ui.model.Filter("Ticketno",sap.ui.model.FilterOperator.EQ , sObjectId);
            binding = list.getBinding("items");
            binding.filter(filter,"Application");
            binding.refresh(true);
            
   
             this._bindDesTable(sObjectId);
  
		},
		
		handleIconTabBarSelect: function(oEvent) {
           var list,
            binding,
            filter;
			var sKey = oEvent.getParameter("key");
		var sTicketno = this.getView().getElementBinding().getBoundContext().getProperty("Ticketno");

			if (sKey === "desTableKey") {
				
				
		 
            list = this.getView().byId("DesTableId");
            filter = new sap.ui.model.Filter("Ticketno",sap.ui.model.FilterOperator.EQ , sTicketno);
            binding = list.getBinding("items");
            binding.filter(filter,"Application");
            binding.refresh(true);
			}
		},

    _bindDesTable: function(oObjectId){
    
    	
     
         var list,
            binding,
            filter;
            list = this.getView().byId("DesTableId");
           filter = new sap.ui.model.Filter("Ticketno",sap.ui.model.FilterOperator.EQ , oObjectId);
            binding = list.getBinding("items");
            binding.filter(filter,"Application");
            binding.refresh(true);
            
 
    },
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Ticketno,
				sObjectName = oObject.Onceliktanimi,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList"),
				iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			oLineItemTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for line item table
				oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			});

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		handePressTalepEditBtn: function() {
			var that = this;
			var oMasterList = that.getOwnerComponent()._masterController.getView().byId("list");
			this.getOwnerComponent().oCreateTicket.open(this.getView(), this, oMasterList);
		},
		handePressTicketEditBtn: function() {
			var that = this;
			var oMasterList = that.getOwnerComponent()._masterController.getView().byId("list");
			this.getOwnerComponent().oEditTicket.open(this.getView(), this, oMasterList);

		},
		////////////////////////

		// onPressDokumanIndir:	function(oEvent) {
		// debugger;
		// var obj = oEvent.getSource().getBindingContext().getObject();

		// 		   	var sTicketno = this.getView().getElementBinding().getBoundContext().getProperty("Ticketno");

		// 			var oJsonModel = new sap.ui.model.json.JSONModel();
		// 			oJsonModel.setSizeLimit(999999);
		// 			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["mainService"].uri;
		// 			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
		// 			oModel.setHeaders({
		// 				"X-Requested-With": "XMLHttpRequest",
		// 				"Content-Type": "application/atom+xml",
		// 				"DataServiceVersion": "2.0",
		// 				"X-CSRF-Token": "Fetch"
		// 			});
		// 	//var sPath = "/dosyaEkleSet(Ticketno='" + sTicketno + "',Content='" + obj.Content + "',Filename='" + obj.Filename + "',Mimetype='" + obj.Mimetype + "')";
		// 	var sPath = "/dosyaEkleSet('"+sTicketno+"')/$value";
		// 			oModel.read(sPath, {

		// 				success: function(oData) {
		// 					// oJsonModel.setData(oData);
		// 				debugger;
		// 				},
		// 					error: function(err) {
		// 					// console.log(err);
		// 				debugger;
		// 				}
		// 			});

		// },	
		onPressDokumanIndir: function(oEvent) {
			debugger;
	
	
		
			var obj = oEvent.getSource().getBindingContext().getObject();
			


			var sTicketno = this.getView().getElementBinding().getBoundContext().getProperty("Ticketno");
		
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setSizeLimit(999999);
			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["mainService"].uri;
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			var docURL = undefined;

			var docType = undefined;

			var temp;
			var html = new sap.ui.core.HTML();
			// window.open("/sap/opu/odata/sap/ZBZ_IT_TICKET_SRV_01/dosyaEkleSet('" + sTicketno + "')/$value");
			window.open("/sap/opu/odata/sap/ZBZ_IT_TICKET_SRV_01/dosyaEkleSet(	Ticketno='" + obj.Ticketno + "',Filename='" + obj.Filename + "')/$value");
			
		
			// 	var sPath = "/dosyaEkleSet(Ticketno='" + sTicketno + "',Content='" + obj.Content + "',Filename='" + obj.Filename + "',Mimetype='" + obj.Mimetype + "')";
			// 	var sPath = "/dosyaEkleSet('"+sTicketno+"')/$value";
			// 			oModel.read(sPath,undefined, undefined, false, function(oData, oResponse){  

			//       docURL= oResponse.requestUri;

			//       temp=oResponse.headers;

			//       docType=temp["Content-Type"];

			// },function(oError){

			// }); 

			// if(docType=="application/pdf" || docType=="image/jpeg"){

			//       html.setContent("<iframe src='" + docURL + "' type='"+ docType+"' width='600' height='700'> </iframe>");

			// }else{

			//       html.setContent("<embed src='" + docURL + "' title='attachment'" +

			//       " width='1000px' height='1000px'></embed>");

			// }

		},

		onChangeFile: function(oEvent) {
			debugger;
debugger;
			var sTicketno = this.getView().getElementBinding().getBoundContext().getProperty("Ticketno");
			var Service2 = window.location.origin + "/sap/opu/odata/sap/ZBZ_IT_TICKET_SRV_01/dosyaEkleSet";
			//var oView = this.getView();
			//var oUploader = oView.byId("oUploader");
			var oFileUploader = this.getView().byId("idUpload");
			var file = oEvent.getParameter("files")[0];
			var BASE64_MARKER = 'data:' + file.type + ';base64,';
			//var file = jQuery.sap.domById(oFileUploader.getId() + "-fu").files[0];
			//var BASE64_MARKER = 'data:' + file.type + ';base64,';
			// var oRequest = sap.ui.getCore().getModel(this.getModelName())._createRequest();
			var filename = file.name;
			var reader = new FileReader();
			
			var thy = this;
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					
				
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
					// oModel1 = sap.ui.getCore().getModel("CreateModel");
					// oModel.oData.field = evt.target.result.substring(base64Index);
					var base64 = evt.target.result.substring(base64Index);
					// *****************************

					var imgdata1 = {
						"Ticketno": sTicketno,
						"Mimetype": BASE64_MARKER,
						"Filename": filename,
						"Content": base64
					};
					
					var service_url = Service2;
					var imgdata = JSON.stringify(imgdata1);
			

					$.ajaxSetup({
						cache: false
					});
					  var model = new sap.ui.model.json.JSONModel();
					jQuery.ajax({
						
						url: service_url,
						async: false,
						dataType: 'json',
						cache: false,
						data: base64,
						type: 'POST',
						
				
						beforeSend: function(xhr) {

							xhr.setRequestHeader("X-CSRF-Token", this.token);
							xhr.setRequestHeader("Content-Type", file.type);
							xhr.setRequestHeader("Slug", filename + "/" + sTicketno);

						},
						success: function(odata) {
							MessageToast.show("Dosya yüklendi");
								thy.getView().getModel.refresh(true);
						 //sap.ui.getCore().byId("idList").getModel().refresh(true);
							// document.location.reload(true);
						},
						error: function() {
		     var list,
            binding,
            filter;
            list = thy.getView().byId("idList");
            filter = new sap.ui.model.Filter("Ticketno",sap.ui.model.FilterOperator.EQ , sTicketno);
            binding = list.getBinding("items");
            binding.filter(filter,"Application");
            binding.refresh(true);
										// thy.getView().getModel.refresh(true);
                            MessageToast.show("Lütfen bekleyiniz");
                            			
					
						}
					});
				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);


		},

		onPressDokumanSil: function(oEvent) {
			debugger;
				var that = this;
			var path = oEvent.getParameter("listItem").getBindingContext();
	     	var odata = path.oModel.getProperty(oEvent.getParameter("listItem").getBindingContext().getPath()).Filename;
	
		
           var obj = oEvent.getSource().getBindingContext().getObject();
           var oTable = this.getView().byId("idList");
  	var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText("silErrorTitle");
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText("silMesText");
		
			sap.m.MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.QUESTION,
					actions: [sap.m.MessageBox.Action.CANCEL, sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction === sap.m.MessageBox.Action.OK) {

						var sPath = "/dosyaEkleSet(Ticketno='" + obj.Ticketno + "',Filename='" + odata + "')";

			var oViewModel = that.getView().getModel("detailView");
			oViewModel.setProperty("/busy", true);
		
			that.getView().getModel().remove(sPath, {
				success: function() {
					oViewModel.setProperty("/busy", false);
					if (oTable) {
						oTable.removeSelections();
					}
					debugger;
					that.showMessage("Dosya silindi");
					that.getView().getModel().refresh();
					// if (fReturnFunction) {
					// 	fReturnFunction(that);
					// }
				},
				error: function(oError) {
					try {
						// var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
						// that.showErrorMessage(sErrorMessage);
					} catch (err) {
						var sTempMsg = that.getResourceBundle().getText("updateFail");
						that.showErrorMessage(sTempMsg);
					} finally {
						oViewModel.setProperty("/busy", false);
						that.getModel().refresh();
					}
				}
			});


						} else if (oAction === sap.m.MessageBox.Action.CANCEL) {
					
						}
					}
				}
			);

			//   	var sPath = "/dosyaEkle(Ticketno='" + obj.Ticketno + "',Filename='" + obj.filename +
			// "',Content='" + obj.Content + "',Mimetype='" + obj.Mimetype + "')";

		
		}

	});

});