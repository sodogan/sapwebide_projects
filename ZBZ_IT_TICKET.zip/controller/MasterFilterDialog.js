sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.MasterFilterDialog", {

		_getDialog: function() {
			if (!this.oMasterFilterDialog) {
				this.oMasterFilterDialog = sap.ui.xmlfragment("com.bozankaya.view.MasterFilterDialog", this);
			}
			return this.oMasterFilterDialog;
		},
		open: function(oView, oController) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;

			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
			oController.getView().addDependent(oDialog);
			oDialog.open();
		},
		onCloseDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oMasterFilterDialog.destroy();
			this.oMasterFilterDialog = undefined;
		},

		onSaveFilterBtn: function() {
			var that = this;

			var sTicketSorumlu = sap.ui.getCore().byId("ticketSorumluSelectF");
			var sTicketSorumluValue = sTicketSorumlu.getSelectedKey();

			if (sTicketSorumluValue) {
				this.oController._oListFilterState.aFilter = [new Filter("Ticketsorumlu", FilterOperator.EQ, sTicketSorumluValue)];
			} else {
				// sTicketSorumlu.setValueState(sap.ui.core.ValueState.Error);
				// that.showErrorMessage("warningTitle", "checkSorumluSlct");
				// return;
				this.oController._oListFilterState.aFilter = [];
			}

			// if (sTicketSorumluValue) {
			// 	this.oController._oListFilterState.aFilter.push(new Filter("Ticketsorumlu", FilterOperator.EQ, sTicketSorumluValue));
			// } else {
			// 	sTicketSorumlu.setValueState(sap.ui.core.ValueState.Error);
			// 	that.showErrorMessage("warningTitle", "checkSorumluSlct");
			// 	return;

			// }

			this.oView.byId("masterFilterBtn").setType(sap.m.ButtonType.Emphasized);
			this.oController._applyFilterSearch();
			this.onDialogAfterClose();
		},

		handleChangeSorumluSlct: function(oEvent) {
			var oSource = oEvent.getSource();
			oSource.setValueState(sap.ui.core.ValueState.None);
			if (!oSource.getSelectedKey()) {
				oSource.setValueState(sap.ui.core.ValueState.Error);
				return;
			}

		}

	});

});