sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.BukrsVH", {

		open: function(oView, oController, pSource) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.Input = pSource;
			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);

			oController.getView().addDependent(oDialog);
			oDialog.open();
		},

		_getDialog: function() {
			if (!this.oBukrsVH) {
				this.oBukrsVH = sap.ui.xmlfragment("com.bozankaya.view.BukrsVH", this);
			}
			return this.oBukrsVH;
		},
		onCloseDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oBukrsVH.destroy();
			this.oBukrsVH = undefined;
		},

		onItemSelect: function(oEvent) {
			var oItem = oEvent.getSource();
			var oObject = oItem.getBindingContext().getObject();
			
			this.Input.setValue(oObject.Bukrs);
			this.Input.setValueState(sap.ui.core.ValueState.None);

			this._getDialog().close();

		}

	});

});