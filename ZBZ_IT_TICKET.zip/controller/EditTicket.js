sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.EditTicket", {

		_getDialog: function() {
			if (!this.oEditTicket) {
				this.oEditTicket = sap.ui.xmlfragment("com.bozankaya.view.EditTicket", this);
			}
			return this.oEditTicket;
		},
		open: function(oView, oController, oList) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.oList = oList;

			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
			oController.getView().addDependent(oDialog);
			this._setTalepEdenPernr();
			oDialog.open();
		},
		onCloseDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oEditTicket.destroy();
			this.oEditTicket = undefined;
		},

		onPressTicketSaveButton: function() {
			var that = this;

			var sTicketNo = sap.ui.getCore().byId("ticketNoInpedt");
			var sTicketNoValue = sTicketNo.getValue();

			var sTicketSorumlu = sap.ui.getCore().byId("ticketSorumluSelect");
			var sTicketSorumluValue = sTicketSorumlu.getSelectedKey();
			if (!sTicketSorumluValue) {
				sTicketSorumlu.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkSorumluSlct");
				return;
			}

			var sDurum = sap.ui.getCore().byId("ticketDurumSelect");
			var sDurumValue = sDurum.getSelectedKey();
			if (!sDurumValue) {
				sDurum.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkDurum");
				return;
			}

			var sTalepSorumlusuAcklm = sap.ui.getCore().byId("talepSorumlusuAcklm");
			var sTalepSorumlusuAcklmValue = sTalepSorumlusuAcklm.getValue();
			if (!sTalepSorumlusuAcklmValue) {
				sTalepSorumlusuAcklm.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkTalepSorumlu");
				return;
			}
	
			this.oEntry = {
				"Ticketno": sTicketNoValue,
				"Ticketsorumlu": sTicketSorumluValue,
				"Durum": sDurumValue,
				"Tlpsorumluacklm": sTalepSorumlusuAcklmValue,
				"Operation": "TicketEdit",
				"Ename": this.aEname,
				"Pernr": this.aPernr 
			};

			that.showConfirmationDialog("editTicketSure", this._editTicket);

		},

		onLiveChange: function(oEvent) {
			var oInputId = oEvent.getSource().getId();

			if (oInputId.indexOf('ticketSorumluSelect') > -1) {
				sap.ui.getCore().byId("ticketSorumluSelect").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('ticketDurumSelect') > -1) {
				sap.ui.getCore().byId("ticketDurumSelect").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('talepSorumlusuAcklm') > -1) {
				sap.ui.getCore().byId("talepSorumlusuAcklm").setValueState(sap.ui.core.ValueState.None);
			}
		},

		_editTicket: function(pAction) {
			if (pAction === sap.m.MessageBox.Action.YES) {
				var that = this;
				sap.ui.getCore().byId("editTicketDialog").setBusy(true);
				var oModel = that.getModelAndSetHeaders("mainService");

				oModel.create("/masterSet", this.oEntry, {
					success: function() {
						that.showSuccessMessage("successDataTitle", "successEditedTicket");
						sap.ui.getCore().byId("editTicketDialog").setBusy(false);
						that.oList.getBinding("items").refresh();
						that.onCloseDialog();
					},
					error: function(oError) {
						var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
						that.showErrorMessage("errorTitle", sErrorMessage);
						sap.ui.getCore().byId("editTicketDialog").setBusy(false);
					}
				});

			}
		},
			_setTalepEdenPernr: function() {
			debugger;
			var that = this;
			var oData = this.getOwnerComponent().getModel("statuModel").getData();
			this.aEname = oData.fullname;
			this.aPernr = oData.pernr;
		

		}

	});

});