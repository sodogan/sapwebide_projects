sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.OncelikKoduVH", {

		open: function(oView, oController, pSource) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.Input = pSource;
			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);

			oController.getView().addDependent(oDialog);
			oDialog.open();
		},

		_getDialog: function() {
			if (!this.oOncelikKoduVH) {
				this.oOncelikKoduVH = sap.ui.xmlfragment("com.bozankaya.view.OncelikKoduVH", this);
			}
			return this.oOncelikKoduVH;
		},
		onCloseDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oOncelikKoduVH.destroy();
			this.oOncelikKoduVH = undefined;
		},

		onItemSelect: function(oEvent) {
			var oItem = oEvent.getSource();
			var oObject = oItem.getBindingContext().getObject();

			this.Input.setValue(oObject.Oncelikkodutx);
			this.Input.setValueState(sap.ui.core.ValueState.None);

			// Input'a oncelikd kodun tanımını verdik.Ticket yaratırken öncelik kodu almak için modele atıyoruz
			var oJSModel = new sap.ui.model.json.JSONModel();
			this.oView.setModel(oJSModel, "oncelikKodModel");
			var oTempData = {
				root: oObject
			};
			oJSModel.setData(oTempData);
			this._getDialog().close();

		}

	});

});