sap.ui.define([
	"com/bozankaya/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/bozankaya/model/formatter",
	"sap/m/MessageToast"
], function(BaseController, Filter, FilterOperator, formatter,MessageToast) {
	"use strict";

	return BaseController.extend("com.bozankaya.controller.CreateTicket", {

		formatter: formatter,

		_getDialog: function() {
			if (!this.oCreateTicket) {
				this.oCreateTicket = sap.ui.xmlfragment("com.bozankaya.view.CreateTicket", this);
			}
			return this.oCreateTicket;
		},
		open: function(oView, oController, oList) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.oList = oList;

			this._statu = "Create";
			sap.ui.getCore().byId("idUpload2").setVisible(true);
			if (oView.getControllerName() === "com.bozankaya.controller.Detail") {
				this._statu = "TalepEdit";
				
					sap.ui.getCore().byId("idUpload2").setVisible(false);
				
				// this._bindEditDialog(oController.getView().getElementBinding().getPath());
				this._bindAltBirimSelect();
				var sDurum = oView.getElementBinding().getBoundContext().getObject().Durum;

				if (sDurum && sDurum === "Testte") {
					sap.ui.getCore().byId("ticketDurumuLbl").setVisible(true);
					sap.ui.getCore().byId("ticketDurumSelectCr").setVisible(true);
				}

			}

			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
			oController.getView().addDependent(oDialog);
			this._setTalepEdenPernr();

			oDialog.open();
		},
		onCloseDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oCreateTicket.destroy();
			this.oCreateTicket = undefined;
		},
		onPressTalepEdnVH: function() {
			this.getOwnerComponent().oPersonelValueHelp.open(this.getView(), this);
		},

		handeSelectTicketTuru: function(oEvent) {

			if (oEvent === undefined) {
				var sTicketTuru = this.oView.getElementBinding().getBoundContext().getObject().Ticketturu;
			} else {
				sTicketTuru = oEvent.getSource().getSelectedItem().getBindingContext().getObject().Ticketturu;
			}

			if (!sTicketTuru) {
				return;
			}

			var oSelect = sap.ui.getCore().byId("altBirimSelect");
			var oTemplate = oSelect.getBindingInfo("items").template;
			var oFilter = new Filter("Ticketturu", FilterOperator.EQ, sTicketTuru);

			oSelect.bindItems({
				path: "/altBirimSet",
				template: oTemplate,
				filters: [oFilter],
				events: {
					dataRequested: function() {},
					dataReceived: function() {}
				}
			});
		},

		onPressOncelikKoduVH: function(oEvent) {
			this.getOwnerComponent().oOncelikKoduVH.open(this.getView(), this, oEvent.getSource());
		},

		onPressTicketSaveButton: function() {
			
			var that = this;
			

			var sTicketNo = sap.ui.getCore().byId("ticketNoInp");
			var sTicketNoValue = sTicketNo.getValue();

			var sBukrs = sap.ui.getCore().byId("bukrsInp");
			var sBukrsValue = sBukrs.getValue();
			if (!sBukrsValue) {
				sBukrs.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkBukrs");
				return;
			}

			var sTalepEdnPernr = sap.ui.getCore().byId("talepEdenPernr");
			var sTalepEdnPernrValue = sTalepEdnPernr.getValue();
			if (!sTalepEdnPernrValue) {
				sTalepEdnPernr.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkTalepEden");
				return;
			}

			var sTicketTuru = sap.ui.getCore().byId("ticketTuruSelect");
			var sTicketTuruValue = sTicketTuru.getSelectedKey();
			if (!sTicketTuruValue) {
				sTicketTuru.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkTicketTuru");
				return;
			}

			var sAltBirim = sap.ui.getCore().byId("altBirimSelect");
			var sAltBirimValue = sAltBirim.getSelectedKey();
			if (!sAltBirimValue) {
				sAltBirim.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkAltBirim");
				return;
			}

			var sOncelikDrm = sap.ui.getCore().byId("oncelikDrm");
			var oOncelikKodModel = this.getView().getModel("oncelikKodModel");
			if (oOncelikKodModel) {
				var sOncelikDrmValue = oOncelikKodModel.getData().root.Oncelikkodu;
			} else {
				sOncelikDrmValue = that.oView.getElementBinding().getBoundContext().getObject().Oncelikkodu;
			}

			if (!sOncelikDrmValue) {
				sOncelikDrm.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkOncelikDurum");
				return;
			}

			var sTalepSahibiAcklm = sap.ui.getCore().byId("talepSahibiAcklm");
			var sTalepSahibiAcklmValue = sTalepSahibiAcklm.getValue();
			if (!sTalepSahibiAcklmValue) {
				sTalepSahibiAcklm.setValueState(sap.ui.core.ValueState.Error);
				that.showErrorMessage("warningTitle", "checkTalepSahibiAcklm");
				return;
			}

			var sDurum = sap.ui.getCore().byId("ticketDurumSelectCr");
			var sDurumValue = sDurum.getSelectedKey();

			if (!sDurumValue) {
				sDurumValue = "Başlangıç";
			}
				
			//deneme atachment 


	this.oEntry = {};
			
			
			if(that.file) {

 
			var BASE64_MARKER = 'data:' + that.file.type + ';base64,';
			var filename = that.file.name;
		
			var reader = new FileReader();
 	reader.onload = (function(theFile) {
				return function(evt) {
					
		
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
					// oModel1 = sap.ui.getCore().getModel("CreateModel");
					// oModel.oData.field = evt.target.result.substring(base64Index);
				   that.base64 = evt.target.result.substring(base64Index);
					// *****************************


			that.oEntry.Type = that.file.type;
			that.oEntry.Name = that.file.name;
			that.oEntry.Content = that.base64;

		
	
				};
			})(that.file);
	
			// Read in the file as text
			reader.readAsDataURL(that.file);
		
				
			}
		
	

		
		
		
			
			//deneme attach bitiş
	
			this.oEntry.Ticketno = sTicketNoValue;
			this.oEntry.Bukrs = sBukrsValue;
			this.oEntry.Talepeden = sTalepEdnPernrValue;
			this.oEntry.Ticketturu = sTicketTuruValue;
			this.oEntry.Altbirim = sAltBirimValue;
			this.oEntry.Oncelikkodu = sOncelikDrmValue;
			this.oEntry.Tlpsahibiacklm = sTalepSahibiAcklmValue;
			this.oEntry.Durum = sDurumValue;
			this.oEntry.Operation = this._statu;
			this.oEntry.Ename = this.aEname;
			this.oEntry.Pernr = this.aPernr;

			var sMessage = that.getView().getModel("i18n").getResourceBundle().getText("createTicketSure");
			if (that._statu === "TalepEdit") {
				sMessage = that.getView().getModel("i18n").getResourceBundle().getText("editTicketSure");
			}

			that.showConfirmationDialog(sMessage, this._createTicket);

		},

		onLiveChange: function(oEvent) {
			var oInputId = oEvent.getSource().getId();

			if (oInputId.indexOf('bukrsInp') > -1) {
				sap.ui.getCore().byId("bukrsInp").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('talepEdenPernr') > -1) {
				sap.ui.getCore().byId("talepEdenPernr").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('ticketTuruSelect') > -1) {
				sap.ui.getCore().byId("ticketTuruSelect").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('altBirimSelect') > -1) {
				sap.ui.getCore().byId("altBirimSelect").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('oncelikDrm') > -1) {
				sap.ui.getCore().byId("oncelikDrm").setValueState(sap.ui.core.ValueState.None);
			} else if (oInputId.indexOf('talepSahibiAcklm') > -1) {
				sap.ui.getCore().byId("talepSahibiAcklm").setValueState(sap.ui.core.ValueState.None);
			}
		},

		_createTicket: function(pAction) {
			if (pAction === sap.m.MessageBox.Action.YES) {
				var that = this;
				sap.ui.getCore().byId("createTicketDialog").setBusy(true);
				var oModel = that.getModelAndSetHeaders("mainService");
				
				var sMessage = that.getView().getModel("i18n").getResourceBundle().getText("successCreatedTicket");
				if (that._statu === "TalepEdit") {
					sMessage = that.getView().getModel("i18n").getResourceBundle().getText("successEditedTicket");
				}
				
				oModel.create("/masterSet", this.oEntry, {
					success: function(oData, oResponse) {
						debugger;
							that.oEntry = {};
								that.file= "";
						sMessage = sMessage + " : " + that.parseToInt(oData.Createdticket);
						that.showSuccessMessage("successDataTitle", sMessage);
						sap.ui.getCore().byId("createTicketDialog").setBusy(false);
						that.oList.getBinding("items").refresh();
						that.onCloseDialog();
					
					},
					error: function(oError) {
						var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
						that.showErrorMessage("errorTitle", sErrorMessage);
						sap.ui.getCore().byId("createTicketDialog").setBusy(false);
					}
				});

			}
		},

		_bindEditDialog: function(pPath) {
			sap.ui.getCore().byId("createSimpleForm").bindElement(pPath);
		},

		onPressBukrsVH: function(oEvent) {
			this.getOwnerComponent().oBukrsVH.open(this.getView(), this, oEvent.getSource());
		},

		_bindAltBirimSelect: function() {
			this.handeSelectTicketTuru();
		},

		_setTalepEdenPernr: function() {
			debugger;
			var that = this;
			var oData = this.getOwnerComponent().getModel("statuModel").getData();
			this.aEname = oData.fullname;
			this.aPernr = oData.pernr;
			if (oData) {
				oData.pernr = that.parseToInt(oData.pernr);
				sap.ui.getCore().byId("talepEdenPernr").setValue(oData.pernr);
				sap.ui.getCore().byId("talepEdenEname").setText(oData.fullname);
			}

		},
		
			onChangeFile2: function(oEvent) {

		

		
			this.file = oEvent.getParameter("files")[0];
		
			}

	});

});