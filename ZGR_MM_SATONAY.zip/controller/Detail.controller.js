sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/library",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Label",
	"sap/m/Button",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/ui/model/type/Float",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function(BaseController, JSONModel, formatter, mobileLibrary, Dialog, DialogType, Label, Button, MessageToast, Text, TextArea, Float,
	Filter,
	FilterOperator, MessageBox, Fragment) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;
	var ButtonType = mobileLibrary.ButtonType;

	return BaseController.extend("com.grebo.ZGR_MM_SATONAY.controller.Detail", {

		formatter: formatter,

		onInit: function() {
			var oView = new JSONModel({
				inpEn: true
			});

			this.setModel(oView, "detailView");

			this.setModel(new JSONModel(), "Note");

			this.getRouter().getRoute("Detail").attachPatternMatched(this._onObjectMatched, this);

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		_onObjectMatched: function(oEvent) {
			var dialogBusy = new sap.m.BusyDialog();
			dialogBusy.setText("İşlem sürüyor, lütfen bekleyiniz..");
			this._dialogBusy = dialogBusy;
			
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this._Object = oEvent.getParameter("arguments");
			this.getModel("appSatOnyView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("SatOnayMasterSet", {
					Banfn: sObjectId
				});
				this._setNote(sObjectId);
				this._getDocument(sObjectId);
				this._setItem(sObjectId);
				this._bindView("/" + sObjectPath);

			}.bind(this));
		},
		_getDocument: function(sObjectId) {
			var sCatid = "BO";
			var sTypeid = "BUS2105";
			var aFilter = [];
			aFilter.push(new Filter("Typeid", FilterOperator.EQ, sTypeid));
			aFilter.push(new Filter("Catid", FilterOperator.EQ, sCatid));
			aFilter.push(new Filter("Instid", FilterOperator.EQ, sObjectId));

			this.getView().byId("satdocumentlist").getBinding("items").filter(aFilter);
		},
		_setNote: function(sObjectId) {
			var oModel = this.getModelAndSetHeaders("mainService");
			var sObjectPath = this.getModel().createKey("/SatOnayNoteSet", {
				Banfn: sObjectId
			});
			oModel.read(sObjectPath, {
				success: function(oData) {
					var dataMetinList = {
						"Banfn": oData.Banfn,
						"Not1": oData.Not1,
						"Not2": oData.Not2,
						"Not3": oData.Not3,
						"Not4": oData.Not4,
						"Not5": oData.Not5,
						"Not6": oData.Not6,
						"Not7": oData.Not7,
						"Not8": oData.Not8,
						"Not1Vis": oData.Not1Vis,
						"Not2Vis": oData.Not2Vis,
						"Not3Vis": oData.Not3Vis,
						"Not4Vis": oData.Not4Vis,
						"Not5Vis": oData.Not5Vis,
						"Not6Vis": oData.Not6Vis,
						"Not7Vis": oData.Not7Vis,
						"Not8Vis": oData.Not8Vis
					};
					var oModelMetinList = new sap.ui.model.json.JSONModel(dataMetinList);
					this.getOwnerComponent().setModel(oModelMetinList, "MetinList");
				}.bind(this),
				error: function(oError) {

				}
			});

		},

		_setItem: function(sObjectId) {
			var ItemFilter = [];
			ItemFilter.push(new Filter("Banfn", sap.ui.model.FilterOperator.EQ, sObjectId));

			var oList = this.getView().byId("bnfpoId");
			oList.destroyItems();
			var oBinding = oList.getBinding("items");
			oBinding.filter(ItemFilter);
		},
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Banfn;

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
			//_________________________________________________________________________________oakalan
			// this._changeStatus("B");

			// this._onayRet(sObjectId);

			// this._ilkMontajDeneme(sObjectId);

			//_________________________________________________________________________________oakalan
		},
		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onCloseDetailPress: function() {
			this.getModel("appSatOnyView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("Master");
		},
		toggleFullScreen: function() {
			var bFullScreen = this.getModel("appSatOnyView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appSatOnyView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appSatOnyView").setProperty("/previousLayout", this.getModel("appSatOnyView").getProperty("/layout"));
				this.getModel("appSatOnyView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appSatOnyView").setProperty("/layout", this.getModel("appSatOnyView").getProperty("/previousLayout"));
			}
		},
		//_________________________________________________________________________________________________________POST
		onPressSatOnay: function(oEvent) {
			this._dialogBusy.open();
			var oView = this.getView();
			var oElementBinding = oView.getElementBinding();
			var sPath = oElementBinding.getPath();
			var oObject = oView.getModel().getObject(sPath);
			var oEntry = {};

			var oModel = this.getModelAndSetHeaders("mainService");

			oModel.callFunction("/ApprovePr", {
				method: "POST",
				urlParameters: {
					Banfn: oObject.Banfn,
					Pernr: oObject.Pernr,
					Frggr: oObject.Frggr,
					Frgco: oObject.Frgco
				},
				success: function(oData) {
					this._dialogBusy.close();
					MessageBox.success("onaylama işlemi tamamlandı.");
					this.onCloseDetailPress();
				}.bind(this),
				error: function(oError) {
					this._dialogBusy.close();
					var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(sErrorMessage);
				}.bind(this)
			});

		},
		onPressSatRet: function(oEvent) {
				this._dialogBusy.open();
			var that = this;
			this._sNot = "";
			this._sRetNotu = "";
			this.showMessageBoxDialog("Lütfen ret notu giriniz", that._satYes, "RET");
		},
		showMessageBoxDialog: function(sBaslik, fnOnayla, sPrm1) {
			var that = this;
			if (sPrm1 === "RET") {
				var sValueState = "Error";
				var sPlaceHolder = "Not girişi zorunlu!";
				var sEnabled = false;
			}
			var oDialog = new Dialog({
				title: sBaslik,
				type: "Message",
				content: [
					new TextArea({
						width: "100%",
						growing: true,
						growingMaxLines: 7,
						valueState: sValueState,
						placeholder: sPlaceHolder,
						liveChange: function(oEvent) {
							var sValue = oEvent.getParameter("value");

							if (sPrm1 === "RET") {
								if (sValue !== "") {
									oDialog.getContent()[0].setProperty("valueState", "None");
									oDialog.getBeginButton().setProperty("enabled", true);

								} else {
									oDialog.getContent()[0].setProperty("valueState", "Error");
									oDialog.getContent()[0].setProperty("placeholder", "Not girişi zorunlu!");
									oDialog.getBeginButton().setProperty("enabled", false);
								}
							}

							that._sNot = sValue;
						}
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: "Tamam",
					enabled: sEnabled,
					press: function() {
						if (fnOnayla) {
							fnOnayla(that, that._sNot, sPrm1);

						}
						oDialog.close();
					}
				}),
				endButton: new Button({
					text: "İptal",
					press: function() {
						oDialog.close();
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},
		_satYes: function(that, sNot, sIslem) {
			var oView = that.getView();
			var oElementBinding = oView.getElementBinding();
			var sPath = oElementBinding.getPath();
			var oObject = oView.getModel().getObject(sPath);
			var oEntry = {};

			var oModel = that.getModelAndSetHeaders("mainService");

			oModel.callFunction("/RejectPr", {
				method: "POST",
				urlParameters: {
					Banfn: oObject.Banfn,
					Pernr: oObject.Pernr,
					Retnote: sNot
				},
				success: function(oData) {
					that._dialogBusy.close();
					MessageBox.success("Reddetme işlemi tamamlandı.");
					that.onCloseDetailPress();
				}.bind(this),
				error: function(oError) {
					that._dialogBusy.close();
					var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(sErrorMessage);
				}.bind(this)
			});
		}

	});

});