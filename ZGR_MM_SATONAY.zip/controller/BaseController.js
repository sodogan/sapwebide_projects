sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function(Controller, History, MessageToast, MessageBox, JSONModel) {
	"use strict";

	return Controller.extend("com.grebo.ZGR_MM_SATONAY.controller.BaseController", {

		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				// eslint-disable-next-line sap-no-history-manipulation
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},
		parseToInt: function(pInt) {
			return pInt === "" ? 0 : parseInt(pInt);
		},
		getModelAndSetHeaders: function(pDataSource) {
			var oModel, sServiceUrl;
			if (pDataSource) {
				sServiceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources[pDataSource].uri;
				oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			} else {
				oModel = this.getView().getModel();
			}
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			return oModel;
		},
		showErrorMessage: function(pTitle, pMsg) {
			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText(pTitle);
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(pMsg);
			if (!pMBMessage) {
				pMBMessage = pMsg;
			}
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.ERROR,
					actions: [sap.m.MessageBox.Action.OK]
				}
			);
		},
		_setModel: function(aData, sModel) {

			var oDataModel = new JSONModel();
			var oData = {
				results: []
			};
			oData.results = aData;

			oDataModel.setData(oData);
			oDataModel.setSizeLimit(999999);
			this.getOwnerComponent().setModel(oDataModel, sModel);

			oDataModel.refresh();
		}

	});

});