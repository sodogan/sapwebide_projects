sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter"
], function(BaseController, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter) {
	"use strict";

	return BaseController.extend("com.grebo.ZGR_MM_SATONAY.controller.Master", {

		formatter: formatter,
		onInit: function() {
			 
			// Control state model
			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.getOwnerComponent().setModel(oViewModel, "masterView");

			oList.attachEventOnce("updateFinished", function() {
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("Master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

		},

		_onMasterMatched: function() {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appSatOnyView").setProperty("/layout", "OneColumn");

			var aFilter = this._setFilterStatus("B");

			this._oListFilterState.aFilter = aFilter;

			this._applyFilterSearch();
		},

		onFilterBar: function(oEvent) {
			this._onCloseDetailPress();
			var sKey = oEvent.getParameters().key;
			var aFilter = this._setFilterStatus(sKey);
			this._oListFilterState.aFilter = aFilter;
			this._applyFilterSearch();
		},
		_onCloseDetailPress: function() {
			this.getModel("appSatOnyView").setProperty("/layout", "OneColumn");
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("Banfn", FilterOperator.Contains, sQuery)];
			} else {
				this._oListFilterState.aSearch = [];
			}

			this._applyFilterSearch();

		},

		_setFilterStatus: function(sStatus) {

			var aFilter = [];
			aFilter.push(new Filter("Durum", FilterOperator.EQ, sStatus));
			return aFilter;
		},

		_applyFilterSearch: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getOwnerComponent().getModel("masterView");
			// this._oList.getBinding("items").filter(aFilters, "Application");
			var oStatuModel = this.getOwnerComponent().getModel("Header").getData();
			aFilters.push(new Filter("Pernr", FilterOperator.EQ, oStatuModel.pernr));
			this._oList.getBinding("items").filter(aFilters);

			this.onRefresh();

			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		_updateFilterBar: function(sFilterBarText) {
			var oViewModel = this.getOwnerComponent().getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},

		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getOwnerComponent().getModel("masterView").setProperty("/title", sTitle);
			}
		},
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
		},

		onRefresh: function() {
			this._oList.getBinding("items").refresh();
		},
		onSelectionChange: function(oEvent) {
			var oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},

		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		createGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},

		onNavBack: function() {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
		},

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Degiklikno",
				groupBy: "None",
				Durum: "B"
			});
		},
		_changeStatus: function() {

			var sToolbar = this.getView().byId("iconTabBar").getSelectedKey();

			this.getOwnerComponent().getModel("masterView").setProperty("/Durum", sToolbar);
		},
		//_______________________________________________________________________________________________________
		_showDetail: function(oItem) {

			this._changeStatus();

			var oVis = false;
			var oNVis = false;

			var dataEtkiVis = {
				Vis: oVis,
				NVis: oNVis
			};

			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appSatOnyView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getRouter().navTo("Detail", {
				objectId: oItem.getBindingContext().getProperty("Banfn")
			}, bReplace);
		}

	});

});