sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device',
	'sap/ui/demo/toolpageapp/model/formatter',
	'sap/m/ResponsivePopover',
	'sap/m/MessagePopover',
	'sap/m/ActionSheet',
	'sap/m/Button',
	'sap/m/Link',
	'sap/m/NotificationListItem',
	'sap/m/MessagePopoverItem',
	'sap/ui/core/CustomData',
	'sap/m/MessageToast',
	'sap/ui/core/syncStyleClass',
	'sap/m/library',
	"sap/m/MessageBox",
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(
	BaseController,
	JSONModel,
	Device,
	formatter,
	ResponsivePopover,
	MessagePopover,
	ActionSheet,
	Button,
	Link,
	NotificationListItem,
	MessagePopoverItem,
	CustomData,
	MessageToast,
	syncStyleClass,
	mobileLibrary,
	MessageBox,
	VersionInfo,
	XMLView,
	Filters,
	FilterOperator) {
	"use strict";
	// shortcut for sap.m.PlacementType
	var PlacementType = mobileLibrary.PlacementType;
	// Dialog Busy Define
	var dialogBusy = new sap.m.BusyDialog();
	dialogBusy.setText("İşlem sürüyor, lütfen bekleyiniz..");
	// shortcut for sap.m.VerticalPlacementType
	var VerticalPlacementType = mobileLibrary.VerticalPlacementType;
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;
	// FAI JSON MAIN CREATE...
	var jsonFAIMain, jsonBildirimMain;

	return BaseController.extend("sap.ui.demo.toolpageapp.controller.FAITakibi", {
		formatter: formatter,
		onInit: function() {

			if (window.localStorage.UserType != 1) {
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Login");
			}

			this._oview = this.getView();
			var oViewModel = new JSONModel({
				isPhone: Device.system.phone,
				currentUser: window.localStorage.Username,
				lastLogin: new Date(Date.now() - 86400000)
			});
			this.setModel(oViewModel, "view");

			Device.media.attachHandler(function(oDevice) {
				this.getModel("view").setProperty("/isPhone", oDevice.name === "Phone");
			}.bind(this));
			// ------------------------------------------------------------
			jsonFAIMain = new JSONModel();
			jsonFAIMain.setProperty("/jsonFAIList", []);
			jsonFAIMain.setSizeLimit(10000);
			this.getView().setModel(jsonFAIMain, "jsonFAIView");

			jsonBildirimMain = new JSONModel();
			jsonBildirimMain.setProperty("/jsonBildirimList", []);
			jsonBildirimMain.setSizeLimit(10000);
			this.getView().setModel(jsonBildirimMain, "jsonBildirimView");

		},
		onAfterRendering: function() {
			if (window.localStorage.UserType != 1) { //Farklı Kullanıcı Grubları link ile giremez. giriş kontrolü
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Login");
			}
			const oUserInfoModel = new JSONModel({
				Username: window.localStorage.Username,
				Password: window.localStorage.Password,
				Mail: window.localStorage.Mail
			});
			this.getView().setModel(oUserInfoModel, "oUserInfoModel");

			// ----------------------------------------------------
			var oModel = this._oview.getModel(),
				aFilters = [];
			aFilters.push(new Filters("Key", FilterOperator.EQ, window.localStorage.FirmaKod));
			oModel.read("/fai_takibiSet", {
				filters: aFilters,
				async: true,
				success: function(oData, Response) {
					jsonFAIMain.setProperty("/jsonFAIList", []);
					var data = jsonFAIMain.getProperty("/jsonFAIList");

					jQuery.each(oData.results, function(index, item) {
						jsonFAIMain.refresh();
						var line = {
							index: index,
							FaiNo: item.FaiNo,
							FirmaKod: item.FirmaKod,
							FirmaAdi: item.FirmaAdi,
							PlanlananFaiTarihi: item.PlanlananFaiTarihi,
							GerceklesenFaiTarihi: item.GerceklesenFaiTarihi,
							FaiDurumu: item.FaiDurumu
						};
						data.push(line);
						jsonFAIMain.setProperty("/jsonFAIList", data);
					});
				},
				error: function(oData, Response) {
					// Hata 
				}
			});
		},
		onIslemlerAction: function(oEvent) {
			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oItem = oEvent.getParameter("item");
			var islemText = oItem.mProperties.text;
			var faiNo = oItem.mProperties.key;

			if (islemText === 'Düzenle') {
				loRouter.navTo("FAITakibiDuzenle", {
					faiNo: faiNo
				});
			} else if (islemText === 'Detayları Görüntüle') {
				loRouter.navTo("FAITakibiDetay", {
					faiNo: faiNo
				});
			}
		},
		onCloseFragment: function(oEvent) {
			var buttonID = oEvent.mParameters.id;
			if (buttonID === 'userInfoID') {
				this._oUserInfoDialog.close();
				this._oUserInfoDialog.destroy(true);
				delete this._oUserInfoDialog;
			};
		},
		onExit: function() {
			Device.media.detachHandler(this._handleWindowResize, this);
		},
		onRouteChange: function(oEvent) {
			this.getModel('side').setProperty('/selectedKey', oEvent.getParameter('name'));
			if (Device.system.phone) {
				this.onSideNavButtonPress();
			}
		},
		onUserNamePress: function(oEvent) {
			var oSource = oEvent.getSource();
			this.getModel("i18n").getResourceBundle().then(function(oBundle) {
				// close message popover
				var oMessagePopover = this.byId("errorMessagePopover");
				if (oMessagePopover && oMessagePopover.isOpen()) {
					oMessagePopover.destroy();
				}
				var fnHandleUserMenuUserInfo = function(oEvent) {
					this._oUserInfoDialog = sap.ui.xmlfragment("sap.ui.demo.toolpageapp.fragment.userInfo", this);
					this.getView().addDependent(this._oUserInfoDialog);
					this._oUserInfoDialog.open();
				}.bind(this);

				var fnHandleUserMenuItemLogout = function(oEvent) {
					var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
					loRouter.navTo("Login");
				}.bind(this);

				var oActionSheet = new ActionSheet(this.getView().createId("userMessageActionSheet"), {
					title: oBundle.getText("userHeaderTitle"),
					showCancelButton: false,
					buttons: [
						new Button({
							text: '{i18n>userAccountUserSettings}',
							type: ButtonType.Transparent,
							press: fnHandleUserMenuUserInfo
						}),
						new Button({
							text: '{i18n>userAccountLogout}',
							type: ButtonType.Transparent,
							press: fnHandleUserMenuItemLogout
						})
					],
					afterClose: function() {
						oActionSheet.destroy();
					}
				});
				this.getView().addDependent(oActionSheet);
				// forward compact/cozy style into dialog
				syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(), this.getView(), oActionSheet);
				oActionSheet.openBy(oSource);
			}.bind(this));
		},
		onSideNavButtonPress: function() {
			var oToolPage = this.byId("app");
			var bSideExpanded = oToolPage.getSideExpanded();
			this._setToggleButtonTooltip(bSideExpanded);
			oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		},
		_setToggleButtonTooltip: function(bSideExpanded) {
			var oToggleButton = this.byId('sideNavigationToggleButton');
			this.getBundleText(bSideExpanded ? "expandMenuButtonText" : "collpaseMenuButtonText").then(function(sTooltipText) {
				oToggleButton.setTooltip(sTooltipText);
			});
		},
		onMessagePopoverPress: function(oEvent) {
			var oMessagePopoverButton = oEvent.getSource();
			if (!this.byId("errorMessagePopover")) {
				this.getModel("i18n").getResourceBundle().then(function(oBundle) {
					var oMessagePopover = new MessagePopover(this.getView().createId("errorMessagePopover"), {
						placement: VerticalPlacementType.Bottom,
						items: {
							path: 'alerts>/alerts/errors',
							factory: this._createError.bind(this, oBundle)
						},
						afterClose: function() {
							oMessagePopover.destroy();
						}
					});
					this.byId("app").addDependent(oMessagePopover);
					// forward compact/cozy style into dialog
					syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(), this.getView(), oMessagePopover);
					oMessagePopover.openBy(oMessagePopoverButton);
				}.bind(this));
			}
		},
		/**
		 * Event handler for the notification button
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onNotificationPress: function(oEvent) {
			var that = this;
			var oSource = oEvent.getSource();
			// BaseControllerFM.onNotificationGlobal(oEvent, that, oSource);
			this.getModel("i18n").getResourceBundle().then(function(oBundle) {
				var oModel = this._oview.getModel(),
					aFilters = [];
				aFilters.push(new Filters("FirmaKod", FilterOperator.EQ, window.localStorage.FirmaKod));
				oModel.read("/bildirimSet", {
					filters: aFilters,
					async: true,
					success: function(oData, Response) {
						var data = [];
						jsonBildirimMain.refresh();
						jQuery.each(oData.results, function(index, item) {
							var line = {
								"BildirimNo": item.BildirimNo,
								"title": item.BildirimTitle,
								"description": item.BildirimDescription,
								"date": item.BildirimDate,
								"priority": item.BildirimPriority,
								"icon": item.BildirimIcon,
							};
							data.push(line);
							jsonBildirimMain.setProperty("/jsonBildirimList", data);
						});

						var oNotificationPopover = new ResponsivePopover(that.getView().createId("notificationMessagePopover"), {
							title: 'Bildirimler',
							contentWidth: "400px",
							placement: PlacementType.Bottom,
							content: {
								path: 'jsonBildirimView>/jsonBildirimList',
								factory: that._createNotification.bind(that)
							},
							afterClose: function() {
								oNotificationPopover.destroy();
							}
						});
						that.byId("app").addDependent(oNotificationPopover);
						syncStyleClass(that.getView().getController().getOwnerComponent().getContentDensityClass(), that.getView(),
							oNotificationPopover);
						oNotificationPopover.openBy(oSource);

					}
				});
			}.bind(this));
		},

		/**
		 * Factory function for the notification items
		 * @param {string} sId The id for the item
		 * @param {sap.ui.model.Context} oBindingContext The binding context for the item
		 * @returns {sap.m.NotificationListItem} The new notification list item
		 * @private
		 */
		_createNotification: function(sId, oBindingContext) {
			var that = this;
			var oBindingObject = oBindingContext.getObject();
			var oNotificationItem = new NotificationListItem({
				title: oBindingObject.title,
				description: oBindingObject.description,
				priority: oBindingObject.priority,
				close: function(oEvent) {
					var sBindingPath = oEvent.getSource().getCustomData()[0].getValue();
					var sIndex = sBindingPath.split("/").pop();
					var aItems = jsonBildirimMain.getProperty("/jsonBildirimList");
					var BildirimNo = aItems[sIndex].BildirimNo;
					aItems.splice(sIndex, 1);
					jsonBildirimMain.refresh();
					jsonBildirimMain.setProperty("jsonBildirimView>/jsonBildirimList", aItems);
					oEvent.getSource().getModel("alerts").updateBindings("jsonBildirimView>/jsonBildirimList");

					var oModel = that._oview.getModel(),
						sPath = "/bildirimSet",
						oData = {
							FirmaKod: 'BOZANKAYA',
							BildirimNo: BildirimNo
						},
						mParameters = {};

					oModel.setHeaders({
						"X-Requested-With": "XMLHttpRequest",
						"Content-Type": "application/atom+xml",
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch"
					});
					mParameters.success = function(oData, oReponse) {
						that.getBundleText("notificationMessageDeleted").then(function() {
							MessageToast.show(oData.Message);
						});
					}.bind(that);
					oModel.create(sPath, oData, mParameters);

				}.bind(that),
				datetime: oBindingObject.date,
				authorPicture: oBindingObject.icon,
				press: function() {},
				customData: [
					new CustomData({
						key: "path",
						value: oBindingContext.getPath()
					})
				]
			});
			return oNotificationItem;
		},
		_createError: function(oBundle, sId, oBindingContext) {
			var oBindingObject = oBindingContext.getObject();
			var oLink = new Link("moreDetailsLink", {
				text: oBundle.getText("moreDetailsButtonText"),
				press: function(oEvent) {
					this.getBundleText("clickHandlerMessage", [oEvent.getSource().getText()]).then(function(sClickHandlerMessage) {
						MessageToast.show(sClickHandlerMessage);
					});
				}.bind(this)
			});

			var oMessageItem = new MessagePopoverItem({
				title: oBindingObject.title,
				subtitle: oBindingObject.subTitle,
				description: oBindingObject.description,
				counter: oBindingObject.counter,
				link: oLink
			});
			return oMessageItem;
		},
		getBundleText: function(sI18nKey, aPlaceholderValues) {
			return this.getBundleTextByModel(sI18nKey, this.getModel("i18n"), aPlaceholderValues);
		},
		updateUserInfo: function(oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var username = sap.ui.getCore().byId("username").getValue();
			var pass = sap.ui.getCore().byId("password").getValue();
			var mail = sap.ui.getCore().byId("mail").getValue();
			if (username == "" || pass == "" || mail == "") {
				sap.ui.core.BusyIndicator.hide();
				MessageBox.alert("Bilgiler Boş Bırakılamaz!", {
					styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
				});

			} else {
				var oModel = this._oview.getModel(),
					sPath = "/userBilgi_guncelleSet",
					oData = {
						Username: username,
						Password: pass,
						Mail: mail
					},
					mParameters = {};

				oModel.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});

				mParameters.success = function(oData2, oReponse) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.success(oData2.Message, {
						actions: [MessageBox.Action.OK],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function(sAction2) {
							window.localStorage.Username = oData2.Username;
							window.localStorage.UserType = oData2.UserType;
							window.localStorage.Password = oData2.Password;
							window.localStorage.Mail = oData2.Mail;
							sap.ui.getCore().byId("idDialog").close();
						}
					});
				}.bind(this);

				mParameters.error = function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Şifre güncelleme işlemi gerçekleştirilemedi!");
				};
				oModel.create(sPath, oData, mParameters);
			};
		}
	});
});