sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, VersionInfo, XMLView, MessageBox) {
	"use strict";
	return BaseController.extend("sap.ui.demo.toolpageapp.controller.Login", {

		onInit: function() {
			window.localStorage.Username = "";
			window.localStorage.UserType = "";
			window.localStorage.Password = "";
			window.localStorage.FirmaKod = "";
			window.localStorage.Mail = "";

			var sRootPath = jQuery.sap.getModulePath("sap.ui.demo.toolpageapp");
			var sImagePath = sRootPath + "/image/boz-logo.png";

			this.getView().byId("logo").setSrc(sImagePath);
			$("#busyIndicator").remove();

			this._oview = this.getView();
			var oViewModel = new JSONModel({});
			this.setModel(oViewModel, "view");
		},

		onRefresh: function() {
			this.byId("charts").byId("statisticsBlockLayout").invalidate();
			this.byId("charts").byId("statisticsBlockLayout").setBusy(true);
			setTimeout(function() {
				this.byId("charts").byId("statisticsBlockLayout").setBusy(false);
			}.bind(this), 2000);
		},
		changeType: function() {
			if (this.getView().byId("textGor").getIcon() === "sap-icon://show") {
				this.getView().byId("pass").setType("Text");
				this.getView().byId("textGor").setIcon("sap-icon://hide");
			} else {
				this.getView().byId("pass").setType("Password");
				this.getView().byId("textGor").setIcon("sap-icon://show");
			}
		},
		forgotPress: function() {
			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
			loRouter.navTo("ForgotPass");
		},
		loginPress: function(oEvent) {

			sap.ui.core.BusyIndicator.show(0);
			var username = this.getView().byId("idUser").getValue();
			var pass = this.getView().byId("pass").getValue();

			if (username == "" || pass == "") {
				sap.ui.core.BusyIndicator.hide();
				MessageBox.alert("Kullanıcı numarası veya şifre boş olamaz!", {
					styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
				});

			} else {

				var oModel = this._oview.getModel(),
					sPath = "/giris_kontrolSet(Username='" + username + "',Password='" + pass + "')",
					oData = {},
					mParameters = {};

				oModel.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});

				mParameters.success = function(oData2, oReponse) {
					if (oData2.check == "OK") {
						if (oData2.Username != "00000000" && oData2.Password != "") {
							window.localStorage.Username = oData2.Username;
							window.localStorage.UserType = oData2.UserType;
							window.localStorage.Password = oData2.Password;
							window.localStorage.FirmaKod = oData2.FirmaKod;
							window.localStorage.Mail = oData2.Mail;

							if (oData2.IlkGiris == "X") {
								sap.ui.core.BusyIndicator.hide();
								if (this._oDialog == undefined) {
									this._oDialog = sap.ui.xmlfragment("sap.ui.demo.toolpageapp.fragment.chagepassword", this);
								}
								this.getView().addDependent(this._oDialog);
								this._oDialog.open();

							} else {
								sap.ui.core.BusyIndicator.hide();
								var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
								if (oData2.UserType == '1') {
									loRouter.navTo("home");
								} else {
									window.localStorage.FirmaKod = oData2.FirmaKod;
									loRouter.navTo("HomeAdmin");
								};
							}
						} else {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.alert("Kullanıcı Adı ve Şifre Alanı Boş Servisten Alınamadı!", {
								styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
							});
						}

					} else if (oData2.check == "PS") {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.alert("Şifre yanlış!", {
							styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
						});
					} else {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.alert(oData2.Message, {
							styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
						});
					}
				}.bind(this);

				mParameters.error = function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.alert("Yapmak istenilen işlem zaman aşımına uğraşmıştır", {
						styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
					});

				};
				oModel.read(sPath, mParameters);
			}
		},
		closeFragment: function(oEvent) {
			this._oDialog.close();
		},
		updateRecordpass: function() {

			sap.ui.core.BusyIndicator.show(0);
			var eskiSifre = sap.ui.getCore().byId("oldpass").getValue();
			var yeniSifre = sap.ui.getCore().byId("newpass").getValue();
			var yeniSifreT = sap.ui.getCore().byId("newpassagain").getValue();

			var yeniSifreCount;
			var yeniSifreCountT;

			var loRouter = sap.ui.core.UIComponent.getRouterFor(this);

			yeniSifreCount = yeniSifre.length;
			yeniSifreCountT = yeniSifreT.length;

			if (eskiSifre == "" || yeniSifre == "" || yeniSifreT == "") {

				sap.ui.core.BusyIndicator.hide();
				MessageBox.alert("Belirtilen alanlar boş geçilemez!", {
					styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
				});

			} else {

				if (window.localStorage.Password != eskiSifre) {

					sap.ui.core.BusyIndicator.hide();
					MessageBox.alert("Eski şifreniz sistemde belirlenen ilk şifreniz ile aynı değildir!", {
						styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
					});
				} else {

					if (yeniSifre != yeniSifreT) {

						sap.ui.core.BusyIndicator.hide();
						MessageBox.alert("Yeni şifre ve yeni şifre tekrarı aynı değildir!", {
							styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
						});
					} else {
						if (yeniSifreCount >= 20 || yeniSifreCountT >= 20) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.alert("Yeni şifreniz en fazla 20 karakterli olmalıdır!", {
								styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
							});

						} else {

							var oModel = this._oview.getModel(),
								sPath = "/aktivasyonSet",
								oData = {
									Username: window.localStorage.Username,
									Password: yeniSifre
								},
								mParameters = {};

							oModel.setHeaders({
								"X-Requested-With": "XMLHttpRequest",
								"Content-Type": "application/atom+xml",
								"DataServiceVersion": "2.0",
								"X-CSRF-Token": "Fetch"
							});

							mParameters.success = function(oData2, oReponse) {
								sap.ui.core.BusyIndicator.hide();
								MessageBox.success(oData2.Message, {
									actions: [MessageBox.Action.OK],
									emphasizedAction: MessageBox.Action.OK,
									onClose: function(sAction2) {
										if (oData2.check == "OK") {
											sap.ui.getCore().byId("idDialog").close();
											loRouter.navTo("Login");

										}
									}
								});
							}.bind(this);

							mParameters.error = function(oError) {
								sap.ui.core.BusyIndicator.hide();
								MessageBox.error("Şifre güncelleme işlemi gerçekleştirilemedi!");
							};
							oModel.create(sPath, oData, mParameters);
						}
					}
				}
			}
		}

	});
});