sap.ui.define([
	'./BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, VersionInfo, XMLView, MessageBox) {
	"use strict";
	return BaseController.extend("sap.ui.demo.toolpageapp.controller.ForgotPass", {

		onInit: function() {
			this._oview = this.getView();

			var oviewModel = new JSONModel({
				Pernr: ""
			});
			this._oview.setModel(oviewModel, "viewModel");

			// this.getOwnerComponent().getRouter().getRoute("twopage").attachPatternMatched(this._onObjectMatched, this);

		},
		turnBack: function() {
			this.getOwnerComponent().getRouter().navTo("Login");
		},
		_onObjectMatched: function(oEvent) {
			// var otemp = oEvent.getParameter("arguments").deger; //linkden veriyi çekme
		},

		forgotClick: function() {
			var that = this;
			sap.ui.core.BusyIndicator.show(0);
			var username = that.getView().byId("idUser").getValue();

			if (username == "") {
				sap.ui.core.BusyIndicator.hide();
				MessageBox.alert("Mail Adresiniz boş olamaz!", {
					styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
				});
			} else {
				var oModel = this._oview.getModel(),
					sPath = "/forgot_passSet(Username='" + username + "')",
					oData = {},
					mParameters = {};

				oModel.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});

				mParameters.success = function(oData2, oReponse) {
					if (oData2.check == "X") {
						that.getView().byId("idUser").setValue("");
						var mailAd = oData2.Mail.substr(0, 2);
						var mailUzanti = oData2.Mail.split("@");
						var uzantiYazdir = mailUzanti.length - 1;
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("Şifreniz " + mailAd + "****" + mailUzanti[uzantiYazdir] + " mail adresinize gönderildi", {
							styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
						});
					} else {
						that.getView().byId("idUser").setValue("");
						sap.ui.core.BusyIndicator.hide();
						MessageBox.alert(oData2.Message, {
							styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
						});
					}

				}.bind(this);
				mParameters.error = function(oError) {
					that.getView().byId("idUser").setValue("");
					sap.ui.core.BusyIndicator.hide();
					MessageBox.alert("Yapmak istenilen işlem zaman aşımına uğraşmıştır", {
						styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
					});
				};

				oModel.read(sPath, mParameters);
			}
		}

	});
});