sap.ui.define([
	"com/bozankaya/ZBZ_MALZEME_NAKIL/test/unit/controller/Login.controller"
], function () {
	"use strict";
});