sap.ui.define([
  // "sap/ui/core/mvc/Controller",
  "com/tedarik/ZGR_MM_TEKLIF/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/m/library",
  "sap/m/Dialog",
  "sap/m/Label",
  "sap/m/Button"
], function(BaseController, JSONModel, Filter, FilterOperator, MessageToast, MessageBox, mobileLibrary, Dialog, Label, Button) {
  "use strict";
  var ButtonType = mobileLibrary.ButtonType;
  return BaseController.extend("com.tedarik.ZGR_MM_TEKLIF.controller.Main", {

    onInit: function() {
      var Guid = jQuery.sap.getUriParameters().get("guid");

      if (Guid === null) {
        Guid = '1';
      }
 
      this._sGuid = Guid;
      var oNote = new JSONModel();
      this.getView().setModel(oNote, "Note");

      var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");
 
      var oVisList = false;
      var oVisBut = false;
      var oEditList = false;

      var oHeaderModel = new JSONModel({
        VisList: oVisList,
        VisBut: oVisBut,
        EditList: oEditList,
        Flpre: "",
        Guid: Guid,
        Ebeln: "",
        idate: "",
        sdate: "",
        eknam: "",
        telnum: "",
        smtpa: "",
        Zterm: "",
        Inco1: "",
        Hdffytdrm: true,
        Hdffytonydrm: true,
        Maliyetdrm: true,
        VisHeader: false
      });
      this.getOwnerComponent().setModel(oHeaderModel, "Header");


      oModel.read("/ZLP_CHECK_GUIDSet('" + Guid + "')", {
        success: function(oData) {

          var oHeader = this.getView().getModel("Header");
          var aHeaderData = oHeader.getData();

          aHeaderData.Ebeln = oData.Ebeln;
          aHeaderData.idate = oData.Idate;
          aHeaderData.sdate = oData.Sdate;
          aHeaderData.eknam = oData.Eknam;
          aHeaderData.telnum = oData.Telnum;
          aHeaderData.smtpa = oData.Smtpa;
          aHeaderData.Zterm = oData.Zterm;
          aHeaderData.Inco1 = oData.Inco1; 
          aHeaderData.Hdffytdrm = oData.Hdffytdrm;
          aHeaderData.Hdffytonydrm = oData.Hdffytonydrm;
          aHeaderData.Maliyetdrm = oData.Maliyetdrm;
          // aHeaderData.Zterm = oData.Zterm;

          //Ekran Alanlarının Tamamı
          aHeaderData.VisHeader = true;

          //Kaydet Butonu, Ödeme Vadesi, Teslim Şekli,
          //Teklif Verme Durumu (Kalem)
          aHeaderData.VisBut = oData.Fledt;

          //Ön Görünüm
          aHeaderData.Flpre = oData.Flpre;

          //Kalem Listesi Görünüm
          aHeaderData.VisList = oData.Flvis;

          oHeader.setData(aHeaderData);
          oHeader.refresh();

          this.getTeklifData(oData.Ebeln, aHeaderData.Flpre);

        }.bind(this),
        error: function(oError) {

          var oHeader = this.getView().getModel("Header");
          var aHeaderData = oHeader.getData();
          aHeaderData.VisError = false;
          oHeader.setData(aHeaderData);
          oHeader.refresh();
          var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
          // that.showErrorMessage("Hata", sErrorMessage);
          var aErrorMessage = sErrorMessage.split("++");
          var msg = "";
          for (var k = 0; k < aErrorMessage.length; k++) {
            msg = msg + aErrorMessage[k] + "\n";
          }

          MessageBox.warning(msg);

        }.bind(this)
      });


      oModel.read("/ZLP_WAERSSet", {
        success: function(oData) {

          var jsonForm = new sap.ui.model.json.JSONModel();
          jsonForm.setData(oData);
          jsonForm.setSizeLimit(999999);

          this.getOwnerComponent().setModel(jsonForm, "ItemWaers");

        }.bind(this)
      });

      oModel.read("/ZLP_IS_SURETURSet", {
        success: function(oData) {

          var jsonForm = new sap.ui.model.json.JSONModel();
          jsonForm.setData(oData);
          jsonForm.setSizeLimit(999999);

          this.getOwnerComponent().setModel(jsonForm, "ItemIsSureTur");

        }.bind(this)
      });



      //oModel.read("/ZLP_INCO1Set", {
      //  success: function(oData) {

      //    var jsonForm = new sap.ui.model.json.JSONModel();
      //    jsonForm.setData(oData);
      //    jsonForm.setSizeLimit(999999);

      //    this.getOwnerComponent().setModel(jsonForm, "ItemInco1");

      //  }.bind(this)
      //});


      var sObjectPath = "/ZLP_SAT_NOTSet(Guid='" + Guid + "')"; 
      oModel.read(sObjectPath, {
        success: function(oData){
          this.getModel("Note").setProperty("/Aciklama", oData.Aciklama);
        }.bind(this)
      });

    },
    checkOnlyNumber: function(oEvent){

      var myString = oEvent.getSource().getValue();
      myString = myString.replace(/[^\d.]|\.(?=.*\.)/g,"");

      oEvent.getSource().setValue(myString);

    },
    getTeklifData: function(Ebeln, Flpre) {
 
      var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");

      var oFilters = [];
      oFilters.push(new Filter("Ebeln", FilterOperator.EQ, Ebeln));
      oFilters.push(new Filter("Flpre", FilterOperator.EQ, Flpre));

      oModel.read("/ZLP_KLM_LISTSet", {
        filters: oFilters,
        success: function(oData) {
          var jsonForm = new sap.ui.model.json.JSONModel();
          jsonForm.setData(oData);
          jsonForm.setSizeLimit(999999);

          this.getOwnerComponent().setModel(jsonForm, "Item");

        }.bind(this)
      });

      var dataDocument = {
        "List": [{
          "Line": "",
          "Filename": "",
          "Filetype": "",
          "Filebasedata": ""
        }]
      };

      var oModelDocument = new sap.ui.model.json.JSONModel(dataDocument);
      this.getOwnerComponent().setModel(oModelDocument, "DataDocument");

      var oModelDocument2 = this.getOwnerComponent().getModel("DataDocument");
      var aData = oModelDocument2.getData();

      for (var i = 0; i < aData.List.length; i++) {
        aData.List.splice(i, 1);
      }

      oModelDocument2.setData(aData);
      oModelDocument2.refresh();
 
      var oFiltersAtt = [];
debugger;
      //oFiltersAtt.push(new Filter("Ebeln", FilterOperator.EQ, Ebeln));
	  oFiltersAtt.push(new Filter("Instid", FilterOperator.EQ, Ebeln));
      oModel.read("/DocumentTeklifSet", { 
        filters: oFiltersAtt,
        success: function(oData) {
          var jsonForm = new sap.ui.model.json.JSONModel();
          jsonForm.setData(oData);
          jsonForm.setSizeLimit(999999);

          // sap.ui.getCore().setModel(jsonForm, "Item");
          this.getOwnerComponent().setModel(jsonForm, "ItemAtta");

        }.bind(this),
        error: function( oError ) {
          //execute in case of call fail
          var obj = JSON.parse(oError.response.body);
          var msg = obj.error.message.value;
          sap.m.MessageBox.show(msg, {
            icon: sap.m.MessageBox.Icon.ERROR,
            title: "Error",
            actions: [sap.m.MessageBox.Action.OK]
          });
        }
      });

    },
    _questionHdfFyt: function(oSaveDialog){
      var aItem = this.getView().getModel("Item").getData().results;
      var bHdfFytVAR = false;
      bHdfFytVAR = aItem.find(function(item) {
        if (item.Hdffyt) {
          return true;
        }
      });

      if ( !bHdfFytVAR){ // hiçbiri seçili değilse normal kaydetsin
        oSaveDialog.open();
        return;
      }
      // seçili olan varsa 2 soru sorulacak
      var Question = this.getModel("i18n").getResourceBundle().getText("tarPriceApQue");

      var that = this;
      var oDialog = new Dialog({
        title: '',
        type: 'Message',
        content: [
          new Label({
            text: Question,
            labelFor: 'rejectDialogTextarea'
          })
        ],
        beginButton: new Button({
          type: ButtonType.Emphasized,
          text: 'Onayla',
          press: function() {
            oSaveDialog.open();
            oDialog.close();
          }
        }),
        endButton: new Button({
          text: 'İptal',
          press: function() {
            oDialog.close();
          }
        }),
        afterClose: function() {
          oDialog.destroy();
        }
      });

      oDialog.open();

    },
    _setTslmtDatum: function( oItem ){
      var aResult = oItem.results;

      for ( var i=0;i<aResult.length;i++){
        aResult[i].Tslmt.setHours("23","59");
      }

    },
    onSaveButtonPress: function() {

      var Question = this.getModel("i18n").getResourceBundle().getText("biddingApprove");
      var that = this;
      var oDialog = new Dialog({
        title: '',
        type: 'Message',
        content: [
          new Label({
            text: Question,
            labelFor: 'rejectDialogTextarea'
          })
        ],
        beginButton: new Button({
          type: ButtonType.Emphasized,
          text: this.getModel("i18n").getResourceBundle().getText("approve"),
          press: function() {

            var oModelHeader = that.getOwnerComponent().getModel("Header");
            var aDataHeader = oModelHeader.getData();
            var oModelDocument = that.getOwnerComponent().getModel("DataDocument");
            var aDataDocument = oModelDocument.getData();
            var oItem = that.getView().getModel("Item").oData;
 
            that._setTslmtDatum(oItem);
 
            var jsonData = JSON.stringify(oItem);
            var encodedString = btoa(unescape(encodeURIComponent(jsonData)));

            var oItemDocument = that.getView().getModel("DataDocument").oData;
            var jsonDataDocument = JSON.stringify(oItemDocument);
            var encodedStringDocument = btoa(unescape(encodeURIComponent(jsonDataDocument)));

            that.oCreateArray = {};
            that.oCreateArray.Zterm = aDataHeader.Zterm;
            that.oCreateArray.Inco1 = aDataHeader.Inco1;
            that.oCreateArray.Guid = aDataHeader.Guid;
            that.oCreateArray.String = encodedString;
            that.oCreateArray.String2 = encodedStringDocument;
            that.oCreateArray.Note = that.getView().getModel("Note").getProperty("/note");
            that._saveData(that.oCreateArray);

            oDialog.close();
          }
        }),
        endButton: new Button({
          text: 'İptal',
          press: function() {
            oDialog.close();
          }
        }),
        afterClose: function() {
          oDialog.destroy();
        }
      });

      this._questionHdfFyt(oDialog);

      // oDialog.open();

    },

    _saveData: function(pData) {

      var that = this;
      var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["ZGR_MM_001_FIORI_SRV_01"].uri;
      var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);

      oModel.setHeaders({
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/atom+xml",
        "DataServiceVersion": "2.0",
        "X-CSRF-Token": "Fetch"
      });

      sap.ui.core.BusyIndicator.show();

      oModel.create("/ZLP_SAVESet", pData, {
        success: function(oData, oResponse) {

          sap.ui.core.BusyIndicator.hide();
          var oHeader = that.getView().getModel("Header");
          var aHeaderData = oHeader.getData();

          aHeaderData.VisBut = false;
          aHeaderData.EditList = false;

          oHeader.setData(aHeaderData);
          oHeader.refresh();

          var sCompleteMessage = oResponse.headers["sap-message"];
          var oMessage = JSON.parse(sCompleteMessage);
          var aSuccMessage = oMessage.message.split("++");
          var msg = "";
          for (var k = 0; k < aSuccMessage.length; k++) {
            msg = msg + aSuccMessage[k] + "\n";
          }

          MessageBox.success(msg, {
            onClose: function(sAction) {
              that.onNavBack();
            }
          });

        },
        error: function(oError) {

          sap.ui.core.BusyIndicator.hide();
          var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
          // that.showErrorMessage("Hata", sErrorMessage);
          var aErrorMessage = sErrorMessage.split("++");
          var msg = "";
          for (var k = 0; k < aErrorMessage.length; k++) {
            msg = msg + aErrorMessage[k] + "\n";
          }

          MessageBox.warning(msg);
        }
      });

    },

    // _saveNote: function(){
    //  var oModel = this.getModelAndSetHeaders("ZGR_MM_001_FIORI_SRV_01");

    //  var sGuid = this._sGuid;
    //  var sNote = this.getView().getModel("Note").getProperty("/note");
    //  var oCreate = {};
    //  oCreate.note = sNote;
    //  var sPath = "/SaveNote(guid='" + sGuid + "')";

    //  oModel.update(sPath, oCreate, {
    //    method: "PUT"
    //  });
    // },
    changest2: function(oEvent) {

      var oObject = oEvent.getSource().getBindingContext("Item").getObject();
      var oEbelp = oObject.Ebelp;
      var oState = oEvent.getParameters().state;

      var oModel = this.getOwnerComponent().getModel("Item");
      var aData = oModel.getData();
      for (var i = 0; i < aData.results.length; i++) {
        if (aData.results[i].Ebelp === oEbelp) {

          if (!oState) {
            aData.results[i].Netpr = "";
            aData.results[i].Netpredt = true;
            aData.results[i].Waers = "";
            aData.results[i].Waersedt = true;
          } else {
            aData.results[i].Netpr = aData.results[i].Netpr2;
            aData.results[i].Netpredt = false;
            aData.results[i].Waers = aData.results[i].Waers2;
            aData.results[i].Waersedt = false;
          }

        }
      }

      oModel.setData(aData);
      oModel.refresh();

    },
    changest: function(oEvent) {

      var oObject = oEvent.getSource().getBindingContext("Item").getObject();
      var oEbelp = oObject.Ebelp;
      var oState = oEvent.getParameters().state;

      if (!oState) {
        MessageBox.warning( this.getModel("i18n").getResourceBundle().getText("whyEnter") );
      }

      var oModel = this.getOwnerComponent().getModel("Item");
      var aData = oModel.getData();
      for (var i = 0; i < aData.results.length; i++) {
        if (aData.results[i].Ebelp === oEbelp) {

          aData.results[i].Klmok = oState;

          if (!oState) {
            aData.results[i].Netpr = "";
            aData.results[i].Netpredt = oState;
            aData.results[i].Waers = "";
            aData.results[i].Waersedt = oState;
            aData.results[i].Hdffytedt = oState;
          } else {
            if (aData.results[i].Netpr2var) {
              aData.results[i].Hdffytedt = oState;
            }

            if (aData.results[i].Hdffyt) {
              aData.results[i].Netpr = aData.results[i].Netpr2;
              aData.results[i].Netpredt = false;
              aData.results[i].Waers = aData.results[i].Waers2;
              aData.results[i].Waersedt = false;
            } else {
              aData.results[i].Netpr = aData.results[i].Netpronc;
              aData.results[i].Netpredt = oState;
              aData.results[i].Waers = aData.results[i].Waersonc;
              aData.results[i].Waersedt = oState;
            }

          }

        }
      }

      oModel.setData(aData);
      oModel.refresh();

    },
    // Dosya ekleme
    onFilenameLengthExceed: function() {
      this.showErrorMessage("ucCheckFileName");
    },

    onFileSizeExceed: function() {
      this.showErrorMessage("ucCheckFileSize");
    },

    onUploadTerminated: function() {
      this.showErrorMessage("ucFileUploadFailed");
    },

    onBeforeUploadStarts: function(oEvent) {
      // var sFileName = formatter.replaceTRCharacters(oEvent.getParameter("fileName"));
      var sFileName = oEvent.getParameter("fileName");

      var filename1 = sFileName;
      var filename2 = function makeSortString(s) {
        var translate = {
          "İ": "i",
          "Ş": "S",
          "ş": "s",
          "Ö": "O",
          "ö": "o",
          "Ü": "U",
          "ü": "u",
          "ı": "i",
          "Ç": "C",
          "ç": "c",
          "Ğ": "G",
          "ğ": "g",
          " ": "_"
        };
        var translate_re = /[İŞşÖöÜüıÇçĞğ ]/g;
        return (s.replace(translate_re, function(match) {
          return translate[match];
        }));
      };
      var sFileName = filename2(filename1);

      var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
        name: "slug",
        value: sFileName
      });
      oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
    },

    onUploadChange: function(oEvent) {
      var oHeader = this.getView().getModel("Header").oData;
      var sOrderId = oHeader.Satnum;
      var sServiceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["ZGR_MM_001_FIORI_SRV_01"].uri;
      var sPath = "AttachmentObjSetSet(Ebeln='" + sOrderId + "',AttaId='" + sOrderId + "')/attach";
      // var sPath = "AttachmentObjSetSet(Banfn='" + sOrderId + "',AttaId='" + sOrderId + "')";
      var oUploadCollection = oEvent.getSource();
      oUploadCollection.setUploadUrl(sServiceUrl + sPath);

      var oModel = this.getView().getModel();
      oModel.refreshSecurityToken();
      var oHeaders = oModel.oHeaders;
      var csrfToken = oHeaders['x-csrf-token'];

      var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
        name: "x-csrf-token",
        value: csrfToken
      });
      oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
    },

    onUploadComplete: function(oEvent) {
      var oHeader = this.getView().getModel("Header").oData;
      var sOrderId = oHeader.Ebeln;
      var that = this;
      var sFileName = oEvent.getParameter("files")[0].fileName;
      var sStatus = oEvent.getParameter("files")[0].status;
      var oModel = this.getView().getModel();
      if (sStatus === 201) {
        // this.showSuccessMessage("ucFileUploadSucs", [sFileName]);
        var oUploadCollection = oEvent.getSource();
        // var oTemplate = oUploadCollection.getBindingInfo("items").template;
        // oUploadCollection.unbindAggregation("items");

        var oFilter = [];
        var Ebeln = sOrderId;
        oFilter.push(new Filter("Ebeln", FilterOperator.EQ, Ebeln));
        oModel.read("/DocumentTeklifSet", { 
          filters: oFilter,
          success: function(oData, oResponse) {
         
            that.addAttaRow(oData);

          },
          error: function(oData, oResponse) {
            //execute in case of call fail

          }
        });

      } else {
        this.showErrorMessage("ucFileUploadErr", [sFileName]);
      }

    },

    onFileDeleted: function(oEvent) {
      var that = this;
      var oItem = oEvent.getParameters().item;
      var oObject = oItem.getBindingContext().getObject();

      var sPath = "/AttachmentSet(Ebeln='" + oObject.Matnr + "',AttaId='" + oObject.AttaId + "')";
      this.getView().getModel().remove(sPath, {
        success: function() {},
        error: function(oError) {
          var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
          that.showErrorMessage("loginErrorTitle", sErrorMessage);
        }
      });
    },

    onDataReceivedUC: function(oData) { 
      var iTotalItems = oData.getParameter("data").results.length;
      this._setNumberOfAttachmentsText(iTotalItems);
    },

    _setNumberOfAttachmentsText: function(iTotalItems) { 
      var oUploadCollection = this.getView().byId("uploadCollection");
      var sTitle = this.getResourceBundle().getText("ucAttachTitle", [iTotalItems]);
      oUploadCollection.setNumberOfAttachmentsText(sTitle);
    },

    onCompleteDokuman: function(oEvent) { 
      var list = this.getView().byId("FileList");
      var binding = list.getBinding("items");
      binding.refresh(true);
    },
    onDeleteDocument: function(oEvent) { 
      var oObject = oEvent.getSource().getBindingContext("DataDocument").getObject();
      var oModelDocument2 = this.getOwnerComponent().getModel("DataDocument");
      var aData = oModelDocument2.getData();
    
      for (var i = 0; i < aData.List.length; i++) {
        if (aData.List[i].Line === oObject.Line) {
          aData.List.splice(i, 1);
        }
      }

      oModelDocument2.setData(aData);
      oModelDocument2.refresh();
 
    },
    onChangeDokuman: function(oEvent) {
      var that = this;
     
      var file = oEvent.getParameter("files")[0];
      var BASE64_MARKER = 'data:' + file.type + ';base64,';

      var filename1 = file.name;
      var filename2 = function makeSortString(s) {
        var translate = {
          "İ": "i",
          "Ş": "S",
          "ş": "s",
          "Ö": "O",
          "ö": "o",
          "Ü": "U",
          "ü": "u",
          "ı": "i",
          "Ç": "C",
          "ç": "c",
          "Ğ": "G",
          "ğ": "g",
          " ": "_"
        };
        var translate_re = /[İŞşÖöÜüıÇçĞğ ]/g;
        return (s.replace(translate_re, function(match) {
          return translate[match];
        }));
      };
      var filename = filename2(filename1);
      var reader = new FileReader();
      var that = this;

      reader.onload = (function(theFile) {
        return function(evt) {
          // var oViewModel = that.getView().getModel();
          // oViewModel.setProperty("/busy", true);

          var oModel = that.getOwnerComponent().getModel("DataDocument");
          var aData = oModel.getData();

          var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
          var base64 = evt.target.result.substring(base64Index);
          // *****************************

          var imgdata1 = {
            "Mimetype": BASE64_MARKER,
            "Filename": filename,
            "Content": base64
          };

          var Line = 0;
          
          for (var i = 0; i < aData.List.length; i++) {
            Line = aData.List[i].Line;
          }

          Line = Line + 1;

          var oNewEntry = new Object();
          oNewEntry.__metadata = oModel.getProperty("/0/__metadata");
          oNewEntry.Line = Line;
          oNewEntry.Filename = filename;
          oNewEntry.Filetype = BASE64_MARKER;
          oNewEntry.Filebasedata = base64;
          aData.List.push(oNewEntry);
          oModel.setData(aData);
          oModel.refresh(); 
          var imgdata = JSON.stringify(imgdata1);
 
        };
      })(file);
      // Read in the file as text
      reader.readAsDataURL(file);

    }

  });
});