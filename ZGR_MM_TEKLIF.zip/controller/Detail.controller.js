sap.ui.define([
	"com/tedarik/ZGR_MM_TEKLIF/controller/BaseController",
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/library",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Button"
], function (BaseController, JSONModel, MessageToast, MessageBox, mobileLibrary, Dialog, Label, Button) {
	"use strict";
	var ButtonType = mobileLibrary.ButtonType;
	return BaseController.extend("com.tedarik.ZGR_MM_TEKLIF.controller.Detail", {

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Navigates back to the worklist
		 * @function
		 */
		onNavBack: function () {

			var oModel = this.getOwnerComponent().getModel("Nav");
			var aData = oModel.getData();

			if (aData.Nav === 'C') {
				var Question = 'Kaydetmeden çıkılıyor. Emin misiniz?';

				var that = this;
				var oDialog = new Dialog({
					title: 'Onay',
					type: 'Message',
					content: [
						new Label({
							text: Question,
							labelFor: 'rejectDialogTextarea'
						})
					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: 'Onayla',
						press: function () {
							that.myNavBack("Main");
							oDialog.close();
						}
					}),
					endButton: new Button({
						text: 'İptal',
						press: function () {
							oDialog.close();
						}
					}),
					afterClose: function () {
						oDialog.destroy();
					}
				});

				oDialog.open();
			} else {
				this.myNavBack("Main");
			}
		},

		_deleteRow: function (results) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel("Item");
			var aData = oModel.getData();

			var oModelDetail = this.getOwnerComponent().getModel("ItemDetail");
			var aDataDetail = oModelDetail.getData();

			var Question = 'Kalem listeden silinecektir. Onaylıyor musunuz?';

			var that = this;
			var oDialog = new Dialog({
				title: 'Kalem Sil Onay',
				type: 'Message',
				content: [
					new Label({
						text: Question,
						labelFor: 'rejectDialogTextarea'
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: 'Onayla',
					press: function () {
						// var sText = sap.ui.getCore().byId('rejectDialogTextarea').getValue();
						for (var i = 0; i < aData.results.length; i++) {
							if (aData.results[i].Matnr === aDataDetail.Matnr) {
								aData.results.splice(i, 1);
								that.myNavBack("Main");
							}
						}

						oModel.setData(aData);
						oModel.refresh();
						oDialog.close();
					}
				}),
				endButton: new Button({
					text: 'İptal',
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});

			oDialog.open();

		},

		_saveRow: function (results) {
			var oModel = this.getOwnerComponent().getModel("Item");
			var aData = oModel.getData();
			var oError = "";
			var oModelDetail = this.getOwnerComponent().getModel("ItemDetail");
			var aDataDetail = oModelDetail.getData();

			var oModelCharg = this.getOwnerComponent().getModel("ItemCharg");
			var aDataCharg = oModelCharg.getData();

			var oModelChargDetail = this.getOwnerComponent().getModel("ItemChargDetail");
			var aDataChargDetail = oModelChargDetail.getData();
			var oTotalCharg = 0;

			

			for (var i = 0; i < aDataChargDetail.results.length; i++) {

				if (!parseFloat(aDataChargDetail.results[i].Menge)) {

					if (aDataChargDetail.results[i].Menge !== "" && aDataChargDetail.results[i].Menge !== "0") {
						oError = 'X';
					} else {
						// oError = "";
						if (aDataChargDetail.results[i].Menge === "") {
							aDataChargDetail.results[i].Menge = 0;
						}
						oTotalCharg = parseFloat(oTotalCharg) + parseFloat(aDataChargDetail.results[i].Menge);
					}

				} else {

					if (aDataChargDetail.results[i].Menge === "") {
						aDataChargDetail.results[i].Menge = 0;
					}
					oTotalCharg = parseFloat(oTotalCharg) + parseFloat(aDataChargDetail.results[i].Menge);

				}

			}

			if (oError === "") {

				if (parseFloat(oTotalCharg) > parseFloat(aDataDetail.Menge)) {
					aDataDetail.Nmenge = "";
					// oModelDetail.refresh();
					MessageBox.warning("Kabul miktarı açık sipariş miktarından büyük girilemez.");
				} else {
					aDataDetail.Nmenge = oTotalCharg;
					for (var i = 0; i < aData.results.length; i++) {
						if (aData.results[i].Matnr === aDataDetail.Matnr) {
							if (aDataDetail.Nmenge === "") {
								aDataDetail.Nmenge = "0";
							} else {
								aData.results[i].Nmenge = oTotalCharg;
							}

							for (var k = 0; k < aDataChargDetail.results.length; k++) {

								for (var j = 0; j < aDataCharg.results.length; j++) {
									if (aDataCharg.results[j].Matnr === aDataChargDetail.results[k].Matnr &&
										aDataCharg.results[j].Charg === aDataChargDetail.results[k].Charg)

										aDataCharg.results[j].Menge = aDataChargDetail.results[k].Menge;

								}

							}

							aData.results[i].Nmeins = aDataDetail.Nmeins;
							oModel.refresh();
							this.myNavBack("Main");
						}
					}
				}
			} else {
				aDataDetail.Nmenge = "";
				oModelDetail.refresh();
				MessageBox.warning("Hatalı miktar girişi.");
			}

		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the post path.
		 *
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onPostMatched: function (oEvent) {
			var oViewModel = this.getModel("postView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: "/Posts('" + oEvent.getParameter("arguments").postId + "')",
				events: {
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		}

	});

});