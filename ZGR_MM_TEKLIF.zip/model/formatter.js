sap.ui.define([], function() {
	"use strict";

	return {
		replaceTRCharacters: function(sText) {
			var iMaxLength = 50;
			
			sText = sText.replaceAll("ü", "u");
			sText = sText.replaceAll("ı", "i");
			sText = sText.replaceAll("ö", "o");
			sText = sText.replaceAll("ş", "s");
			sText = sText.replaceAll("ğ", "g");
			sText = sText.replaceAll("ç", "c");
			sText = sText.replaceAll("Ü", "U");
			sText = sText.replaceAll("İ", "I");
			sText = sText.replaceAll("Ö", "O");
			sText = sText.replaceAll("Ş", "S");
			sText = sText.replaceAll("Ğ", "G");
			sText = sText.replaceAll("Ç", "C");
			sText = sText.replaceAll(" ", "_");

			if (sText.length > iMaxLength) {
				sText = sText.substring(0, iMaxLength);
			}
			return sText;
		}
	};

});