sap.ui.define([
	"com/tedarik/ZGR_MM_TEKLIF/test/unit/controller/Main.controller"
], function () {
	"use strict";
});