sap.ui.define([
	"com/bozankaya/zbz_pp_urun_agaci2/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, Fragment, Filter, FilterOperator, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("com.bozankaya.zbz_pp_urun_agaci2.controller.App", {

		onInit: function() {
			var that = this;
			var oModel = this.getView().getModel();
			var sPathWerks = "/WerksShSet";
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});

			oModel.read(sPathWerks, {
				success: function(oData) {
					var JsonWerksShSet = new JSONModel();
					JsonWerksShSet.setSizeLimit(999999);
					JsonWerksShSet.setData(oData.results);
					sap.ui.getCore().setModel(JsonWerksShSet, "WerksShSet");
					that.getView().setModel(JsonWerksShSet, "WerksShSet");
					// that.getOwnerComponent().setModel(jsonGorusmeTextSet, "GorusmeTextSet");
				},
				error: function(oData) {

				}
			});
			var sPathMatkl = "/MatklShSet";
			oModel.read(sPathMatkl, {
				success: function(oData) {
					var JsonMatklShSet = new JSONModel();
					JsonMatklShSet.setSizeLimit(999999);
					JsonMatklShSet.setData(oData.results);
					sap.ui.getCore().setModel(JsonMatklShSet, "MatklShSet");
					that.getView().setModel(JsonMatklShSet, "MatklShSet");
					// that.getOwnerComponent().setModel(jsonGorusmeTextSet, "GorusmeTextSet");
				},
				error: function(oData) {

				}
			});
			var sPathArac = "/AracShSet";
			oModel.read(sPathArac, {
				success: function(oData) {
					var JsonAracShSet = new JSONModel();
					JsonAracShSet.setSizeLimit(999999);
					JsonAracShSet.setData(oData.results);
					sap.ui.getCore().setModel(JsonAracShSet, "AracShSet");
					that.getView().setModel(JsonAracShSet, "AracShSet");
					// that.getOwnerComponent().setModel(jsonGorusmeTextSet, "GorusmeTextSet");
				},
				error: function(oData) {

				}
			});
			var sPathDip = "/DipShSet";
			oModel.read(sPathDip, {
				success: function(oData) {
					var JsonDipShSet = new JSONModel();
					JsonDipShSet.setSizeLimit(999999);
					JsonDipShSet.setData(oData.results);
					sap.ui.getCore().setModel(JsonDipShSet, "DipShSet");
					that.getView().setModel(JsonDipShSet, "DipShSet");
					// that.getOwnerComponent().setModel(jsonGorusmeTextSet, "GorusmeTextSet");
				},
				error: function(oData) {

				}
			});

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.getView().byId('idUrunAgacTable').setVisible(false);
		},

		onSearchall: function(oEvent) {
			var aFilter = [];
			var that = this;
			var oModel = this.getView().getModel();
			var sPath = "/UrunAgacSet";
			if (oEvent.getParameters().selectionSet[0].getValue()) {
				aFilter.push(new Filter("Matnr", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[0].getValue()));
			}
			if (oEvent.getParameters().selectionSet[1].getSelectedKey()) {
				aFilter.push(new Filter("Matkl", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[1].getSelectedKey()));
			}
			if (oEvent.getParameters().selectionSet[2].getSelectedKey()) {
				aFilter.push(new Filter("Zzaractipi", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[2].getSelectedKey()));
			}
			if (oEvent.getParameters().selectionSet[3].getSelectedKey()) {
				aFilter.push(new Filter("Dispo", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[3].getSelectedKey()));
			}
			if (oEvent.getParameters().selectionSet[4].getValue()) {
				aFilter.push(new Filter("Datuv", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[4].getValue()));
			}
			if (oEvent.getParameters().selectionSet[5].getValue()) {
				aFilter.push(new Filter("Bmeng", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[5].getValue()));
			}
			if (oEvent.getParameters().selectionSet[6].getValue()) {
				aFilter.push(new Filter("Maxst", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[6].getValue()));
			}
			if (oEvent.getParameters().selectionSet[7].getSelectedKey()) {
				aFilter.push(new Filter("Werks", sap.ui.model.FilterOperator.EQ, oEvent.getParameters().selectionSet[7].getSelectedKey()));
			}
			if (aFilter.length > 0) {
				this.getView().byId('idUrunAgacTable').setVisible(true);
				
				this.getTable().bindRows({
					path: sPath
				});
			
				var oList = this.getView().byId("idUrunAgacTable");
				var oBinding = oList.getBinding("rows");
				oBinding.filter(aFilter, "Application");

			} else {

				MessageBox.error("Zorunlu Filtreleri Giriniz.");
			}

		},
		getTable: function() {
			return this.byId("idUrunAgacTable");
		},
		onSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Matnr", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilter]);
		},
		onDialogClose: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				MessageToast.show("You have chosen " + aContexts.map(function(oContext) {
					return oContext.getObject().Name;
				}).join(", "));
			} else {
				MessageToast.show("No new item was selected.");
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		onValueHelpRequest: function() {
			var oView = this.getView();

			if (!this._pValueHelpDialog) {
				this._pValueHelpDialog = Fragment.load({
					id: oView.getId(),
					name: "com.bozankaya.zbz_pp_urun_agaci2.view.MatnrValueHelp",
					controller: this
				}).then(function(oValueHelpDialog) {
					oView.addDependent(oValueHelpDialog);
					return oValueHelpDialog;
				});
			}
			this._pValueHelpDialog.then(function(oValueHelpDialog) {
				this._configValueHelpDialog();
				oValueHelpDialog.open();
			}.bind(this));
		},
		_configValueHelpDialog: function() {

			var sInputValue = this.byId("MatnrInput").getValue(),
				oModel = this.getView().getModel(),
				aProducts = oModel.getProperty("/MatnrShSet");

		},
		onValueHelpDialogClose: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem"),
				oInput = this.byId("MatnrInput");

			if (!oSelectedItem) {
				oInput.resetProperty("value");
				return;
			}

			oInput.setValue(oSelectedItem.getTitle());
		}

	});

});