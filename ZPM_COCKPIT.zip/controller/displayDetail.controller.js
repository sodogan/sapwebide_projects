sap.ui.define([
	"ZVESTELPM1/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"ZVESTELPM1/model/formatter"
], function (BaseController, Controller, JSONModel, Filter, MessageBox, formatter) {
	"use strict";

	return BaseController.extend("ZVESTELPM1.controller.displayDetail", {
		formatter: formatter,

		onInit: function () {
			// var params = vm.getItems();
			// var oModel = this.getView().getModel("vModel");

			this.getRouter().getRoute("displayDetail").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			var model = this.getModel("mainModel");
			var name = oEvent.getParameter("name");
			if (name === "displayDetail") {
				var arg = oEvent.getParameter("arguments");
				model.setProperty("/qmnumDetail", arg);
				this.getInit(arg.Qmnum);
				//this.getUrunAgaciList(this.getOwnerComponent().getModel("mainModel").getProperty("/Qmnum"));
			}
		},

		getInit: function (arg) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			
			var oEntry = "/NotifDetailGeneralInfoGetSet(Qmnum='" + arg + "')";
			model.setProperty("/flag", true);
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function (oData, oResponse) {
					model.setProperty("/genelTabDetail", oData);
					//var siparisDurum = oData.JTxt04 +"-"+ oData.JTxt30;
					//model.setProperty("/notifHeader/siparis",siparisDurum);
					that.getView().byId("cb_orderStatuDetail").setSelectedKey(oData.JTxt04);
					that.getView().byId("idFaaliyetDetail").setSelectedKey(oData.Qmgrp);
					if (oData.Qmgrp !== "") {
						that.FaaliyetCodeChange(oData.Qmgrp);
					}
					that.getView().byId("idFaaliyetCodeDetail").setSelectedKey(oData.Qmcod);

					var oEntry = "/getFecodUrcodListForQmnumSet";
					oDataModel.read(oEntry, {
						filters: [
							new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, arg)
						],
						success: function (oData, oResponse) {
							model.setProperty("/ConsumeVisibleLastConfirmation", true);
							model.setProperty("/ConsumeCollectionLastConfirmation", "");
							model.setProperty("/ConsumeCollectionLastConfirmation", oData.results);
							model.setProperty("/flag", false);
							sap.ui.core.BusyIndicator.hide(0);
						},
						failed: function (oError) {
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

					sap.ui.core.BusyIndicator.hide(0);
					model.setProperty("/flag", false);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDefinationGetSet", {
				filters: [
					new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, arg)
				],
				success: function (oData, oResponse) {
					var text = "";
					for (var i = 0; i < oData.results.length; i++) {
						text = text + oData.results[i].Tdline;
						model.setProperty("/tdLine", text);
					}
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			var filterQkatart = new sap.ui.model.Filter("Qkatart", sap.ui.model.FilterOperator.EQ, "U");
			var filters = new Array();
			filters.push(filterQkatart);

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: filters,
				success: function (oData, oResponse) {
					model.setProperty("/notifDetailGeneralInfoActivityCodeLisSet", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
			//Aufnr parametresi eklendikten sonra burada ki kod aktif edilecektir.
			/*			var filterSipDurum = new sap.ui.model.Filter("IvAufnr", sap.ui.model.FilterOperator.EQ, aufnr); 
						var filter = new Array();
						filter.push(filterSipDurum);

						sap.ui.core.BusyIndicator.show(0);
						oDataModel.read("/sipDurumListSet", {
							filters: filter,
							success: function(oData, oResponse) {
								model.setProperty("/sipDurumList", oData.results);
								sap.ui.core.BusyIndicator.hide(0);

							},
							failed: function(oError) {
								sap.ui.core.BusyIndicator.hide(0);
							}
						});*/
		},

		FaaliyetCodeChange: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var flag = oModel.getProperty("/flag");
			var oDataModel = this.getOwnerComponent().getModel();
			// var fragmentId= this.getView().createId("idConfim");
			// var comboBox= sap.ui.core.Fragment.byId(fragmentId,"idDamageCode");
			var val = "";
			if (flag == false || oEvent.length == undefined) {
				val = oEvent.getSource().getSelectedKey();
			} else {
				val = oEvent;
			}

			var f = [];
			f.push(new Filter("Group", "EQ", val));
			f.push(new Filter("Qkatart", "EQ", "A"));

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: f,
				success: function (oData, oResponse) {
					oModel.setProperty("/faaliyetDetail", oData.results);
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},

		// 		//CheckList Ekranına geçiş sağlanır.
		onChecklist: function () {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var aufnr = oModel.getProperty("/notifHeader/Aufnr");
			var qmart = oModel.getProperty("/notifHeader/Qmart");

			//if (qmart !== "B2" && qmart !== "B5" && qmart !== "B6") {
			if (qmart !== "X2" ) {
				MessageBox.alert(
					"Sadece planlı bakım(B2), Önly./Kestrmci Bakım(B5) ve Kalibrasyon (B6)türündeki bildirimler için kontrol listesi işlenebilir!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (aufnr === "") {
				MessageBox.alert("Siparişe dönüştürülmemiş bildirimlerde kontrol listesi işlenemez!", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Hata"
				});

				return;
			}

			this.getRouter().navTo("checkList", {
				Aufnr: aufnr
			});
		},

		handleIconTabBarSelect: function (oEvent) {

			switch (oEvent.getSource().getSelectedKey()) {
			case "genelBilgilerDetail":
				this.getGenelBilgiler();
				break;
			case "zamanDevirDetail":
				this.getZamanDevir();
				break;
			case "aktiviteDetail":
				this.getAktivite();
				break;
			case "malzemeDetail":
				this.getMalzeme();
				break;
			case "checkListDetail":
				this.getDOFList();
				break;
				// case "bakimOnerileri":

				// 	break;
				// case "sonBakimlar":
				// 	this.getsonBakimlar();
				// 	break;
			}
		},

		//Genel Bilgiler İconTab tıklandığında çalıştırılır. 
		getGenelBilgiler: function (oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/qmnumDetail").Qmnum;

			var oEntry = "/NotifDetailGeneralInfoGetSet(Qmnum='" + qmnum + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function (oData, oResponse) {
					model.setProperty("/genelTabDetail", oData);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDefinationGetSet", {
				filters: [
					new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
				],
				success: function (oData, oResponse) {
					var text = "";
					for (var i = 0; i < oData.results.length; i++) {
						text = text + oData.results[i].Tdline;
						model.setProperty("/tdLineDetail", text);
					}
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getZamanDevir: function (oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/qmnumDetail").Qmnum;

			var oEntry = "/notifDateTimeDetailsSet(Qmnum='" + qmnum + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function (oData, oResponse) {
					model.setProperty("/zamanTabDetail", oData);
					model.setProperty("/zamanTabDetail/Auztv", formatter.formatTime(oData.Auztv.ms));
					model.setProperty("/zamanTabDetail/Mzeit", formatter.formatTime(oData.Mzeit.ms));
					model.setProperty("/zamanTabDetail/Zstime", formatter.formatTime(oData.Zstime.ms));
					model.setProperty("/zamanTabDetail/Zetime", formatter.formatTime(oData.Zetime.ms));
					sap.ui.core.BusyIndicator.hide(0);
					that.getZamanDevirTable();
				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},
		//Detay sayfasında bu alan gözükmeyecektir.
		/*		damageCodeChange1: function(oEvent) {
					var	val = oEvent.getSource().getSelectedKey();
					var model = this.getModel("mainModel");
					var oDataModel = this.getOwnerComponent().getModel();
					
					var filterQkatart = new sap.ui.model.Filter("Qkatart", sap.ui.model.FilterOperator.EQ, "U");
					var filterCode = new sap.ui.model.Filter("Group", sap.ui.model.FilterOperator.EQ, val); 
					
					var filters = new Array();
					filters.push(filterQkatart);
					filters.push(filterCode);
					

					sap.ui.core.BusyIndicator.show(0);
					oDataModel.read("/oteilUrcodListSet", {
						filters: filters,
						success: function(oData, oResponse) {
							model.setProperty("/oteilUrcodListSet", oData.results);
							sap.ui.core.BusyIndicator.hide(0);

						},
						failed: function(oError) {
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

				},*/

		//Zaman Devir içerisinde ki işi devretme tablosu verileri doldurulur.
		getZamanDevirTable: function () {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/qmnumDetail").Qmnum;

			var filterQmnum = new sap.ui.model.Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum); //
			var filters = new Array();
			filters.push(filterQmnum);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifWorkcenterChangeforwardDetailLists", {
				filters: filters,
				success: function (oData, oResponse) {
					model.setProperty("/IsiDevretListDetail", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//AUFNR parametresi eklendiğinde çalıştırılacaktır.
		//Aktivite içerisinde ki işi devretme tablosu verileri doldurulur.
		getAktivite: function () {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/qmnumDetail").Aufnr;

			var filterAufnr = new sap.ui.model.Filter("Aufnr", sap.ui.model.FilterOperator.EQ, aufnr);
			var filters = new Array();
			filters.push(filterAufnr);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailActivitiesListGetSet", {
				filters: filters,
				success: function (oData, oResponse) {
					model.setProperty("/aktiviteListDetail", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//Aufnr parametresi gerekli
		getMalzeme: function () {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/qmnumDetail").Aufnr;

			var filterAufnr = new sap.ui.model.Filter("Aufnr", sap.ui.model.FilterOperator.EQ, aufnr);
			var filters = new Array();
			filters.push(filterAufnr);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailComsuptionGetListSet", {
				filters: filters,
				success: function (oData, oResponse) {
					model.setProperty("/malzemeListDetail", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getCheckList: function () {
			// var that = this;
			// var model = this.getModel("mainModel");
			// var oDataModel = this.getOwnerComponent().getModel();
			// var qmnum = model.getProperty("/notifHeader/Qmnum");

			// var filterAufnr = new sap.ui.model.Filter("QmnumIn", sap.ui.model.FilterOperator.EQ, qmnum);
			// var filters = new Array();
			// filters.push(filterAufnr);

			// sap.ui.core.BusyIndicator.show(0);
			// oDataModel.read("/lastTenNotifForEquipSet", {
			// 	filters: filters,
			// 	success: function(oData, oResponse) {
			// 		model.setProperty("/checkList", oData.results);
			// 		sap.ui.core.BusyIndicator.hide(0);

			// 	},
			// 	failed: function(oError) {
			// 		that.console.log(oError);
			// 		sap.ui.core.BusyIndicator.hide(0);
			// 	}
			// });

		},
		//Aufnr gerekli
		getDOFList: function () {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/qmnumDetail").Aufnr;

			var oEntry = "/checklistCreNotifDofSet(Aufnr='" + aufnr + "')";

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function (oData, oResponse) {
					model.setProperty("/dofDetail", oData);
					if (oData.Success == "") {
						MessageBox.alert(
							oData.Message, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Bilgi"
							}
						);

					}

					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},

		/*		getBakimOnerileri: function() {
					var that = this;
					var model = this.getModel("mainModel");
					var oDataModel = this.getOwnerComponent().getModel();
					//var qmnum = model.getProperty("/notifHeader/Qmnum");
					var qmgrp = this.getView().byId("idDamageDetay").getSelectedKey();
					var qmcod = this.getView().byId("idDamageCodeDetay").getSelectedKey();

					var filterQmgrp = new sap.ui.model.Filter("Qmgrp", sap.ui.model.FilterOperator.EQ, qmgrp);
					var filterQmcod = new sap.ui.model.Filter("Qmcod", sap.ui.model.FilterOperator.EQ, qmcod);
					var filters = new Array();
					filters.push(filterQmgrp);
					filters.push(filterQmcod);

					sap.ui.core.BusyIndicator.show(0);
					oDataModel.read("/damageCodeInstListSet", {
						filters: filters,
						success: function(oData, oResponse) {
							model.setProperty("/bakimOneri", oData.results);
							sap.ui.core.BusyIndicator.hide(0);

						},
						failed: function(oError) {
							that.console.log(oError);
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

				},

				getsonBakimlar: function() {
					var that = this;
					var model = this.getModel("mainModel");
					var oDataModel = this.getOwnerComponent().getModel();
					var qmnum = model.getProperty("/notifHeader/Qmnum");

					var filterAufnr = new sap.ui.model.Filter("QmnumIn", sap.ui.model.FilterOperator.EQ, qmnum);
					var filters = new Array();
					filters.push(filterAufnr);

					sap.ui.core.BusyIndicator.show(0);
					oDataModel.read("/lastTenNotifForEquipSet", {
						filters: filters,
						success: function(oData, oResponse) {
							model.setProperty("/sonBakimList", oData.results);
							sap.ui.core.BusyIndicator.hide(0);

						},
						failed: function(oError) {
							that.console.log(oError);
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

				},*/

		// onNavBack: function(oEvent) {
		// 	this.onClear();

		// },

		onClear: function () {
			var model = this.getModel("mainModel");
			model.setProperty("/notifHeader", "");
			model.setProperty("/genelTab", "");
			model.setProperty("/aktiviteList", []);
			model.setProperty("/zamanTab", "");
			model.setProperty("/IsiDevretList", []);
			model.setProperty("/malzemeList", []);
			//model.setProperty("/checkList", []);
			model.setProperty("/dof", "");
			model.setProperty("/bakimOneriStr", "");
			model.setProperty("/bakimOneri", []);
			model.setProperty("/tdLine", []);

		}

	});

});