sap.ui.define([
	"ZVESTELPM1/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"ZVESTELPM1/model/formatter"
], function(BaseController, Controller, JSONModel, Filter, MessageBox, formatter) {
	"use strict";

	return BaseController.extend("ZVESTELPM1.controller.S2", {
		formatter: formatter,

		onInit: function() {
			// var params = vm.getItems();
			// var oModel = this.getView().getModel("vModel");

			this.getRouter().getRoute("s2").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function(oEvent) {
			//this.onClear();
			var name = oEvent.getParameter("name");
			var oIconTabBar = this.getView().byId("iconTabBar");
			oIconTabBar.setSelectedKey("genelBilgiler");
			if (name === "s2") {

				this.getInit();
				this.getOwnerComponent().getModel("global").setProperty("/detailView", true);
				//this.getUrunAgaciList(this.getOwnerComponent().getModel("mainModel").getProperty("/Qmnum"));
			}
		},

		getInit: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var oEntry = "/NotifDetailGeneralInfoGetSet(Qmnum='" + qmnum + "')";
			model.setProperty("/flag", true);
			var empty = "";
			model.setProperty("/genelTab", empty);

			var qmart = model.getProperty("/notifHeader/Qmart");
			var cList = "B2,B5,B6";
			if (cList.indexOf(qmart) !== -1) {
				this.byId("iconTabBarFilter5").setVisible(true);
			} else {
				this.byId("iconTabBarFilter5").setVisible(false);
			}

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					model.setProperty("/genelTab", oData);
					var siparisDurum = oData.JTxt04 + "-" + oData.JTxt30;
					model.setProperty("/notifHeader/siparis", siparisDurum);
					that.getView().byId("idFaaliyet").setSelectedKey(oData.Qmgrp);
					if (oData.Qmgrp !== "") {
						that.FaaliyetCodeChange(oData.Qmgrp);
					}
					that.getView().byId("idFaaliyetCode").setSelectedKey(oData.Qmcod);

					var oEntry = "/getFecodUrcodListForQmnumSet";
					oDataModel.read(oEntry, {
						filters: [
							new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
						],
						success: function(oData, oResponse) {
							model.setProperty("/ConsumeVisibleLastConfirmation", true);
							model.setProperty("/ConsumeCollectionLastConfirmation", "");
							model.setProperty("/ConsumeCollectionLastConfirmation", oData.results);
							model.setProperty("/flag", false);
							sap.ui.core.BusyIndicator.hide(0);
						},
						failed: function(oError) {
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDefinationGetSet", {
				filters: [
					new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
				],
				success: function(oData, oResponse) {
					var empty = "";
					model.setProperty("/tdLine", empty);
					var text = "";
					for (var i = 0; i < oData.results.length; i++) {
						text = text + oData.results[i].Tdline;
						model.setProperty("/tdLine", text);
					}
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			// var filterSipDurum = new sap.ui.model.Filter("IvAufnr", sap.ui.model.FilterOperator.EQ, aufnr); 
			// var filter = new Array();
			// filter.push(filterSipDurum);

			// sap.ui.core.BusyIndicator.show(0);
			// oDataModel.read("/sipDurumListSet", {
			// 	filters: filter,
			// 	success: function(oData, oResponse) {
			// 		model.setProperty("/sipDurumList", oData.results);
			// 		sap.ui.core.BusyIndicator.hide(0);

			// 	},
			// 	failed: function(oError) {
			// 		sap.ui.core.BusyIndicator.hide(0);
			// 	}
			// });
		},

		FaaliyetCodeChange: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var flag = oModel.getProperty("/flag");
			var oDataModel = this.getOwnerComponent().getModel();
			// var fragmentId= this.getView().createId("idConfim");
			// var comboBox= sap.ui.core.Fragment.byId(fragmentId,"idDamageCode");
			var val = "";
			if (flag == false || oEvent.length == undefined) {
				val = oEvent.getSource().getSelectedKey();
			} else {
				val = oEvent;
			}

			var f = [];
			f.push(new Filter("Group", "EQ", val));
			f.push(new Filter("Qkatart", "EQ", "A"));

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: f,
				success: function(oData, oResponse) {
					oModel.setProperty("/faaliyet", oData.results);
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},

		faaliyetCodeUpdate: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var qmgrp = this.getView().byId("idFaaliyet").getSelectedKey();
			var qmcod = this.getView().byId("idFaaliyetCode").getSelectedKey();

			var oEntry = "/notifActivityTypeChangeSet(Qmcod='" + qmcod + "',Qmgrp='" + qmgrp + "',Qmnum='" + qmnum + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					MessageBox.alert(
						oData.Message, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}
					);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//CheckList Ekranına geçiş sağlanır.
		onChecklist: function() {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var aufnr = oModel.getProperty("/notifHeader/Aufnr");
			var qmart = oModel.getProperty("/notifHeader/Qmart");

			//if (qmart !== "B2" && qmart !== "B5" && qmart !== "B6") {
			if (qmart !== "X2") {
				MessageBox.alert(
					"Sadece planlı bakım(B2), Önly./Kestrmci Bakım(B5) ve Kalibrasyon (B6)türündeki bildirimler için kontrol listesi işlenebilir!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (aufnr === "") {
				MessageBox.alert("Siparişe dönüştürülmemiş bildirimlerde kontrol listesi işlenemez!", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Hata"
				});

				return;
			}

			this.getRouter().navTo("checkList", {
				Aufnr: aufnr
			});
		},

		handleIconTabBarSelect: function(oEvent) {

			switch (oEvent.getSource().getSelectedKey()) {
				case "genelBilgiler":
					this.getGenelBilgiler();
					break;
				case "zamanDevir":
					this.getZamanDevir();
					break;
				case "aktivite":
					this.getAktivite();
					break;
				case "malzeme":
					this.getMalzeme();
					break;
				case "checkList":
					this.getDOFList();
					break;
				case "bakimOnerileri":
					this.getBakimOnerileri();
					break;
				case "sonBakimlar":
					this.getsonBakimlar();
					break;
				case "Dokumanlar":
					this.getDokumanlar();
					break;
			}
		},

		//Genel Bilgiler İconTab tıklandığında çalıştırılır. 
		getGenelBilgiler: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			model.setProperty("/flag", true);

			var oEntry = "/NotifDetailGeneralInfoGetSet(Qmnum='" + qmnum + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					model.setProperty("/genelTab", oData);
					that.getView().byId("idFaaliyet").setSelectedKey(oData.Qmgrp);
					if (oData.Qmgrp !== "") {
						that.FaaliyetCodeChange(oData.Qmgrp);
					}
					that.getView().byId("idFaaliyetCode").setSelectedKey(oData.Qmcod);

					var oEntry = "/getFecodUrcodListForQmnumSet";
					oDataModel.read(oEntry, {
						filters: [
							new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
						],
						success: function(oData, oResponse) {
							model.setProperty("/ConsumeVisibleLastConfirmation", true);
							model.setProperty("/ConsumeCollectionLastConfirmation", "");
							model.setProperty("/ConsumeCollectionLastConfirmation", oData.results);
							model.setProperty("/flag", false);
							sap.ui.core.BusyIndicator.hide(0);
						},
						failed: function(oError) {
							sap.ui.core.BusyIndicator.hide(0);
						}
					});

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDefinationGetSet", {
				filters: [
					new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
				],
				success: function(oData, oResponse) {
					var text = "";
					for (var i = 0; i < oData.results.length; i++) {
						text = text + oData.results[i].Tdline;
						model.setProperty("/tdLine", text);
					}
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getZamanDevir: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");

			var oEntry = "/notifDateTimeDetailsSet(Qmnum='" + qmnum + "')";
			//	sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					model.setProperty("/zamanTab", oData);
					model.setProperty("/zamanTab/Auztv", formatter.formatTime(oData.Auztv.ms));
					model.setProperty("/zamanTab/Mzeit", formatter.formatTime(oData.Mzeit.ms));
					model.setProperty("/zamanTab/Zstime", formatter.formatTime(oData.Zstime.ms));
					model.setProperty("/zamanTab/Zetime", formatter.formatTime(oData.Zetime.ms));
					sap.ui.core.BusyIndicator.hide(0);
					that.getZamanDevirTable();
				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		damageCodeChange1: function(oEvent) {
			var val = oEvent.getSource().getSelectedKey();
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();

			var filterQkatart = new sap.ui.model.Filter("Qkatart", sap.ui.model.FilterOperator.EQ, "C");
			var filterCode = new sap.ui.model.Filter("Group", sap.ui.model.FilterOperator.EQ, val);

			var filters = new Array();
			filters.push(filterQkatart);
			filters.push(filterCode);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/notifDetailGeneralInfoActivityCodeLisSet", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//Zaman Devir içerisinde ki işi devretme tablosu verileri doldurulur.
		getZamanDevirTable: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");

			var filterQmnum = new sap.ui.model.Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum); //
			var filters = new Array();
			filters.push(filterQmnum);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifWorkcenterChangeForwardDetailLisSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/IsiDevretList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//Aktivite içerisinde ki işi devretme tablosu verileri doldurulur.
		getAktivite: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/notifHeader/Aufnr");

			var filterAufnr = new sap.ui.model.Filter("Aufnr", sap.ui.model.FilterOperator.EQ, aufnr);
			var filters = new Array();
			filters.push(filterAufnr);

			//			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailActivitiesListGetSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/aktiviteList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getMalzeme: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/notifHeader/Aufnr");

			var filterAufnr = new sap.ui.model.Filter("Aufnr", sap.ui.model.FilterOperator.EQ, aufnr);
			var filters = new Array();
			filters.push(filterAufnr);

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailComsuptionGetListSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/malzemeList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},
		getCheckList: function() {
			// var that = this;
			// var model = this.getModel("mainModel");
			// var oDataModel = this.getOwnerComponent().getModel();
			// var qmnum = model.getProperty("/notifHeader/Qmnum");

			// var filterAufnr = new sap.ui.model.Filter("QmnumIn", sap.ui.model.FilterOperator.EQ, qmnum);
			// var filters = new Array();
			// filters.push(filterAufnr);

			// sap.ui.core.BusyIndicator.show(0);
			// oDataModel.read("/lastTenNotifForEquipSet", {
			// 	filters: filters,
			// 	success: function(oData, oResponse) {
			// 		model.setProperty("/checkList", oData.results);
			// 		sap.ui.core.BusyIndicator.hide(0);

			// 	},
			// 	failed: function(oError) {
			// 		that.console.log(oError);
			// 		sap.ui.core.BusyIndicator.hide(0);
			// 	}
			// });

		},
		getDOFList: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/notifHeader/Aufnr");

			// var oEntry = "/checklistCreNotifDofSet(Aufnr='" + aufnr + "')";

			// //	sap.ui.core.BusyIndicator.show(0);
			// oDataModel.read(oEntry, {
			// 	success: function (oData, oResponse) {
			// 		model.setProperty("/dof", oData);
			// 		if (oData.Success == "") {
			// 			MessageBox.alert(
			// 				oData.Message, {
			// 					icon: sap.m.MessageBox.Icon.ERROR,
			// 					title: "Bilgi"
			// 				}
			// 			);

			// 		}

			// 		sap.ui.core.BusyIndicator.hide(0);

			// 	},
			// 	failed: function (oError) {
			// 		that.console.log(oError);
			// 		sap.ui.core.BusyIndicator.hide(0);
			// 	}
			// });
		},

		getBakimOnerileri: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			this.getView().byId("idDamageDetay").setSelectedKey("");
			this.getView().byId("idDamageCodeDetay").setSelectedKey("");

			var filterQkatart = new sap.ui.model.Filter("Qkatart", sap.ui.model.FilterOperator.EQ, "C");
			var filters = new Array();
			filters.push(filterQkatart);

			//	sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/orderCompleteDamageListGetSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/OrderCompleteDamageListGetSet", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getTalimat: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			//var qmnum = model.getProperty("/notifHeader/Qmnum");
			var qmgrp = this.getView().byId("idDamageDetay").getSelectedKey();
			var qmcod = this.getView().byId("idDamageCodeDetay").getSelectedKey();

			var filterQmgrp = new sap.ui.model.Filter("Qmgrp", sap.ui.model.FilterOperator.EQ, qmgrp);
			var filterQmcod = new sap.ui.model.Filter("Qmcod", sap.ui.model.FilterOperator.EQ, qmcod);
			var filters = new Array();
			filters.push(filterQmgrp);
			filters.push(filterQmcod);

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/instructionListForDamageCodeSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/bakimOneri", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getsonBakimlar: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");

			var filterAufnr = new sap.ui.model.Filter("QmnumIn", sap.ui.model.FilterOperator.EQ, qmnum);
			var filters = new Array();
			filters.push(filterAufnr);

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailLastTenNotifForEquipmentGeSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/sonBakimList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		getDokumanlar: function() {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");

			var filterQmnum = new sap.ui.model.Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum);
			var filters = new Array();
			filters.push(filterQmnum);

			oDataModel.read("/NotifDetailDocumentListGetSet", {
				filters: filters,
				success: function(oData, oResponse) {
					model.setProperty("/documentList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		onUpdateOrderStat: function(oEvent) {
			var that = this;
			var stat = this.getView().byId("cb_orderStatu").getSelectedKey();
			var updateStat = this.getView().byId("cb_orderStatu").getValue();
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var dest = "X";

			var oEntry = "/orderUserStatusChangeSet(Aufnr='" + aufnr + "',StatDrm='" + stat + "',Dest='" + dest + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, response) {
					//var returnList = oData.NavUpdateReturn.results;
					if (oData.Message !== "X") {
						MessageBox.alert(
							"İşlem gerçekleşmedi!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Hata"
							}
						);

					} else {

						model.setProperty("/notifHeader/siparis", updateStat);
					}

					sap.ui.core.BusyIndicator.hide(0);

				},
				error: function(oError) {
					var errMessage = JSON.parse(oError.responseText);
					sap.ui.core.BusyIndicator.hide(0);

				}
			});

		},

		onAciklamaKaydet: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var aciklama = model.getProperty("/genelTab/Defination");

			var oEntry = {
				Qmnum: qmnum,
				Aciklama: aciklama
			};
			var oEntry = "/notifDefinationChangeSet(Qmnum='" + qmnum + "',Aciklama='" + aciklama + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					MessageBox.alert(
						oData.Message, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}
					);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		onDetailBakim: function(oEvent) {
			//var qmnum = oEvent.getSource().mProperties.text;
			var model = this.getModel("mainModel");
			var qmnum = oEvent.getSource().getBindingContext("mainModel").getProperty("Qmnum");
			var aufnr = oEvent.getSource().getBindingContext("mainModel").getProperty("Aufnr");

			model.setProperty("/detailHeader", {
				Qmnum: oEvent.getSource().getBindingContext("mainModel").getProperty("Qmnum"),
				Aufnr: oEvent.getSource().getBindingContext("mainModel").getProperty("Aufnr"),
				Qmtxt: oEvent.getSource().getBindingContext("mainModel").getProperty("Qmtxt"),
				Qmartx: oEvent.getSource().getBindingContext("mainModel").getProperty("Qmartx"),
				Qmart: oEvent.getSource().getBindingContext("mainModel").getProperty("Qmart"),
				Zdurum: oEvent.getSource().getBindingContext("mainModel").getProperty("Zdurum"),
				Arbpl: oEvent.getSource().getBindingContext("mainModel").getProperty("Arbpl"),
				Equnr: oEvent.getSource().getBindingContext("mainModel").getProperty("Equnr"),
				Eqktx: oEvent.getSource().getBindingContext("mainModel").getProperty("Eqktx")

			});

			this.getRouter().navTo("displayDetail", {
				Qmnum: qmnum
					// Aufnr: aufnr
			});
		},

		// onNavBack: function(oEvent) {
		// 	this.onClear();

		// },

		onClear: function() {
			var model = this.getModel("mainModel");
			model.setProperty("/notifHeader", "");
			model.setProperty("/genelTab", "");
			model.setProperty("/aktiviteList", []);
			model.setProperty("/zamanTab", "");
			model.setProperty("/IsiDevretList", []);
			model.setProperty("/malzemeList", []);
			//model.setProperty("/checkList", []);
			model.setProperty("/dof", "");
			model.setProperty("/bakimOneriStr", "");
			model.setProperty("/bakimOneri", []);
			model.setProperty("/tdLine", []);

		}

	});
});