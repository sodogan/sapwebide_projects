sap.ui.define([
	"ZVESTELPM1/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"ZVESTELPM1/model/formatter"
], function (BaseController, Controller, JSONModel, Filter, MessageBox, formatter) {
	"use strict";

	return BaseController.extend("ZVESTELPM1.controller.CheckList", {
		formatter: formatter,

		onInit: function () {
			// var params = vm.getItems();
			// var oModel = this.getView().getModel("vModel");

			this.getRouter().getRoute("checkList").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			var name = oEvent.getParameter("name");
			var oIconTabBar = this.getView().byId("iconTabBar1");
			oIconTabBar.setSelectedKey("anketList");
			if (name === "checkList") {
				var aufnr = oEvent.getParameters().arguments.Aufnr;
				this.getInit(aufnr);
				//this.getUrunAgaciList(this.getOwnerComponent().getModel("mainModel").getProperty("/Qmnum"));
			}
		},

		onNavBack: function () {
			var model = this.getModel("mainModel");
			var oIconTabBar = this.getView().byId("iconTabBar1");
			oIconTabBar.setSelectedKey("anketList");
			this.getView().byId("tb_checkList").removeSelections(true);
			model.setProperty("/anketList", []);

			history.go(-1);

		},

		getInit: function (aufnr) {

			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var Aufnr = aufnr;
			model.setProperty("/bt_anketVisible", false);
			model.setProperty("/anket", []);

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/checklistForOrderListSet", {
				filters: [
					new Filter("Aufnr", sap.ui.model.FilterOperator.EQ, Aufnr)
				],
				success: function (oData, oResponse) {
					model.setProperty("/checkList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/NotifDetailOrderOperationListGetSet", {
				filters: [
					new Filter("Aufnr", sap.ui.model.FilterOperator.EQ, Aufnr)
				],
				success: function (oData, oResponse) {
					model.setProperty("/operationList", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		onSelectionAnket: function (oEvent) {
			//	oEvent.getParameters().selected=true;
			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var tableId = this.getView().byId("tb_checkList");
			var oIconTabBar = this.getView().byId("iconTabBar1");
			var selectedPath = tableId.getSelectedItem().getBindingContext("mainModel").sPath;
			this.getView().byId("tb_checkList").removeSelections(true);
			var selectedIndex = selectedPath.split("/")[2];
			var items = model.getProperty("/checkList");
			var SelectedTur = items[selectedIndex].Tur;
			model.setProperty("/tur", SelectedTur);
			var aufnr2 = model.getProperty("/notifHeader/Aufnr");
			var aufnr = "00" + aufnr2;
			model.setProperty("/bt_anketVisible", true);

			//	sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/checklistItemGetSet", {
				filters: [
					new Filter("Aufnr", sap.ui.model.FilterOperator.EQ, aufnr),
					new Filter("Tur", sap.ui.model.FilterOperator.EQ, SelectedTur)
				],
				success: function (oData, oResponse) {
					model.setProperty("/anketList", oData.results);
					model.setProperty("/anket", oData.results[0]);

					//Radio butonlar tikli ise onlar doldurulur. 
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].Duzeltildi == "@R6@") {
							model.setProperty("/anketList/" + i + "/rb_InputAciklama", true);
						} else if (oData.results[i].UygunDegil == "@R6@") {
							model.setProperty("/anketList/" + i + "/rb_InputAciklama", true);
						} else {
							model.setProperty("/anketList/" + i + "/rb_InputAciklama", false);
						}
					}
					oIconTabBar.setSelectedKey("anket");
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function (oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}

			});

		},

		onSelectUygun: function (oEvent) {
			var model = this.getModel("mainModel");
			var SelectedIndex = oEvent.getSource().mBindingInfos.selected.binding.oContext.sPath.split("/")[2];

			model.setProperty("/anketList/" + SelectedIndex + "/rb_InputAciklama", false);
			model.setProperty("/anketList/" + SelectedIndex + "/Aciklama", "");
		},

		onSelectDuzeltildi: function (oEvent) {
			var model = this.getModel("mainModel");
			var SelectedIndex = oEvent.getSource().mBindingInfos.selected.binding.oContext.sPath.split("/")[2];

			model.setProperty("/anketList/" + SelectedIndex + "/rb_InputAciklama", true);
		},

		onSelectDuzeltUygunDegil: function (oEvent) {
			var model = this.getModel("mainModel");
			var SelectedIndex = oEvent.getSource().mBindingInfos.selected.binding.oContext.sPath.split("/")[2];

			model.setProperty("/anketList/" + SelectedIndex + "/rb_InputAciklama", true);

		},

		//
		handleIconTabSelect: function (oEvent) {

			var model = this.getModel("mainModel");
			switch (oEvent.getSource().getSelectedKey()) {
			case "anketList":
				this.getView().byId("tb_checkList").removeSelections(true);
				model.setProperty("/anketList", []);
				model.setProperty("/anket", []);
				break;
			case "anket":
				this.getView().byId("tb_checkList").removeSelections(true);
				model.setProperty("/anketList", []);
				var oIconTabBar = this.getView().byId("iconTabBar1");
				oIconTabBar.setSelectedKey("anketList");
				break;

			}
		},

		onSaveAnket: function (oEvent) {
			var model = this.getModel("mainModel");
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var items = model.getProperty("/anketList");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var tur = model.getProperty("/tur");
			var oIconTabBar = this.getView().byId("iconTabBar1");

			var kontrol = this.getZorunluAlanKontrol(this);

			if (!kontrol) {
				return;
			}

			var oEntry = {};
			oEntry.SoruNo = "1";
			oEntry.Message = "HEY";
			oEntry.Success = "";

			var NavChecklistHeaderGet = [];
			var tb = this.getView().byId("tb_anketList");

			for (var i = 0; i < items.length; i++) {
				NavChecklistHeaderGet.push({
					Tur: tur,
					SoruNo: items[i].SoruNo,
					SoruTanimi: items[i].SoruTanimi,
					Uygun: formatter.setRadioButtons(tb.mAggregations.items[i].mAggregations.cells[2].mProperties.selected),
					Duzeltildi: formatter.setRadioButtons(tb.mAggregations.items[i].mAggregations.cells[3].mProperties.selected),
					UygunDegil: formatter.setRadioButtons(tb.mAggregations.items[i].mAggregations.cells[4].mProperties.selected),
					Aciklama: items[i].Aciklama,
					AnketNo: items[i].AnketNo,
					AnketTanimi: items[i].AnketTanimi,
					Aufnr: aufnr,
					Equnr: items[i].Equnr
				});
			}

			oEntry.NavChecklistHeaderGet = NavChecklistHeaderGet;

			//		sap.ui.core.BusyIndicator.show(0);
			oDataModel.create("/checklistHeaderGetSet", oEntry, {
				success: function (oData, response) {
					//var returnList = oData.NavUpdateReturn.results;
					model.setProperty("/bt_anketVisible", false);
					MessageBox.success(oData.Message, {
						title: "Bilgi", // default
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (sButton) {
							if (sButton === "OK") {

								model.setProperty("/anketList", []);
								that.getView().byId("tb_checkList").removeSelections(true);
								oIconTabBar.setSelectedKey("anketList");
								that.getInit(aufnr);
							}
						}
					});
					sap.ui.core.BusyIndicator.hide(0);

				},
				error: function (oError) {
					var errMessage = JSON.parse(oError.responseText);
					sap.ui.core.BusyIndicator.hide(0);

				}
			});

		},

		getZorunluAlanKontrol: function (thisView) {

			var view = this.getView().byId("tb_anketList");

			var result = true;

			var inputs = [];
			for (var i = 0; i < view.getItems().length; i++) {
				inputs.push(view.getItems()[i].getBindingContext("mainModel").getProperty("/anketList/" + i + "/Aciklama"));
			}

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			for (var j = 0; j < view.getItems().length; j++) {
				if (view.getItems()[j].getBindingContext("mainModel").getProperty("/anketList/" + j + "/rb_InputAciklama")) {

					if (!inputs[j]) {
						var idAciklama = view.getItems()[j].getCells()[5].getId();
						this.getView().byId(idAciklama).setValueState("Error");
						result = false;
					} else {
						var idAciklama = view.getItems()[j].getCells()[5].getId();
						this.getView().byId(idAciklama).setValueState("None");
					}
				} else {
					var idAciklama = view.getItems()[j].getCells()[5].getId();
					this.getView().byId(idAciklama).setValueState("None");
				}
			}

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		onClear: function () {
			var model = this.getModel("mainModel");
			model.setProperty("/notifHeader", "");
			model.setProperty("/genelTab", "");
			model.setProperty("/aktiviteList", []);
			model.setProperty("/zamanTab", "");
			model.setProperty("/IsiDevretList", []);
			model.setProperty("/malzemeList", []);
			model.setProperty("/checkList", []);
			model.setProperty("/dof", "");
			model.setProperty("/bakimOneriStr", "");
			model.setProperty("/bakimOneri", []);
			model.setProperty("/tdLine", []);
			model.setProperty("/anketList", []);

		}

	});
});