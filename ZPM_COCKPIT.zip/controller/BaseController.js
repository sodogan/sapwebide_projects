sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	'sap/m/MessageBox'
], function (Controller, History, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("ZVESTELPM1.controller.BaseController", {
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				// Otherwise we go backwards with a forward history
				var bReplace = true;
				this.getRouter().navTo("master", {}, bReplace);
			}
		},

		onCloseDialog: function (oEvent) {
			var dialog = oEvent.getSource().getParent();
			dialog.close();
		},

		closePopup: function (oEvent) {
			var dialog = oEvent.getSource().getParent();
			dialog.close();
		}

	});

});