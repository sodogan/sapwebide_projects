sap.ui.define([
	"ZVESTELPM1/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/m/BusyDialog",
	"sap/ui/model/FilterOperator",
	"sap/m/Token",
	"sap/ui/model/resource/ResourceModel",
	'sap/m/MessageBox',
	"ZVESTELPM1/model/formatter"
], function(BaseController, Controller, JSONModel, Filter, M, BD, FilterOperator, Token, ResourceModel, MessageBox, formatter) {
	"use strict";
	var dialogBusy = new sap.m.BusyDialog();
	dialogBusy.setText("Doküman Yükleniyor, lütfen bekleyiniz..");

	return BaseController.extend("ZVESTELPM1.controller.S1", {
		formatter: formatter,

		table: function() {
			return this.getView().byId("tableListId");
		},

		onInit: function() {
			this.model = this.getOwnerComponent().getModel("mainModel");
			sap.ui.getCore().setModel(this.model, "mainModel");
			sap.ui.getCore().getModel("mainModel").setSizeLimit(50000);

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(oDataJSONModel, "global");

			this.getRouter().getRoute("s1").attachPatternMatched(this.onRouteMatched.bind(this));

			//Set model i18n
			this.i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleUrl: "ZVESTELPM1/i18n/i18n.properties"
			});

			//this.syncOrderList();

			this.getRouter().getRoute("s1").attachPatternMatched(this.onRouteMatched, this);

		},

		onRouteMatched: function() {
			//var oDataModel = this.getView().getModel();
			var model = this.getModel("mainModel");
			model.setProperty("/bt_IsiDevretEnb", false);
			model.setProperty("/iconVisible", "sap-icon://hide");
			model.setProperty("/iconColor", "Reject");
			model.setProperty("/refreshFlag", false);
			model.setProperty("/refreshColor", "Reject");

			if (!this.getOwnerComponent().getModel("global").getProperty("/detailView")) {
				var nowDate = new Date();
				var futureDate = new Date();
				var pastDate = futureDate.getDate();
				var nextDate = futureDate.getDate();
				futureDate.setDate(pastDate - 7);
				nowDate.setDate(nextDate);

				model.setProperty("/bslTarih", formatter.getDateTextFormat(futureDate));
				model.setProperty("/btsTarih", formatter.getDateTextFormat(nowDate));
			}

			//Tablo binding yapıldığında aşağıda ki fonksiyona düşer, bu aşamada satır boyama işlemi yaparız
			var oTable = this.getView().byId("tableListId");
			oTable.attachUpdateFinished(function() {
				this.getItems().forEach(function(row) {
					var obj = row.getBindingContext("mainModel").getObject();
					//row.getBindingContext("mainModel").sPath.split("/")[2]; seçili satır
					if (obj.Stat == "1") {
						row.removeStyleClass("highlightStyleRed");
						row.removeStyleClass("highlightStyleBlue");
						row.removeStyleClass("highlightStyleWhite");
						row.addStyleClass("highlightStyleRed");
					} else if (obj.Stat == "2") {
						row.removeStyleClass("highlightStyleRed");
						row.removeStyleClass("highlightStyleBlue");
						row.removeStyleClass("highlightStyleWhite");
						row.addStyleClass("highlightStyleRed");
					} else if (obj.Stat == "3") {
						row.removeStyleClass("highlightStyleRed");
						row.removeStyleClass("highlightStyleBlue");
						row.removeStyleClass("highlightStyleWhite");
						row.addStyleClass("highlightStyleBlue");
					} else if (obj.Stat == "4") {
						row.removeStyleClass("highlightStyleRed");
						row.removeStyleClass("highlightStyleBlue");
						row.removeStyleClass("highlightStyleWhite");
						row.addStyleClass("highlightStyleBlue");
					} else if (obj.Stat == "5") {
						row.removeStyleClass("highlightStyleRed");
						row.removeStyleClass("highlightStyleBlue");
						row.removeStyleClass("highlightStyleWhite");
						row.addStyleClass("highlightStyleWhite");
					}
				});
			}.bind(oTable));

			this.disableTypingBildirimList();

			/*------------------Katalog Türlerinin yüklenmesi----------------*/
			/*menu
			var date = new Date("2018-08-09");
			var date2 = new Date("2018-07-08");
			var filterdate = new sap.ui.model.Filter("Strmn", sap.ui.model.FilterOperator.EQ, date); //
			var filterdate1 = new sap.ui.model.Filter("Ltrmn", sap.ui.model.FilterOperator.EQ, date2); //
			var filters = new Array();
			filters.push(filterdate);
			filters.push(filterdate1);
			// var that = this;
			oDataModel.read("/qmnumListSet", {
				filters: filters,
				success: $.proxy(function(oData) {
					var oModel = new JSONModel({
						Lists: oData.results
					});
					this.table().setModel(oModel);
				}, this)

			});*/

		},

		disableTypingBildirimList: function() {
			var b1Id = this.byId("multiEqunrId").addEventDelegate({
				onAfterRendering: function() {
					b1Id.$().find("input").attr("readonly", true);
				}
			}, this);
		},

		disableConsumeMatnr: function() {
			var b1Id = sap.ui.getCore().byId("idDamageConsume").addEventDelegate({
				onAfterRendering: function() {
					b1Id.$().find("input").attr("readonly", true);
				}
			}, this);
		},

		handleListItemPress: function(oEvent) {
			var qmart = oEvent.getSource().getSelectedItem().getBindingContext("mainModel").getProperty("Qmart");
			var stat = oEvent.getSource().getSelectedItem().getBindingContext("mainModel").getProperty("Stat");

			var cList = "X2"; //"B2,B5,B6";
			if (cList.indexOf(qmart) !== -1) {
				this.byId("bt_check").setVisible(true);

				var dList = "1,2,3,4";
				if (dList.indexOf(stat) !== -1) {
					this.byId("bt_check").setVisible(true);
				} else {
					this.byId("bt_check").setVisible(false);
				}

			} else {
				this.byId("bt_check").setVisible(false);
			}

			var sList = "1,2,3,4";
			if (sList.indexOf(stat) !== -1) {
				// this.byId("bt_isiDevret").setVisible(true);
				// this.byId("bt_iseDahilEt").setVisible(true);
				this.byId("bt_isiBasladim").setVisible(true);
			} else {
				// this.byId("bt_isiDevret").setVisible(false);
				// this.byId("bt_iseDahilEt").setVisible(false);
				this.byId("bt_isiBasladim").setVisible(false);
			}

			var eList = "4";
			if (eList.indexOf(stat) !== -1) {
				this.byId("bt_isiBitirdim").setVisible(true);
			} else {
				this.byId("bt_isiBitirdim").setVisible(false);
			}

			var fList = "1,2";
			if (fList.indexOf(stat) !== -1) {
				this.byId("bt_tamamla").setVisible(true);
			} else {
				this.byId("bt_tamamla").setVisible(false);
			}
		},

		onDokumanEkle: function(oEvent) {
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
			this.finishWorkFlag = "";
			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (!this.recordDialog) {
				this.recordDialog = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.addDocument", this);
			}
			this.getView().addDependent(this.recordDialog);
			this.recordDialog.open();
		},
		startDocUploadPress: function(oEvent) {
			dialogBusy.open();
			var model = this.getModel("mainModel");
			var oModelDok = this.getView().getModel();
			var BildirimNo = model.getProperty("/notifHeader/Qmnum");
			// var aufnr = model.getProperty("/notifHeader/Aufnr");

			var oFileUploader = sap.ui.getCore().byId("docId");
			var Filename = sap.ui.getCore().byId("docId").getValue();
			Filename = this.convertTurkishChar(Filename);

			oFileUploader.removeAllHeaderParameters();

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "BildirimNo",
				value: BildirimNo
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "FileName",
				value: Filename
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "content-disposition",
				value: "1"
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: oModelDok.getSecurityToken()
			}));
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "X-Requested-With",
			// 	value: "X"
			// }));

			oFileUploader.upload();
		},
		handleUploadComplete: function(oEvent) {
			dialogBusy.close();
			MessageBox.success('Doküman yükleme işlemi başarılı bir şekilde tamamlandı.', {
				actions: [MessageBox.Action.OK],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function(sAction2) {
					// var dialog = oEvent.getSource().getParent();
					// dialog.close();
				}
			});
		},
		convertTurkishChar: function(iv_string) {
			var str_array = new Array();
			var str;
			var charMap = {
				"Ç": 'C',
				"ç": 'c',
				"Ö": 'O',
				"ö": 'o',
				"Ş": 'S',
				"ş": 's',
				"İ": 'I',
				"ı": 'i',
				"Ü": 'U',
				"ü": 'u',
				"Ğ": 'G',
				"ğ": 'g',
				" ": '_'
			};

			str_array = iv_string.split('');

			for (var i = 0, len = str_array.length; i < len; i++) {
				str_array[i] = charMap[str_array[i]] || str_array[i];
			}
			str = str_array.join('');
			return str;
		},
		onIseBasla: function(oEvent) {
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
			this.finishWorkFlag = "";
			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (!this.recordDialog) {
				this.recordDialog = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.record", this);
			}
			this.getView().addDependent(this.recordDialog);
			this.recordDialog.open();
			sap.ui.getCore().byId("empId").setValue("");
			sap.ui.getCore().byId("id_startWorkButton").setText("İşi Başlat");
		},

		startWorkPress: function(oEvent) {

			if (this.finishWorkFlag && sap.ui.getCore().byId("id_startWorkButton").getText() === "İşi Bitir") {
				this.startWorkFinishPress();
				// this.listPress();
			}
			// İşe başladım
			else {
				this.finishWorkFlag = "";
				var model = this.getView().getModel("mainModel");
				var aufnr = model.getProperty("/notifHeader/Aufnr");
				var qmnum = model.getProperty("/notifHeader/Qmnum");
				var pernr = sap.ui.getCore().byId("empId").getValue();
				this.recordDialog.setBusy(true);
				this.getModel().read("/orderStartWorkWithPernrSaveSet(Aufnr='" + aufnr + "',Qmnum='" + qmnum + "',Pernr='" + pernr + "')", {
					success: $.proxy(function(oData) {
						if (!oData.Success) {
							M.alert(oData.Message);
							this.recordDialog.close();
							this.recordDialog.setBusy(false);

						} else {
							M.success(oData.Message);
							this.recordDialog.close();
							this.recordDialog.setBusy(false);
							this.listPress();
							// tableId.destroyItems();
						}
					}, this),
					error: $.proxy(function(oError) {
						var e = JSON.parse(oError.responseText);
						M.error(e.error.message.value);
						this.recordDialog.setBusy(false);
					}, this)
				});
			}

		},

		startWorkFinishPress: function() {
			this.recordDialog.close();
			var model = this.getView().getModel("mainModel");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var pernr = sap.ui.getCore().byId("empId").getValue();
			sap.ui.core.BusyIndicator.show(0);
			this.getModel().read("/getDurationForPernrAufnrSet(Aufnr='" + aufnr + "',Pernr='" + pernr + "')", {
				success: $.proxy(function(oData) {
					if (!oData.Success) {
						M.error(oData.Message);
						sap.ui.core.BusyIndicator.hide(0);
					} else {
						var innerModel = {
							"Duration": oData.Duration,
							"DurationT": oData.DurationText,
							"Aufnr": oData.Aufnr,
							"Qmart": oData.Qmart,
							"Qmnum": oData.Qmnum,
							"Pernr": sap.ui.getCore().byId("empId").getValue()
						};
						sap.ui.core.BusyIndicator.hide(0);
						if (!this.finishWorkPopUp) {
							this.finishWorkPopUp = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.finishWorkPopUp", this);
						}
						this.getView().addDependent(this.finishWorkPopUp);
						this.finishWorkPopUp.setModel(new JSONModel(innerModel));
						$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.finishWorkPopUp);
						this.finishWorkPopUp.open();
						this.onFinishWorkPopClear();
					}
				}, this),
				error: $.proxy(function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}, this)
			});

		},

		onFinishWorkPopClear: function() {
			sap.ui.getCore().byId("descId").setValue("");
			sap.ui.getCore().byId("lastConfirm").setSelected(false);
			sap.ui.getCore().byId("thereIsConsume").setSelected(false);
		},

		onIsiBitir: function(oEvent) {
			this.finishWorkFlag = "X";
			var model = this.getModel("mainModel");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			var selectedStat = model.getProperty("/notifHeader/Stat");
			var stats = "4";
			var zDurum = model.getProperty("/notifHeader/Zdurum");
			if (stats.indexOf(selectedStat) === -1) {
				M.error(zDurum + " statüsündeki duruma işi bitir işlemi yapamazsınız !");
				return 1;
			}

			if (!this.recordDialog) {
				this.recordDialog = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.record", this);
			}
			this.getView().addDependent(this.recordDialog);
			this.recordDialog.open();
			sap.ui.getCore().byId("id_startWorkButton").setText("İşi Bitir");
			sap.ui.getCore().byId("empId").setValue("");

		},

		onRefreshAuto: function(oEvent) {
			var model = this.getModel("mainModel");
			var flag = model.getProperty("/refreshFlag");
			if (flag == false) {
				model.setProperty("/refreshFlag", true);
				model.setProperty("/refreshColor", "Accept");
				this.syncOrderList(true);
			} else {
				model.setProperty("/refreshFlag", false);
				model.setProperty("/refreshColor", "Reject");

			}

		},

		syncOrderList: function(flag) {
			var t = this;
			var model = this.getModel("mainModel");
			var intervalId = window.setInterval(function() {
				flag = model.getProperty("/refreshFlag");
				if (flag === true) {
					t.listPress();
					t.onRefreshAuto();
				} else {
					window.clearInterval(intervalId);
				}
			}, 500);

		},

		equnrVH: function(oEvent) {
			var that = this;
			var oModel = that.getView().getModel();
			if (!that.equnrSVH) {
				that.equnrSVH = sap.ui.xmlfragment("ZVESTELPM1.view.equnrVH", that);
			}
			that.equnrSVH.open();
			that.equnrSVH.setBusy(true);
			oModel.read("/notifListFilterEquipmentListGetSet", {
				success: $.proxy(function(oData) {
					this.equnrSVH.setModel(new JSONModel({
						Equipments: oData.results
					}), "mModel");
					$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.equnrSVH);
					this.equnrSVH.setBusy(false);
				}, this)
			});

		},
		onSearchToEqunr: function(oEvent) {
			var sQuery = oEvent.getParameter("value");
			var oFilter;
			var oFilter1 = new Filter("Eqktx", FilterOperator.Contains, sQuery);
			var oFilter2 = new Filter("Equnr", FilterOperator.Contains, sQuery);
			var oFilter3 = new Filter("Tplnr", FilterOperator.Contains, sQuery);
			var oFilter4 = new Filter("Pltxt", FilterOperator.Contains, sQuery);
			var oFilter5 = new Filter("Invnr", FilterOperator.Contains, sQuery);
			var oFilter6 = new Filter("Eqart", FilterOperator.Contains, sQuery);
			var oFilter7 = new Filter("Eartx", FilterOperator.Contains, sQuery);
			oFilter = new Filter([oFilter1, oFilter2, oFilter3, oFilter4, oFilter5, oFilter6, oFilter7], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter, "Application");
		},

		onDialogEqunrPress: function(oEvent) {
			var items = oEvent.getParameter("selectedItems");
			items.map($.proxy(function(arg) {
				var multiPernrId = this.getView().byId("multiEqunrId");
				var tokenText = arg.getBindingContext("mModel").getProperty("Equnr");
				return multiPernrId.addToken(new Token({
					text: tokenText
				}));
			}), this);
		},

		//Qmnam VH
		qmnamVH: function() {
			var oModel = this.getView().getModel();
			if (!this.qmnamSVH) {
				this.qmnamSVH = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.qmnamVH", this);
			}
			this.qmnamSVH.open();
			this.qmnamSVH.setBusy(true);
			oModel.read("/notifListFilterQmnamSet", {
				success: $.proxy(function(oData) {
					this.qmnamSVH.setModel(new JSONModel({
						Qmnams: oData.results
					}), "mModel");
					$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.qmnamSVH);
					this.qmnamSVH.setBusy(false);
				}, this)
			});
		},

		onSearchToQmnam: function(oEvent) {
			var sQuery = oEvent.getParameter("value");
			var oFilter;
			var oFilter1 = new Filter("McNamelas", FilterOperator.Contains, sQuery);
			var oFilter2 = new Filter("McNamefir", FilterOperator.Contains, sQuery);
			oFilter = new Filter([oFilter1, oFilter2], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter, "Application");
		},

		onDialogQmnamPress: function(oEvent) {
			var items = oEvent.getParameter("selectedItems");
			items.map($.proxy(function(arg) {
				var multiQmnamId = this.getView().byId("multiQmnamId");
				var tokenText = arg.getBindingContext("mModel").getProperty("Bname");
				return multiQmnamId.addToken(new Token({
					text: tokenText
				}));
			}), this);
		},

		// Tplnr VH
		tplnrVH: function() {
			var oModel = this.getView().getModel();
			if (!this.tplnrSVH) {
				this.tplnrSVH = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.tplnrVH", this);
			}
			this.tplnrSVH.open();
			this.tplnrSVH.setBusy(true);
			oModel.read("/notifFilterTplnrListSet", {
				success: $.proxy(function(oData) {
					this.tplnrSVH.setModel(new JSONModel({
						Tplnrs: oData.results
					}), "mModel");
					$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.tplnrSVH);
					this.tplnrSVH.setBusy(false);
				}, this)
			});
		},

		onSearchToTplnr: function(oEvent) {
			var sQuery = oEvent.getParameter("value");
			var oFilter;
			var oFilter1 = new Filter("Tplma", FilterOperator.Contains, sQuery);
			var oFilter2 = new Filter("Tplnr", FilterOperator.Contains, sQuery);
			var oFilter3 = new Filter("Pltxt", FilterOperator.Contains, sQuery);
			oFilter = new Filter([oFilter1, oFilter2, oFilter3], false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter, "Application");
		},

		onDialogTplnrPress: function(oEvent) {
			var items = oEvent.getParameter("selectedItems");
			items.map($.proxy(function(arg) {
				var multiTplnrId = this.getView().byId("multiTplnrId");
				var tokenText = arg.getBindingContext("mModel").getProperty("Tplnr");
				return multiTplnrId.addToken(new Token({
					text: tokenText
				}));
			}), this);
		},

		onDialogClosePress: function() {
			this.equnrSVH.close();
		},

		qmnumVH: function() {
			var that = this;
			var oModel = that.getView().getModel();
			if (!that.qmnumSVH) {
				that.qmnumSVH = sap.ui.xmlfragment("ZVESTELPM1.view.qmnumVH", that);
			}
			that.qmnumSVH.open();
			that.qmnumSVH.setBusy(true);
			oModel.read("/qmnumList_SHSet", {
				success: $.proxy(function(oData) {
					this.qmnumSVH.setModel(new JSONModel({
						Qmnums: oData.results
					}), "mModel");
					$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.qmnumSVH);
					this.qmnumSVH.setBusy(false);
				}, this)
			});
		},

		/*	FabrikaVH: function() {
				var that = this;
				var oModel = that.getView().getModel();
				if (!that.fabrikaSVH) {
					that.fabrikaSVH = sap.ui.xmlfragment("ZVESTELPM1.view.FabrikaVH", that);
				}
				that.fabrikaSVH.open();
				that.fabrikaSVH.setBusy(true);
				oModel.read("/getFabrikaBolumListSet", {
					success: $.proxy(function(oData) {
						this.fabrikaSVH.setModel(new JSONModel({
							Qmnums: oData.results
						}), "mModel");
						$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.fabrikaSVH);
						this.fabrikaSVH.setBusy(false);
					}, this)
				});

			},*/
		onDialogFabrikaPress: function(oEvent) {
			var dialog = oEvent.getSource().getParent();
			var table = dialog.getContent()[0];
			var items = table.getSelectedItems(); //array of controlls
			items.map($.proxy(function(arg) {
				var multiInputForFilter = this.getView().byId("multiFabrikaList");
				var tokenText = arg.getBindingContext("mModel").getProperty("ZfabrikaBolum");
				return multiInputForFilter.addToken(new Token({
					text: tokenText
				}));
			}), this);
			//Closing dialog after tokens set
			dialog.close();
			this.fabrikaSVH.close();
		},

		onDialogClosePress3: function() {
			this.fabrikaSVH.close();
		},

		onDialogQmnumPress: function(oEvent) {
			var dialog = oEvent.getSource().getParent();
			var table = dialog.getContent()[0];
			var items = table.getSelectedItems(); //array of controlls
			items.map($.proxy(function(arg) {
				var multiInputForFilter = this.getView().byId("multiQmnumList");
				var tokenText = arg.getBindingContext("mModel").getProperty("Qmnum");
				return multiInputForFilter.addToken(new Token({
					text: tokenText
				}));
			}), this);
			//Closing dialog after tokens set
			dialog.close();
			this.qmnumSVH.close();
		},

		onDialogClosePress2: function() {
			this.qmnumSVH.close();
		},

		onUpdateFinished: function(oEvent) {
			var t = this.getResourceBundle().getText("listNotif", [oEvent.getParameter("total")]);
			this.getView().byId("idListNotif").setText(t);
		},

		listPress: function(oEvent) {
			var model = this.getModel("mainModel");
			var oDataModel = this.getView().getModel();
			var qmart = this.getView().byId("multiQmartId").getSelectedKeys();
			var werks = this.getView().byId("multiWerksId").getSelectedKeys();
			var equnr = this.getView().byId("multiEqunrId").getTokens();
			var arbpl = this.getView().byId("multiArbplId").getSelectedKeys();
			var durum = this.getView().byId("multiDurumId").getSelectedKeys();
			var tplnr = this.getView().byId("multiTplnrId").getTokens();
			var qmnam = this.getView().byId("multiQmnamId").getTokens();
			//	var sipDurum = this.getView().byId("sipDurumId").getSelectedKeys();
			var tableId = this.getView().byId("tableListId");

			//OtomatikRefresh aktif mi ? 
			var flagRefresh = model.getProperty("/refreshFlag");

			var f = [];

			for (var i = 0; i < qmart.length; i++) {
				f.push(new Filter("Qmart", "EQ", qmart[i]));
			}

			for (var i = 0; i < werks.length; i++) {
				f.push(new Filter("Werks", "EQ", werks[i]));
			}

			for (var i = 0; i < equnr.length; i++) {
				f.push(new Filter("Equnr", "EQ", equnr[i].getProperty("text")));
			}
			for (var i = 0; i < tplnr.length; i++) {
				f.push(new Filter("Tplnr", "EQ", tplnr[i].getProperty("text")));
			}
			for (var i = 0; i < arbpl.length; i++) {
				f.push(new Filter("Arbpl", "EQ", arbpl[i]));
			}
			for (var i = 0; i < durum.length; i++) {
				f.push(new Filter("Zid", "EQ", durum[i]));
			}
			for (var i = 0; i < qmnam.length; i++) {
				f.push(new Filter("Qmnam", "EQ", qmnam[i].getProperty("text")));
			}

			f.push(new Filter("Qmtxt", FilterOperator.Contains, this.getView().byId("qmtxtId").getValue()));

			var sDate = "";
			var pDate = this.getView().byId("dateSId").getDateValue();
			if (pDate !== null) {
				var b = pDate.getTime() - pDate.getTimezoneOffset() * 60 * 1000;
				sDate = new Date(b);
				f.push(new Filter("Strmn", "EQ", sDate));
			}

			var fDate = "";
			var pfDate = this.getView().byId("dateFId").getDateValue();
			if (pfDate !== null) {
				var b = pfDate.getTime() - pfDate.getTimezoneOffset() * 60 * 1000;
				fDate = new Date(b);
				f.push(new Filter("Ltrmn", "EQ", fDate));
			}

			//var filters = new Array();

			if (flagRefresh == false) {
				sap.ui.core.BusyIndicator.show(0);
				tableId.destroyItems();
			}
			oDataModel.read("/notifListDetailGetSet", {
				filters: f,
				success: $.proxy(function(oData) {
					var oModel = new JSONModel({
						Lists: oData.results,
						count: oData.results.length
					});

					this.table().setModel(oModel, "mainModel");
					sap.ui.core.BusyIndicator.hide(0);

				}, this),
				error: $.proxy(function(oError) {
					sap.ui.core.BusyIndicator.hide(0);

				}, this)

			});

			//var qmnum = this.getView().byId("multiQmnumList").getTokens();
			var qmart = this.getView().byId("multiQmartId").getSelectedKeys();
			var werks = this.getView().byId("multiWerksId").getSelectedKeys();
			var equnr = this.getView().byId("multiEqunrId").getTokens();
			var arbpl = this.getView().byId("multiArbplId").getSelectedKeys();
			var durum = this.getView().byId("multiDurumId").getSelectedKeys();
			//var sipDurum = this.getView().byId("sipDurumId").getSelectedKeys();
			var f = [];
			for (var i = 0; i < qmart.length; i++) {
				f.push(new Filter("Qmart", "EQ", qmart[i]));
			}
			// for (var i = 0; i < qmnum.length; i++) {
			// 	f.push(new Filter("Qmnum", "EQ", qmnum[i].getProperty("text")));
			// }
			for (var i = 0; i < equnr.length; i++) {
				f.push(new Filter("Equnr", "EQ", equnr[i].getProperty("text")));
			}
			for (var i = 0; i < arbpl.length; i++) {
				f.push(new Filter("Arbpl", "EQ", arbpl[i]));
			}
			for (var i = 0; i < durum.length; i++) {
				f.push(new Filter("Zid", "EQ", durum[i]));
			}
			// for (var i = 0; i < sipDurum.length; i++) {
			// 	f.push(new Filter("Estat", "EQ", sipDurum[i]));
			// }

			f.push(new Filter("Qmtxt", FilterOperator.Contains, this.getView().byId("qmtxtId").getValue()));

			var sDate = "";
			var pDate = this.getView().byId("dateSId").getDateValue();
			if (pDate !== null) {
				var b = pDate.getTime() - pDate.getTimezoneOffset() * 60 * 1000;
				sDate = new Date(b);
				f.push(new Filter("Strmn", "EQ", sDate));
			}

			var fDate = "";
			var pfDate = this.getView().byId("dateFId").getDateValue();
			if (pfDate !== null) {
				var b = pfDate.getTime() - pfDate.getTimezoneOffset() * 60 * 1000;
				fDate = new Date(b);
				f.push(new Filter("Ltrmn", "EQ", fDate));
			}

			this.getView().byId("tableListId").getBinding("items").filter(f);

		},

		onUpdateTableFinished: function(oEvent) {
			if (sap.ui.Device.browser.mobile) {
				var table = this.getView().byId("tableListId").getItems();
				var cols = document.getElementsByClassName("sapMListTblSubRow");
				for (var i = 0; i < table.length; i++) {
					if (table[i].getBindingContext("mainModel").getProperty("Stat") === "1" || table[i].getBindingContext("mainModel").getProperty(
							"Stat") === "2") {
						cols[i].style.backgroundColor = "#F5A9A9";
					} else if (table[i].getBindingContext("mainModel").getProperty("Stat") === "3" || table[i].getBindingContext("mainModel").getProperty(
							"Stat") === "4") {
						cols[i].style.backgroundColor = "#b3d1ff";
					} else {
						cols[i].style.backgroundColor = "rgb(255, 255, 255)";
					}
				}
			}

		},

		deleteFieldPress: function() {
			this.getView().byId("qmtxtId").setValue("");
			this.getView().byId("multiEqunrId").removeAllTokens();
			this.getView().byId("multiTplnrId").removeAllTokens();
			this.getView().byId("multiQmartId").setSelectedItems(null);
			this.getView().byId("multiWerksId").setSelectedItems(null);
			this.getView().byId("multiDurumId").setSelectedItems(null);
			this.getView().byId("multiArbplId").setSelectedItems(null);
			this.getView().byId("multiQmnamId").setSelectedItems(null);

		},
		//Listede ki bazı alanların kapatılması işlemi
		onChangeListVisible: function(oEvent) {
			var model = this.getModel("mainModel");
			var oColumn1 = this.getView().byId("id_hideColumn1");
			var oColumn2 = this.getView().byId("id_hideColumn2");
			var oColumn3 = this.getView().byId("id_hideColumn3");
			var oColumn4 = this.getView().byId("id_hideColumn4");
			var oColumn5 = this.getView().byId("id_hideColumn5");

			var iconStatu = model.getProperty("/iconVisible");
			if (iconStatu == "sap-icon://show") {
				model.setProperty("/iconVisible", "sap-icon://hide");
				model.setProperty("/iconColor", "Reject");
				oColumn1.setVisible(false);
				oColumn2.setVisible(false);
				oColumn3.setVisible(false);
				oColumn4.setVisible(false);
				oColumn5.setVisible(false);
			} else {
				model.setProperty("/iconVisible", "sap-icon://show");
				model.setProperty("/iconColor", "Accept");
				oColumn1.setVisible(true);
				oColumn2.setVisible(true);
				oColumn3.setVisible(true);
				oColumn4.setVisible(true);
				oColumn5.setVisible(true);
			}

		},
		//İşi Devret pop-up'da selection change eventi
		onSelectionCngIsiDevret: function(oEvent) {
			var model = this.getModel("mainModel");
			var tableId = sap.ui.getCore().byId("tb_Devretlist");
			var selectedPath = tableId.getSelectedItem().getBindingContext("mainModel").sPath;
			var selectedIndex = selectedPath.split("/")[2];
			var items = model.getProperty("/BolumList");
			var SelectedArbpl = items[selectedIndex].Arbpl;
			var arbpl = model.getProperty("/notifHeader/ArbplT");

			if (SelectedArbpl === arbpl) {

				MessageBox.alert(
					"Sorumlu İşyeri tekrar seçilemez!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				model.setProperty("/bt_IsiDevretEnb", false);
				sap.ui.getCore().byId("tb_Devretlist").removeSelections(true);
				return;
			}

			model.setProperty("/bt_IsiDevretEnb", true);

		},

		//İşe Dahil et pop-up'da selection change eventi
		onSelectionChangeWorkCenter: function() {
			//Bildirim listesinde seçilen satırda ki iş yeri ile bu evente seçilen arbpl alanı aynı ise
			//uyarı verilecek ve ve seçime izin verilmeyecek...

		},

		//Ana Menu de ki bildirim listesinde ki change eventi
		onChangeNotifList: function(oEvent) {
			var model = this.getModel("mainModel");
			var tableId = this.getView().byId("tableListId");
			var selectedFlag = model.setProperty("/selectedFlag", true);
			var selectedPath = tableId.getSelectedItem().getBindingContext("mainModel").sPath;
			var selectedIndex = selectedPath.split("/")[2];

			var items = tableId.getBinding("items").oList;

			model.setProperty("/notifHeader", {
				Aufnr: items[selectedIndex].Aufnr,
				Qmarx: items[selectedIndex].Qmarx,
				Qmnum: items[selectedIndex].Qmnum,
				ArbplT: items[selectedIndex].ArbplT,
				Qmtxt: items[selectedIndex].Qmtxt,
				Qmnam: items[selectedIndex].Qmnam,
				Equnr: items[selectedIndex].Equnr,
				Zdurum: items[selectedIndex].Zdurum,
				Eqktx: items[selectedIndex].Eqktx,
				Qmart: items[selectedIndex].Qmart,
				Qmcod: items[selectedIndex].Qmcod,
				Qmgrp: items[selectedIndex].Qmgrp,
				Stat: items[selectedIndex].Stat,
				Iwerk: items[selectedIndex].Iwerk

			});

		},

		onSelectionChangeWorkDahilEt: function(oEvent) {

			var tbl = sap.ui.getCore().byId("tb_DahilEtlist");
			var model = this.getView().getModel("mainModel");
			var items = model.getProperty("/BolumListDahilEt");
			var path = oEvent.getParameters().listItems[0].getBindingContext("mainModel").sPath.split("/")[2];

			if (oEvent.getParameters().selected == true) {
				items[path].Dahil = "X";
			} else {
				items[path].Dahil = "";
			}

		},

		getWorkCenterList: function(popUpId) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = oModel.getProperty("/notifHeader/Qmnum");

			/*------------------Katalog Türlerinin yüklenmesi----------------*/
			var filterQmnum = new sap.ui.model.Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum); //
			var filters = new Array();
			filters.push(filterQmnum);

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifForwardWorkcenterDetailGetSet", {
				filters: filters,
				success: function(oData, oResponse) {

					//Dahil et işlemi multiple select özelliğine sahip ve odata'dan işaretli gelen satırlar tabloya işlenir.
					if (popUpId === "iseDahilEt") {
						oModel.setProperty("/BolumListDahilEt", oData.results);
						var tb = sap.ui.getCore().byId("tb_DahilEtlist");
						var items = tb.getItems();
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].Dahil == "X") {
								items[i].setSelected(true);
							}
						}
					} else {
						oModel.setProperty("/BolumList", oData.results);
					}
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//CheckList Ekranına geçiş sağlanır.
		onChecklist: function() {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var aufnr = oModel.getProperty("/notifHeader/Aufnr");
			var qmart = oModel.getProperty("/notifHeader/Qmart");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;

			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			//if (qmart !== "B2" && qmart !== "B5" && qmart !== "B6") {
			if (qmart !== "X2") {
				MessageBox.alert(
					"Sadece planlı bakım(B2), Önly./Kestrmci Bakım(B5) ve Kalibrasyon (B6)türündeki bildirimler için kontrol listesi işlenebilir!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (aufnr === "") {
				MessageBox.alert("Siparişe dönüştürülmemiş bildirimlerde kontrol listesi işlenemez!", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Hata"
				});

				return;
			}

			this.getRouter().navTo("checkList", {
				Aufnr: aufnr
			});
		},

		//Ana ekranda ki işe dahil et Pop-up'ı açarız	
		onIseDahilEtPopUp: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;

			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			this.getWorkCenterList("iseDahilEt");

			if (!this._addIseDahilEtDialog) {
				this._addIseDahilEtDialog = sap.ui.xmlfragment("ZVESTELPM1.view.IseDahilEtDialog", this);
				this._addIseDahilEtDialog.setModel(this.i18nModel, "i18n");
				this._addIseDahilEtDialog.setModel(oModel, "mainModel");
			}

			this._addIseDahilEtDialog.open();

		},

		//Ana ekranda ki işi devret Pop-up'ı açarız	
		onIsiDevretPopUp: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;

			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			this.getWorkCenterList("isiDevret");

			if (!this._addIsiDevretDialog) {
				this._addIsiDevretDialog = sap.ui.xmlfragment("ZVESTELPM1.view.IsiDevretDialog", this);
				this._addIsiDevretDialog.setModel(this.i18nModel, "i18n");
				this._addIsiDevretDialog.setModel(oModel, "mainModel");
			}
			this._addIsiDevretDialog.open();
		},

		onIsiTamamlaOpenDialog: function(oEvent) {
			var model = this.getModel("mainModel");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			var selectedStat = model.getProperty("/notifHeader/Stat");
			var stats = "1,2";
			var zDurum = model.getProperty("/notifHeader/Zdurum");
			if (stats.indexOf(selectedStat) === -1) {
				M.error(zDurum + " statüsündeki duruma işi bitir işlemi yapamazsınız !");
				return 1;
			}

			this.getOwnerComponent().getModel("global").setProperty("/IsiTamamlaSicilNo", "");
			this.getOwnerComponent().getModel("global").setProperty("/IsiTamamlaDescription", "");
			if (!this.IsiTamamlaDialog) {
				this.IsiTamamlaDialog = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.isiTamamlaRecord", this);
			}
			this.getView().addDependent(this.IsiTamamlaDialog);
			this.IsiTamamlaDialog.open();

		},

		onIsiTamamlaPopUp: function(oEvent) {

			var that = this;
			var model = this.getModel("mainModel");
			var oDataModel = this.getOwnerComponent().getModel();
			var model = this.getModel("mainModel");
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
			var oModel = this.getOwnerComponent().getModel("mainModel");
			oModel.setProperty("/flag", true);
			var oDataModel = this.getOwnerComponent().getModel();
			var that = this;

			if (selectedItem === undefined) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			var data = {
				"Pernr": this.getOwnerComponent().getModel("global").getProperty("/IsiTamamlaSicilNo"),
				"Qmnum": qmnum,
				"Aciklama": this.getOwnerComponent().getModel("global").getProperty("/IsiTamamlaDescription")
			};

			var oModel = this.getView().getModel();
			sap.ui.core.BusyIndicator.show(0);
			oModel.create("/notifOrderCompleteWorkSet", data, {
				success: $.proxy(function(oData) {
					if (oData.Success) {
						M.success(oData.Message);
					} else {
						M.error(oData.Message);
					}
					sap.ui.core.BusyIndicator.hide(0);
					this.IsiTamamlaDialog.close();
					this.listPress();
					this.table().setBusy(false);

				}, this),
				error: $.proxy(function(oError) {
					var e = JSON.parse(oError.responseText);
					M.error(e.error.message.value);
					sap.ui.core.BusyIndicator.hide(0);
					this.finishWorkPopUp.setBusy(false);
				}, this)
			});
			// }
		},

		onActivateHasarDialog: function(oEvent) {
			this.oViewModel = this.getView().getModel("mainModel");
			var kontrol = this.getZorunluAlanKontrolHasar(this) && this.getZorunluAlanKontrolHasarComboBox(this);
			var item = this.getView().getModel("mainModel").getProperty("/ConsumeCollectionLastConfirmation");
			if (!item) {
				item = [];
			}
			if (!kontrol) {
				return;
			} else {
				this.getView().getModel("mainModel").setProperty("/ConsumeVisibleLastConfirmation", true);
				item.push({
					Tip: "C",
					Qcodegrp: sap.ui.getCore().byId("idDamage")._getSelectedItemText(),
					GrupKodu: sap.ui.getCore().byId("idDamage").getSelectedKey(),
					Qcode: sap.ui.getCore().byId("idDamageCode")._getSelectedItemText(),
					KodKodu: sap.ui.getCore().byId("idDamageCode").getSelectedKey(),
					Qtext: this.oViewModel.getProperty("/HasarSecimiAciklama"),
					Button: true
				});
				this.oViewModel.setProperty("/ConsumeCollectionLastConfirmation", item);
				this.oViewModel.setProperty("/Qtext", "");
				this.clearHasar();
			}
		},

		onActivateNedenDialog: function(oEvent) {
			this.oViewModel = this.getView().getModel("mainModel");
			var kontrol = this.getZorunluAlanKontrolNeden(this) && this.getZorunluAlanKontrolNedenComboBox(this);
			var item = this.getView().getModel("mainModel").getProperty("/ConsumeCollectionLastConfirmation");
			if (!item) {
				item = [];
			}
			if (!kontrol) {
				return;
			} else {
				this.getView().getModel("mainModel").setProperty("/ConsumeVisibleLastConfirmation", true);
				item.push({
					Tip: "5",
					Qcodegrp: sap.ui.getCore().byId("idCause")._getSelectedItemText(),
					GrupKodu: sap.ui.getCore().byId("idCause").getSelectedKey(),
					Qcode: sap.ui.getCore().byId("idCauseCode")._getSelectedItemText(),
					KodKodu: sap.ui.getCore().byId("idCauseCode").getSelectedKey(),
					Qtext: this.oViewModel.getProperty("/NedenSecimiAciklama"),
					Button: true
				});
				this.oViewModel.setProperty("/ConsumeCollectionLastConfirmation", item);
				this.oViewModel.setProperty("/Qtext", "");
				this.clearNeden();
			}
		},

		getZorunluAlanKontrol: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("idDamageCodeConsume"),
				view.byId("damageDescIdConsume")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		getZorunluAlanKontrolComboBox: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("idDamageConsume"),
				view.byId("idCauseCodeConsume")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getSelectedKey()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		getZorunluAlanKontrolHasar: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("damageDescId")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		getZorunluAlanKontrolHasarComboBox: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("idDamage"),
				view.byId("idDamageCode")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getSelectedKey()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		getZorunluAlanKontrolNeden: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("causeDescId")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		getZorunluAlanKontrolNedenComboBox: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("idCause"),
				view.byId("idCauseCode")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getSelectedKey()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		deleteRowLastConfirmation: function(oEvent) {
			var selectedRow = parseInt(oEvent.getSource().getBindingContext("mainModel").getPath().match(/\d/g)[0]);
			this.getView().getModel("mainModel").getData().ConsumeCollectionLastConfirmation.splice(selectedRow, 1);
			var item = this.getView().getModel("mainModel").getData().ConsumeCollectionLastConfirmation;
			this.oViewModel.setProperty("/ConsumeCollectionLastConfirmation", item);
		},

		deleteRow: function(oEvent) {
			var selectedRow = parseInt(oEvent.getSource().getBindingContext("mainModel").getPath().match(/\d/g)[0]);
			this.getView().getModel("mainModel").getData().ConsumeCollection.splice(selectedRow, 1);
			var item = this.getView().getModel("mainModel").getData().ConsumeCollection;
			this.oViewModel.setProperty("/ConsumeCollection", item);
		},

		finishWorkPress: function(oEvent) {
			var cf = sap.ui.getCore().byId("lastConfirm");
			var cnsm = sap.ui.getCore().byId("thereIsConsume");
			if (cf.getSelected()) {
				this.getModel("mainModel").setProperty("/cf", true);
			} else {
				this.getModel("mainModel").setProperty("/cf", false);
			}
			if (cnsm.getSelected()) {
				this.getModel("mainModel").setProperty("/cnsm", true);
			} else {
				this.getModel("mainModel").setProperty("/cnsm", false);
			}
			var qmart = this.finishWorkPopUp.getModel().getData().Qmart;

			if (!this.finishWorkFlag) {
				var flagHasar = false;
				// var flagNeden = false;
				var tableLength = this.model.getProperty("/ConsumeCollectionLastConfirmation").length;
				for (var i = 0; i < tableLength; i++) {
					if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "C") {
						flagHasar = true;
					}
					// if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "5") {
					// 	flagNeden = true;
					// }
				}

				// var flagFinal = flagHasar & flagNeden;
				var flagFinal = flagHasar;
				if (flagFinal) {
					var eachtableRows = [];
					var aufnr = this.model.getProperty("/notifHeader/Aufnr");
					var qmnum = this.model.getProperty("/notifHeader/Qmnum");
					for (var i = 0; i < tableLength; i++) {
						if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Button")) {
							var Tip = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip");
							var Qcodegrp = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/GrupKodu");
							var Qcode = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/KodKodu");
							var Qtext = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Qtext");
							eachtableRows.push({
								Tip: Tip,
								Qcodegrp: Qcodegrp,
								Qcode: Qcode,
								Qtext: Qtext
							});
						}
					}
					var oEntry = {};
					oEntry.Aufnr = aufnr;
					oEntry.Qmnum = qmnum;
					oEntry.NavNotifDamageCauseAdd = eachtableRows;

					var oModel = this.getView().getModel();
					oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
						success: $.proxy(function(oData) {
							this.model.setProperty("/ConsumeCollectionLastConfirmation", "");
							if (oData.Success) {
								M.success(oData.Message);
								this.listPress();
								this.table().setBusy(false);
							} else {
								M.error(oData.Message);
							}
							this.confirmPopUp.setBusy(false);
							this.confirmPopUp.close();
							this.finishWorkPopUp.close();
							var f = [];
							f.push(new F("Pernr", "EQ", this.getView().byId("idSicilNo").getValue()));
							var oModel = this.getView().getModel();
							this.table().setBusy(true);

							if (that.getModel("mainModel").getProperty("/cnsm")) {
								if (!this.consumePopUp) {
									this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM1.view.consumePopUp", this);
								}
								this.getView().addDependent(this.consumePopUp);
								$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
								this.getView().getModel("mainModel").setProperty("/ConsumeCollection", []);
								this.consumePopUp.open();
								this.disableConsumeMatnr();
								jQuery.sap.delayedCall(1000, this, function() {
									sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
								});
							}

							oModel.read("/orderOpenWorksListGetSet", {
								filters: f,
								success: $.proxy(function(oData) {
									this.table().setBusy(false);
									var oModel = new JSONModel({
										equips: oData.results
									});
									oModel.setSizeLimit(oData.results.length);
									this.table().setModel(oModel);
									this.clear();
								}, this),
								error: $.proxy(function(oError) {
									this.table().setBusy(false);
									this.clear();
								}, this)
							});
						}, this),
						error: $.proxy(function(oError) {
							var e = JSON.parse(oError.responseText);
							M.error(e.error.message.value);
							this.confirmPopUp.close();
							this.finishWorkPopUp.close();
							this.clear();
						}, this)
					});
				} else {
					M.error("Lütfen en az bir adet hasar seçimi giriniz");
				}
			}

			// İşi Bitir
			else {

				if (oEvent.getSource().getId() === "saveButtonId") {
					var flagHasar = false;
					// var flagNeden = false;
					if (this.model.getProperty("/ConsumeCollectionLastConfirmation") === undefined) {
						M.error("Lütfen en az bir adet hasar seçimi giriniz");
						return 1;
					}
					var tableLength = this.model.getProperty("/ConsumeCollectionLastConfirmation").length;
					for (var i = 0; i < tableLength; i++) {
						if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "C") {
							flagHasar = true;
						}
						// if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "5") {
						// 	flagNeden = true;
						// }
					}
					// var flagFinal = flagHasar & flagNeden;
					var flagFinal = flagHasar;
					if (flagFinal) {
						var eachtableRows = [];
						var aufnr = this.model.getProperty("/notifHeader/Aufnr");
						var qmnum = this.model.getProperty("/notifHeader/Qmnum");
						for (var i = 0; i < tableLength; i++) {
							if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Button")) {
								var Tip = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip");
								var Qcodegrp = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/GrupKodu");
								var Qcode = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/KodKodu");
								var Qtext = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Qtext");
								eachtableRows.push({
									Tip: Tip,
									Qcodegrp: Qcodegrp,
									Qcode: Qcode,
									Qtext: Qtext
								});
							}
						}
						var oEntry = {};
						oEntry.Aufnr = aufnr;
						oEntry.Qmnum = qmnum;
						oEntry.Pernr = sap.ui.getCore().byId("empId").getValue();
						oEntry.ConfDesc = sap.ui.getCore().byId("descId").getValue(),
							oEntry.NavNotifDamageCauseAdd = eachtableRows;

						var oModel = this.getView().getModel();

						// 20.05.2019 huseyina 

						if (this.getModel("mainModel").getProperty("/cnsm") || this.getModel("mainModel").getProperty("/cf")) {
							if (this.getModel("mainModel").getProperty("/cnsm")) {
								if (!this.consumePopUp) {
									this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM1.view.consumePopUp", this);
								}
								this.getView().addDependent(this.consumePopUp);
								$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
								this.getView().getModel("mainModel").setProperty("/ConsumeCollection", []);
								this.consumePopUp.open();
								this.disableConsumeMatnr();
								jQuery.sap.delayedCall(1000, this, function() {
									sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
								});

							} else {
								oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
									success: $.proxy(function(oData) {
										this.model.setProperty("/ConsumeCollectionLastConfirmation", "");
										if (!oData.Success) {
											M.error(oData.Message);
										} else {
											M.success(oData.Message);
											this.confirmPopUp.setBusy(false);
											this.confirmPopUp.close();
											this.finishWorkPopUp.close();
											// var f = [];
											// f.push(new Filter ("Pernr", "EQ", this.getView().byId("idSicilNo").getValue()));
											// var oModel = this.getView().getModel();
											this.table().setBusy(true);
											this.listPress();
											this.table().setBusy(false);

										}
									}, this),
									error: $.proxy(function(oError) {
										var e = JSON.parse(oError.responseText);
										M.error(e.error.message.value);
										this.confirmPopUp.close();
										this.finishWorkPopUp.close();
										this.clear();
									}, this)
								});
							}

						} else {
							oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
								success: $.proxy(function(oData) {
									this.model.setProperty("/ConsumeCollectionLastConfirmation", "");
									if (!oData.Success) {
										M.error(oData.Message);
									} else {
										M.success(oData.Message);
										this.confirmPopUp.setBusy(false);
										this.confirmPopUp.close();
										this.finishWorkPopUp.close();
										var f = [];
										f.push(new F("Pernr", "EQ", this.getView().byId("idSicilNo").getValue()));
										var oModel = this.getView().getModel();
										this.table().setBusy(true);

										if (that.getModel("mainModel").getProperty("/cnsm")) {
											if (!this.consumePopUp) {
												this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM1.view.consumePopUp", this);
											}
											this.getView().addDependent(this.consumePopUp);
											$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
											this.consumePopUp.open();
											jQuery.sap.delayedCall(1000, this, function() {
												sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
											});

										}
										this.listPress();
										this.table().setBusy(false);

									}
								}, this),
								error: $.proxy(function(oError) {
									var e = JSON.parse(oError.responseText);
									M.error(e.error.message.value);
									this.confirmPopUp.close();
									this.finishWorkPopUp.close();
									this.clear();
								}, this)
							});
						}

						// end huseyina

					} else {
						M.error("Lütfen en az bir adet hasar seçimi giriniz");
					}

				} else if (oEvent.getSource().getId() === "saveButtonConsumeId") {
					if (this.oViewModel.getProperty("/ConsumeCollection").length > 1) {
						this.confirmPopUp.setBusy(true);
						var data = {
							"Duration": this.finishWorkPopUp.getModel().getData().Duration,
							"Text": sap.ui.getCore().byId("descId").getValue(),
							"Aueru": "X",
							"Pernr": this.getView().byId("idSicilNo").getValue(),
							"Aufnr": this.finishWorkPopUp.getModel().getData().Aufnr,
							"QcodegrpHasar": sap.ui.getCore().byId("idDamage").getSelectedKey(),
							"CodeHasar": sap.ui.getCore().byId("idDamageCode").getSelectedKey(),
							"HasarText": sap.ui.getCore().byId("damageDescId").getValue(),
							"QcodegrpNeden": sap.ui.getCore().byId("idCause").getSelectedKey(),
							"CodeNeden": sap.ui.getCore().byId("idCauseCode").getSelectedKey(),
							"NedenText": sap.ui.getCore().byId("causeDescId").getValue()
						};
						var oModel = this.getView().getModel();
						oModel.create("/OrderConfirmFinishWorkSaveSet", data, {
							success: $.proxy(function(oData) {
								if (oData.Success) {
									M.success(oData.Message);
								} else {
									M.error(oData.Message);
								}
								this.confirmPopUp.setBusy(false);
								this.confirmPopUp.close();
								this.finishWorkPopUp.close();
								this.listPress();
								this.table().setBusy(false);
							}, this),
							error: $.proxy(function(oError) {
								var e = JSON.parse(oError.responseText);
								M.error(e.error.message.value);
								this.confirmPopUp.close();
								this.finishWorkPopUp.close();
							}, this)

						});

					} else {
						M.error("Lütfen malzeme tüketim talebi giriniz");
					}
				} else {

					if ((cf.getSelected() && qmart == "B1")) {
						this.confirmSelect();

					} else if ((cnsm.getSelected())) {
						if (!this.consumePopUp) {
							this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM4.view.consumePopUp", this);
						}
						this.getView().addDependent(this.consumePopUp);
						$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
						this.consumePopUp.open();
						jQuery.sap.delayedCall(1000, this, function() {
							sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
						});

						//huseyina 21.05.2019 consume popup
						// var f1 = [];
						// f1.push(new F("Matnr", "EQ", "C"));
						// oModel.read("/orderMatConspGetMaterialListSet", {
						// 	filters: f1,
						// 	success: $.proxy(function (oData) {
						// 		var oModel = new J({
						// 			Types: oData.results
						// 		});
						// 		oModel.setSizeLimit(oData.results.length);
						// 		this.byId("idDamageConsume").setModel(oModel);
						// 	}, this)
						// });
						//end huseyina 21.05.2019

					}
					// checkbox secili degilse kosulu
					else {
						var sonTeyit = sap.ui.getCore().byId("lastConfirm").mProperties.selected;
						var Aueru = "";
						if (sonTeyit == true) {
							Aueru = "X";
						} else {
							Aueru = "";
						}

						this.finishWorkPopUp.setBusy(true);
						var data = {
							"Duration": this.finishWorkPopUp.getModel().getData().Duration,
							"Text": sap.ui.getCore().byId("descId").getValue(),
							"Aueru": Aueru,
							"Pernr": this.finishWorkPopUp.getModel().getData().Pernr,
							"Aufnr": this.finishWorkPopUp.getModel().getData().Aufnr
						};
						var oModel = this.getView().getModel();
						oModel.create("/OrderConfirmFinishWorkSaveSet", data, {
							success: $.proxy(function(oData) {
								if (oData.Success) {
									M.success(oData.Message);
								} else {
									M.error(oData.Message);
								}

								this.finishWorkPopUp.setBusy(false);
								this.finishWorkPopUp.close();
								this.listPress();
								this.table().setBusy(false);

							}, this),
							error: $.proxy(function(oError) {
								var e = JSON.parse(oError.responseText);
								M.error(e.error.message.value);
								this.finishWorkPopUp.setBusy(false);
							}, this)
						});
					}
				}

				// if ((cf.getSelected() && qmart == "B1")) {
				// 	this.confirmSelect();

				// } else if ((cnsm.getSelected())) {
				// 	if (!this.consumePopUp) {
				// 		this.consumePopUp = sap.ui.xmlfragment("VESTELPM1.view.fragments.consumePopUp", this);
				// 	}
				// 	this.getView().addDependent(this.consumePopUp);
				// 	$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
				// 	this.consumePopUp.open();

				// 	jQuery.sap.delayedCall(1000, this, function () {
				// 		sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
				// 	});
				// 	this.onUpdateComboBoxConsumeNotTyping();

				// } else {
				// 	var sonTeyit = sap.ui.getCore().byId("lastConfirm").mProperties.selected;
				// 	var Aueru = "";
				// 	if (sonTeyit == true) {
				// 		Aueru = "X";
				// 	} else {
				// 		Aueru = "";
				// 	}

				// 	this.finishWorkPopUp.setBusy(true);
				// 	var data = {
				// 		"Duration": this.finishWorkPopUp.getModel().getData().Duration,
				// 		"Text": sap.ui.getCore().byId("descId").getValue(),
				// 		"Aueru": Aueru,
				// 		"Pernr": this.finishWorkPopUp.getModel().getData().Pernr,
				// 		"Aufnr": this.finishWorkPopUp.getModel().getData().Aufnr,
				// 		"Grund": sap.ui.getCore().byId("id_cbNeden").getSelectedKey()
				// 	};
				// 	var oModel = this.getView().getModel();
				// 	oModel.create("/orderConfirmFinishWorkSaveSet", data, {
				// 		success: $.proxy(function (oData) {
				// 			if (oData.Success) {
				// 				M.success(oData.Message);
				// 				this.listPress();
				// 			} else {
				// 				M.error(oData.Message);
				// 			}

				// 			this.finishWorkPopUp.setBusy(false);
				// 			this.finishWorkPopUp.close();
				// 			this.listPress();
				// 			this.table().setBusy(false);

				// 		}, this),
				// 		error: $.proxy(function (oError) {
				// 			var e = JSON.parse(oError.responseText);
				// 			M.error(e.error.message.value);
				// 			this.finishWorkPopUp.setBusy(false);
				// 		}, this)
				// 	});
				// }
			}

		},

		// İşi Bitirdim 28.12.2019
		finishWorkForCockpitPress: function(oEvent) {
			var that = this;
			var cf = sap.ui.getCore().byId("lastConfirm");
			var cnsm = sap.ui.getCore().byId("thereIsConsume");
			if (cf.getSelected()) {
				this.getModel("mainModel").setProperty("/cf", true);
			} else {
				this.getModel("mainModel").setProperty("/cf", false);
			}
			if (cnsm.getSelected()) {
				this.getModel("mainModel").setProperty("/cnsm", true);
			} else {
				this.getModel("mainModel").setProperty("/cnsm", false);
			}
			var qmart = this.finishWorkPopUp.getModel().getData().Qmart;

			if (oEvent.getSource().getId() === "saveButtonId") {
				var flagHasar = false;
				// var flagNeden = false;
				var tableLength = this.model.getProperty("/ConsumeCollectionLastConfirmation").length;
				for (var i = 0; i < tableLength; i++) {
					if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "C") {
						flagHasar = true;
					}
					// if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "5") {
					// 	flagNeden = true;
					// }
				}
				// var flagFinal = flagHasar & flagNeden;
				var flagFinal = flagHasar;
				if (flagFinal) {
					var eachtableRows = [];
					var aufnr = this.getView().getModel("mainModel").getProperty("/Aufnr");
					var qmnum = this.getView().getModel("mainModel").getProperty("/Qmnum");
					for (var i = 0; i < tableLength; i++) {
						if (this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Button")) {
							var Tip = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip");
							var Qcodegrp = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/GrupKodu");
							var Qcode = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/KodKodu");
							var Qtext = this.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Qtext");
							eachtableRows.push({
								Tip: Tip,
								Qcodegrp: Qcodegrp,
								Qcode: Qcode,
								Qtext: Qtext
							});
						}
					}
					var oEntry = {};
					oEntry.Aufnr = aufnr;
					oEntry.Qmnum = qmnum;
					oEntry.Pernr = sap.ui.getCore().byId("empId").getValue(),
						oEntry.ConfDesc = sap.ui.getCore().byId("descId").getValue(),
						oEntry.NavNotifDamageCauseAdd = eachtableRows;
					var oModel = this.getView().getModel();

					if (this.getModel("mainModel").getProperty("/cnsm") || this.getModel("mainModel").getProperty("/cf")) {

						if (this.getModel("mainModel").getProperty("/cnsm")) {
							if (!this.consumePopUp) {
								this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM1.view.consumePopUp", this);
							}
							this.getView().addDependent(this.consumePopUp);
							$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
							this.getView().getModel("mainModel").setProperty("/ConsumeCollection", []);
							this.consumePopUp.open();
							this.disableConsumeMatnr();
							jQuery.sap.delayedCall(1000, this, function() {
								sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
							});

						} else {
							sap.ui.core.BusyIndicator.show(0);
							oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
								success: $.proxy(function(oData) {
									this.model.setProperty("/ConsumeCollectionLastConfirmation", "");
									if (!oData.Success) {
										M.error(oData.Message);
									} else {
										M.success(oData.Message);
										this.confirmPopUp.setBusy(false);
										this.confirmPopUp.close();
										this.finishWorkPopUp.close();
										this.listPress();
										this.table().setBusy(false);

									}
									sap.ui.core.BusyIndicator.hide(0);
								}, this),
								error: $.proxy(function(oError) {
									var e = JSON.parse(oError.responseText);
									M.error(e.error.message.value);
									this.confirmPopUp.close();
									this.finishWorkPopUp.close();
									sap.ui.core.BusyIndicator.hide(0);
									this.clear();
								}, this)
							});
						}

					} else {
						sap.ui.core.BusyIndicator.show(0);
						oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
							success: $.proxy(function(oData) {
								this.model.setProperty("/ConsumeCollectionLastConfirmation", "");
								if (!oData.Success) {
									M.error(oData.Message);
								} else {
									M.success(oData.Message);
									this.confirmPopUp.setBusy(false);
									this.confirmPopUp.close();
									this.finishWorkPopUp.close();
									this.listPress();
									this.table().setBusy(false);

								}
								sap.ui.core.BusyIndicator.hide(0);
							}, this),
							error: $.proxy(function(oError) {
								var e = JSON.parse(oError.responseText);
								M.error(e.error.message.value);
								this.confirmPopUp.close();
								this.finishWorkPopUp.close();
								sap.ui.core.BusyIndicator.hide(0);
								this.clear();
							}, this)
						});
					}

				} else {
					M.error("Lütfen en az bir adet hasar seçimi giriniz");
				}

			} else if (oEvent.getSource().getId() === "saveButtonConsumeId") {
				if (this.oViewModel.getProperty("/ConsumeCollection").length > 1) {
					this.confirmPopUp.setBusy(true);
					var data = {
						"Duration": this.finishWorkPopUp.getModel().getData().Duration,
						"Text": sap.ui.getCore().byId("descId").getValue(),
						"Aueru": "X",
						"Pernr": this.getView().byId("idSicilNo").getValue(),
						"Aufnr": this.finishWorkPopUp.getModel().getData().Aufnr,
						"QcodegrpHasar": sap.ui.getCore().byId("idDamage").getSelectedKey(),
						"CodeHasar": sap.ui.getCore().byId("idDamageCode").getSelectedKey(),
						"HasarText": sap.ui.getCore().byId("damageDescId").getValue(),
						"QcodegrpNeden": sap.ui.getCore().byId("idCause").getSelectedKey(),
						"CodeNeden": sap.ui.getCore().byId("idCauseCode").getSelectedKey(),
						"NedenText": sap.ui.getCore().byId("causeDescId").getValue()
					};
					var oModel = this.getView().getModel();
					sap.ui.core.BusyIndicator.show(0);
					oModel.create("/OrderConfirmFinishWorkSaveSet", data, {
						success: $.proxy(function(oData) {
							if (oData.Success) {
								M.success(oData.Message);
							} else {
								M.error(oData.Message);
							}
							sap.ui.core.BusyIndicator.hide(0);
							this.confirmPopUp.setBusy(false);
							this.confirmPopUp.close();
							this.finishWorkPopUp.close();
							this.listPress();
							this.table().setBusy(false);

						}, this),
						error: $.proxy(function(oError) {
							var e = JSON.parse(oError.responseText);
							M.error(e.error.message.value);
							sap.ui.core.BusyIndicator.hide(0);
							this.confirmPopUp.close();
							this.finishWorkPopUp.close();
						}, this)

					});

				} else {
					M.error("Lütfen malzeme tüketim talebi giriniz");
				}
			} else {

				if ((cf.getSelected() && qmart == "B1")) {
					this.confirmSelect();

				} else if ((cnsm.getSelected())) {
					if (!this.consumePopUp) {
						this.consumePopUp = sap.ui.xmlfragment("ZVESTELPM1.view.consumePopUp", this);
					}
					this.getView().addDependent(this.consumePopUp);
					$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.consumePopUp);
					this.getView().getModel("mainModel").setProperty("/ConsumeCollection", []);
					this.consumePopUp.open();
					this.disableConsumeMatnr();
					jQuery.sap.delayedCall(1000, this, function() {
						sap.ui.getCore().byId("idConfirmConsume").setBusy(false);
					});

				}
				// checkbox secili degilse kosulu
				else {
					var sonTeyit = sap.ui.getCore().byId("lastConfirm").mProperties.selected;
					var Aueru = "";
					if (sonTeyit == true) {
						Aueru = "X";
					} else {
						Aueru = "";
					}

					this.finishWorkPopUp.setBusy(true);
					var data = {
						"Duration": this.finishWorkPopUp.getModel().getData().Duration,
						"Text": sap.ui.getCore().byId("descId").getValue(),
						"Aueru": Aueru,
						"Pernr": sap.ui.getCore().byId("empId").getValue(),
						"Aufnr": this.finishWorkPopUp.getModel().getData().Aufnr
					};
					var oModel = this.getView().getModel();
					oModel.create("/OrderConfirmFinishWorkSaveSet", data, {
						success: $.proxy(function(oData) {
							if (oData.Success) {
								M.success(oData.Message);
							} else {
								M.error(oData.Message);
							}

							this.finishWorkPopUp.setBusy(false);
							this.finishWorkPopUp.close();
							this.listPress();
							this.table().setBusy(false);

						}, this),
						error: $.proxy(function(oError) {
							var e = JSON.parse(oError.responseText);
							M.error(e.error.message.value);
							this.finishWorkPopUp.setBusy(false);
						}, this)
					});
				}
			}
		},

		//Malzeme Tüketim Pop-Up function consume Popup
		saveFinishedWork: function(oEvent) {
			this.model = this.getModel("mainModel");
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var tableId = sap.ui.getCore().byId("idConsumeTable");

			if (this.getView().getModel("mainModel").getProperty("/ConsumeCollection")) {
				var tableLength = this.model.getProperty("/ConsumeCollection").length;
				var eachtableRows = [];
				for (var i = 0; i < tableLength; i++) {
					var aciklama = this.model.getProperty("/ConsumeCollection/" + i + "/Aciklama");
					var depoYeriKodu = this.model.getProperty("/ConsumeCollection/" + i + "/DepoYeriKodu");
					var malzemeKodu = this.model.getProperty("/ConsumeCollection/" + i + "/MalzemeKoduKodu");
					var tuketimYeri = this.model.getProperty("/ConsumeCollection/" + i + "/TuketimYeri");
					var aufnr = this.model.getProperty("/notifHeader/Aufnr");
					var pernr = this.model.getProperty("/notifHeader/Pernr");
					// var pernr = this.model.getProperty("/Pernr");
					eachtableRows.push({
						Aufnr: aufnr,
						Pernr: pernr,
						Matnr: malzemeKodu,
						Menge: tuketimYeri,
						Lgort: depoYeriKodu,
						Aciklama: aciklama
					});
				}
				var oEntry = {};
				oEntry.Aufnr = aufnr;
				oEntry.NavOrderMatConsReqItem = eachtableRows;
				sap.ui.core.BusyIndicator.show(0);
				oDataModel.create("/orderMatConspReqHeaderCreateSet", oEntry, {
					success: function(oData, response) {
						sap.ui.core.BusyIndicator.hide(0);

						if (!that.getModel("mainModel").getProperty("/cf")) {
							var Aueru = "";
							var data = {
								"Duration": that.finishWorkPopUp.getModel().getData().Duration,
								"Text": sap.ui.getCore().byId("descId").getValue(),
								"Aueru": Aueru,
								"Pernr": that.finishWorkPopUp.getModel().getData().Pernr,
								"Aufnr": that.finishWorkPopUp.getModel().getData().Aufnr
							};
							var oModel = that.getView().getModel();
							oModel.create("/OrderConfirmFinishWorkSaveSet", data, {
								success: $.proxy(function(oData) {
									M.success("Kayıt başarı ile oluşturuldu");
									that.consumePopUp.setBusy(false);
									that.consumePopUp.close();
									that.finishWorkPopUp.close();
									that.listPress();
									that.table().setBusy(false);

									that.consumePopUp.setBusy(false);
									that.consumePopUp.close();

								}, that),
								error: $.proxy(function(oError) {
									var e = JSON.parse(oError.responseText);
									M.error(e.error.message.value);
									that.finishWorkPopUp.setBusy(false);
								}, that)
							});
						} else {
							//Son teyit seçili ise
							var flagHasar = false;
							// var flagNeden = false;
							var eachtableRows = [];
							if (that.model.getProperty("/ConsumeCollectionLastConfirmation") !== undefined) {
								var tableLength = that.model.getProperty("/ConsumeCollectionLastConfirmation").length;
								for (var i = 0; i < tableLength; i++) {
									if (that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "C") {
										flagHasar = true;
									}
									// if (that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip") === "5") {
									// 	flagNeden = true;
									// }
								}

								for (var i = 0; i < tableLength; i++) {
									if (that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Button")) {
										var Tip = that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Tip");
										var Qcodegrp = that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/GrupKodu");
										var Qcode = that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/KodKodu");
										var Qtext = that.model.getProperty("/ConsumeCollectionLastConfirmation/" + i + "/Qtext");
										eachtableRows.push({
											Tip: Tip,
											Qcodegrp: Qcodegrp,
											Qcode: Qcode,
											Qtext: Qtext
										});
									}
								}

							}

							var aufnr = that.getModel("mainModel").getProperty("/notifHeader/Aufnr");
							var qmnum = that.getModel("mainModel").getProperty("/notifHeader/Qmnum");

							var oEntry = {};
							oEntry.Aufnr = aufnr;
							oEntry.Qmnum = qmnum;
							oEntry.Pernr = sap.ui.getCore().byId("empId").getValue();
							oEntry.ConfDesc = sap.ui.getCore().byId("descId").getValue();
							oEntry.NavNotifDamageCauseAdd = eachtableRows;
							var oModel = that.getView().getModel();
							sap.ui.core.BusyIndicator.show(0);
							oModel.create("/notifDamageCauseListAddHeaderSet", oEntry, {
								success: $.proxy(function(oData) {
									that.model.setProperty("/ConsumeCollectionLastConfirmation", []);
									if (!oData.Success) {
										M.error(oData.Message);
									} else {
										M.success(oData.Message);
										that.consumeClosePopup();
										sap.ui.core.BusyIndicator.hide(0);
										that.onFinishWorkPopClear();
										that.finishWorkPopUp.close();
										that.listPress();
										that.table().setBusy(false);
										that.confirmPopUp.close();
									}
								}, this),
								error: $.proxy(function(oError) {
									var e = JSON.parse(oError.responseText);
									M.error(e.error.message.value);
									sap.ui.core.BusyIndicator.hide(0);
									that.confirmPopUp.close();
									that.finishWorkPopUp.close();
									that.clear();
								}, this)
							});
						}
						that.consumePopUp.setBusy(false);
						that.consumeClosePopup();

					},
					error: function(oError) {
						var errMessage = JSON.parse(oError.responseText);
						sap.ui.core.BusyIndicator.hide(0);
						M.error(oError.Message);
					}
				}, that);
			} else {
				M.error("Lütfen öncelikle malzeme ekleyiniz");
			}
		},

		consumeClosePopup: function() {
			this.consumePopUp.close();
			sap.ui.getCore().byId("thereIsConsume").setSelected(false);
			this.getModel("mainModel").setProperty("/ConsumeCollection", "");
			// this.closePopup();
		},

		confirmSelect: function(oEvent) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel("mainModel");
			oModel.setProperty("/flag", true);
			var oDataModel = this.getOwnerComponent().getModel();
			var qmnum = this.finishWorkPopUp.getModel().getData().Qmnum;

			if (!this.confirmPopUp) {
				this.confirmPopUp = sap.ui.xmlfragment("ZVESTELPM1.view.confirmPopUp", this);
			}
			this.getView().addDependent(this.confirmPopUp);
			$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.confirmPopUp);
			this.confirmPopUp.open();
			jQuery.sap.delayedCall(2000, this, function() {
				sap.ui.getCore().byId("idConfirmDialog").setBusy(false);
			});

			var oEntry = "/NotifDetailDamageCauseGetSet(Qmnum='" + qmnum + "')";

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					//oModel.setProperty("/BolumList", oData.results);
					sap.ui.getCore().byId("damageDescId").setValue(oData.FeKurztext);
					sap.ui.getCore().byId("idDamage").setSelectedKey(oData.Fegrp);
					if (oData.Fegrp !== "") {
						that.damageCodeChange(oData.Fegrp);
					}
					sap.ui.getCore().byId("idDamageCode").setSelectedKey(oData.Fecod);
					sap.ui.getCore().byId("idCause").setSelectedKey(oData.Urgrp);
					if (oData.Urgrp !== "") {
						that.causeCodeChange(oData.Urgrp);
					}
					sap.ui.getCore().byId("idCauseCode").setSelectedKey(oData.Urcod);

					sap.ui.getCore().byId("causeDescId").setValue(oData.UrKurztext);
					sap.ui.core.BusyIndicator.hide(0);
					oModel.setProperty("/flag", false);

					var oEntry = "/getFecodUrcodListForQmnumSet";
					oDataModel.read(oEntry, {
						filters: [
							new Filter("Qmnum", sap.ui.model.FilterOperator.EQ, qmnum)
						],
						success: function(oData, oResponse) {
							sap.ui.core.BusyIndicator.hide(0);
							// that.model.setProperty("/ConsumeVisibleLastConfirmation", true);
							// that.model.setProperty("/ConsumeCollectionLastConfirmation", oData.results);
						},
						failed: function(oError) {
							sap.ui.core.BusyIndicator.hide(0);
						}
					});
				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		onDamageConsumeVH: function() {
			if (!this.damageConsumeDialog) {
				this.damageConsumeDialog = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.malzemeKodu", this);
			}
			this.getView().addDependent(this.damageConsumeDialog);
			$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.damageConsumeDialog);
			this.damageConsumeDialog.open();

			var oModel = this.getView().getModel();
			oModel.read("/orderMatConspGetMaterialListSet", {
				filters: [new Filter("Matnr", "EQ", "C")],
				success: $.proxy(function(oData) {
					this.damageConsumeDialog.setModel(new JSONModel({
						Types: oData.results
					}));
				}, this)
			});
		},

		handleValueMatnrHelpSearch: function(oEvent) {
			var val = oEvent.getParameter("value");
			var oFilter;
			var oFilter1 = new Filter("Matnr", FilterOperator.Contains, val);
			var oFilter2 = new Filter("Maktx", FilterOperator.Contains, val);
			if (val) {
				oFilter = new Filter([oFilter1, oFilter2], false);
			}
			oEvent.getSource().getBinding("items").filter(oFilter, "Application");
		},

		clearHasar: function(oEvent) {

			sap.ui.getCore().byId("idDamage").setSelectedKey();
			sap.ui.getCore().byId("idDamageCode").setSelectedKey();
			sap.ui.getCore().byId("damageDescId").setValue("");

		},

		clearNeden: function(oEvent) {

			sap.ui.getCore().byId("idCause").setSelectedKey();
			sap.ui.getCore().byId("idCauseCode").setSelectedKey();
			sap.ui.getCore().byId("causeDescId").setValue("");

		},

		damageCodeChange: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var flag = oModel.getProperty("/flag");
			var oDataModel = this.getOwnerComponent().getModel();
			// var fragmentId= this.getView().createId("idConfim");
			// var comboBox= sap.ui.core.Fragment.byId(fragmentId,"idDamageCode");
			var val = "";
			if (flag == false || oEvent.length == undefined) {
				// val = oEvent.getSource().getSelectedKey();
				if (oEvent.getSource().getSelectedKey !== undefined) {
					val = oEvent.getSource().getSelectedKey();
				} else {
					val = oEvent.getParameter("selectedItem").getTitle();
					var desc = oEvent.getParameter("selectedItem").getDescription();
					this.maktx = oEvent.getParameter("selectedItem").getBindingContext().getProperty("Maktx");
					this.matnr = val;
					sap.ui.getCore().byId("idDamageConsume").setValue(val + " - " + desc);
				}
			} else {
				val = oEvent;
			}
			var f = [];
			f.push(new Filter("Group", "EQ", val));
			f.push(new Filter("Qkatart", "EQ", "C"));

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: f,
				success: function(oData, oResponse) {
					oModel.setProperty("/damage", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		onActivateDialog: function(oEvent) {
			this.oViewModel = this.getView().getModel("mainModel");
			var kontrol = this.getZorunluAlanKontrolForTuketim(this);
			// var kontrol = this.getZorunluAlanKontrol(this) && this.getZorunluAlanKontrolComboBox(this);
			var item = this.getView().getModel("mainModel").getProperty("/ConsumeCollection");
			if (!item) {
				item = [];
			}
			if (!kontrol) {
				return;
			} else {
				this.getView().getModel("mainModel").setProperty("/ConsumeVisible", true);

				item.push({
					MalzemeKodu: this.maktx,
					MalzemeKoduKodu: this.matnr,
					TuketimYeri: this.oViewModel.getProperty("/TuketimYeri"),
					DepoYeri: sap.ui.getCore().byId("idCauseCodeConsume")._getSelectedItemText(),
					DepoYeriKodu: sap.ui.getCore().byId("idCauseCodeConsume").getSelectedKey(),
					Aciklama: this.oViewModel.getProperty("/Aciklama")
				});

				this.oViewModel.setProperty("/ConsumeCollection", item);
				this.oViewModel.setProperty("/Aciklama", "");
				this.oViewModel.setProperty("/TuketimYeri", "");
				this.clear();
			}
		},

		causeCodeChange: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			var flag = oModel.getProperty("/flag");
			// var fragmentId= this.getView().createId("idConfim");
			// var comboBox= sap.ui.core.Fragment.byId(fragmentId,"idCauseCode");
			var oDataModel = this.getOwnerComponent().getModel();
			var val = "";
			if (flag == false || oEvent.length == undefined) {
				val = oEvent.getSource().getSelectedKey();
			} else {
				val = oEvent;
			}
			var f = [];
			f.push(new Filter("Group", "EQ", val));
			f.push(new Filter("Qkatart", "EQ", "5"));

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read("/notifDetailGeneralInfoActivityCodeLisSet", {
				filters: f,
				success: function(oData, oResponse) {
					oModel.setProperty("/cause", oData.results);
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

			// //sap.ui.getCore().byId("idCauseCode").bindItems({
			// comboBox.bindItems({
			// 	path: "/oteilUrcodListSet",
			// 	template: sap.ui.getCore().byId("idCauseCode").getBindingInfo("items").template,
			// 	filters: f
			// });
		},

		confirmClosePopup: function(oEvent) {
			this.confirmPopUp.close();
			sap.ui.getCore().byId("idDamage").setSelectedKey("");
			sap.ui.getCore().byId("idDamageCode").setSelectedKey("");
			sap.ui.getCore().byId("idCause").setSelectedKey("");
			sap.ui.getCore().byId("idCauseCode").setSelectedKey("");
		},

		confirmClosePopupIsiTamamla: function(oEvent) {
			this.confirmPopUp.close();
			this.getModel("mainModel").setProperty("/ConsumeCollectionLastConfirmation", "");
		},

		onIsiTamamla: function(oEvent) {
			if (this.finishWorkFlag) {
				this.finishWorkPress(oEvent);
			} else {
				this.finishWorkFlag = "";
				var that = this;
				var model = this.getModel("mainModel");
				var oDataModel = this.getOwnerComponent().getModel();
				var model = this.getModel("mainModel");
				var aufnr = model.getProperty("/notifHeader/Aufnr");
				var qmnum = model.getProperty("/notifHeader/Qmnum");
				var qmart = model.getProperty("/notifHeader/Qmart");
				var qmgrp = sap.ui.getCore().byId("idDamage").getSelectedKey();
				var qmcod = sap.ui.getCore().byId("idDamageCode").getSelectedKey();
				var qmKurztext = sap.ui.getCore().byId("damageDescId").getValue();
				var fegrp = sap.ui.getCore().byId("idCause").getSelectedKey();
				var fecod = sap.ui.getCore().byId("idCauseCode").getSelectedKey();
				var feKurztext = sap.ui.getCore().byId("causeDescId").getValue();

				var listQmcod = model.getProperty("/notifHeader/Qmcod");
				var listQmgrp = model.getProperty("/notifHeader/Qmgrp");
				var flag = model.getProperty("/flagIsiTamamlaProcess");

				if (qmart === "II") {
					if (listQmgrp === "0400") {
						if (listQmcod === "R003") {
							if (flag == false || flag == undefined) {
								this.onDesignPopUp();
								model.setProperty("/flagIsiTamamlaProcess", true);
								return;
							}
						}
					}
				}

				if (qmart === "II") {
					if (listQmgrp === "0400") {
						if (listQmcod === "R004") {
							if (flag == false || flag == undefined) {
								this.onVersionPopup();
								model.setProperty("/flagIsiTamamlaProcess", true);
								return;
							}
						}
					}

				}

				//var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;
				var oEntry = "/notifDamageCauseChangeSet(Aufnr='" + aufnr + "',Qmnum='" + qmnum + "',Qmgrp='" + qmgrp + "',Qmcod='" + qmcod +
					"',QmKurztext='" + qmKurztext +
					"',Fegrp='" + fegrp + "',Fecod='" + fecod + "',FeKurztext='" + feKurztext + "')";

				//	sap.ui.core.BusyIndicator.show(0);
				oDataModel.read(oEntry, {
					success: function(oData, oResponse) {
						//oModel.setProperty("/BolumList", oData.results);
						if (oData.Success == "X") {
							MessageBox.alert(
								oData.Message, {
									icon: sap.m.MessageBox.Icon.SUCCESS,
									title: "Başarılı"
								}
							);
							model.setProperty("/flagIsiTamamlaProcess", false);
							that.confirmClosePopup();
						} else {
							MessageBox.alert(
								oData.Message, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Hata"
								}
							);
							model.setProperty("/flagIsiTamamlaProcess", false);
						}
						sap.ui.core.BusyIndicator.hide(0);
					},
					failed: function(oError) {
						that.console.log(oError);
						sap.ui.core.BusyIndicator.hide(0);
					}
				});
			}

		},

		onDesignPopUp: function(oEvent) {

			var oModel = this.getOwnerComponent().getModel("mainModel");

			if (!this._addDesignUpdate) {
				this._addDesignUpdate = sap.ui.xmlfragment("ZVESTELPM1.view.designPopUp", this);
				this._addDesignUpdate.setModel(oModel, "mainModel");
			}
			this._addDesignUpdate.open();

		},

		onDesingUpdateClose: function() {
			this._addDesignUpdate.close();

		},

		//design update işlemi
		onDesingUpdate: function() {
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var model = this.getModel("mainModel");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var zDesign = model.getProperty("/zDesign");

			var entry = "/almOrderMaintainSet(Aufnr='" + aufnr + "',Zversion='',Zdesign='" + zDesign + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(entry, {
				success: function(oData, oResponse) {
					//oModel.setProperty("/BolumList", oData.results);
					MessageBox.alert(
						oData.Message, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}
					);

					that.onDesingUpdateClose();
					that.onIsiTamamla();
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},
		onVersionPopup: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("mainModel");
			if (!this._addVersionUpdate) {
				this._addVersionUpdate = sap.ui.xmlfragment("ZVESTELPM1.view.versionPopUp", this);
				this._addVersionUpdate.setModel(oModel, "mainModel");
			}
			this._addVersionUpdate.open();

		},

		onVersiyonUpdateClose: function() {
			this._addVersionUpdate.close();

		},

		onVersiyonUpdate: function() {
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var model = this.getModel("mainModel");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var zVersiyon = model.getProperty("/zVersiyon");

			var entry = "/almOrderMaintainSet(Aufnr='" + aufnr + "',Zversion='" + zVersiyon + "',Zdesign='')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(entry, {
				success: function(oData, oResponse) {
					//oModel.setProperty("/BolumList", oData.results);
					if (oData.Success == "X") {
						MessageBox.success(oData.Message, {
							title: "Bilgi", // default
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(sButton) {
								if (sButton === "OK") {
									that.onVersiyonUpdateClose();
									that.onIsiTamamla();
								}
							}
						});
					} else {
						MessageBox.error(oData.Message, {
							title: "Hata", // default
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(sButton) {
								if (sButton === "OK") {
									that.onVersiyonUpdateClose();
									that.confirmClosePopup();
								}
							}
						});

					}
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//İşi devretme işlemi 
		onIsiDevret: function(oEvent) {
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var model = this.getModel("mainModel");
			var tableId = sap.ui.getCore().byId("tb_Devretlist");
			var selectedPath = tableId.getSelectedItem().getBindingContext("mainModel").sPath;
			var selectedIndex = selectedPath.split("/")[2];

			var items = model.getProperty("/BolumList");
			var arbpl = items[selectedIndex].Arbpl;
			var aciklama = items[selectedIndex].Aciklama;
			var pernr = model.getProperty("/pernrDevret");
			var qmnum = model.getProperty("/notifHeader/Qmnum");

			if (aciklama == undefined || aciklama == "") {
				MessageBox.alert(
					"Açıklama alanını doldurunuz!", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Bilgi"
					}

				);
				return;
			}

			if (pernr == undefined || pernr == "") {
				MessageBox.alert(
					"Personel No giriniz!", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Bilgi"
					}

				);
				return;
			}
			var entry = "/notifWorkcenterChangeSet(Qmnum='" + qmnum + "',Arbpl='" + arbpl + "',Pernr='" + pernr + "',Aciklama='" + aciklama +
				"')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(entry, {
				success: function(oData, oResponse) {
					//oModel.setProperty("/BolumList", oData.results);
					MessageBox.alert(
						oData.Message, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}
					);
					that.onCancelIsiDevret();
					that.listPress();
					sap.ui.core.BusyIndicator.hide(0);

				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},

		//İşe Dahil etme işlemi
		onIseDahilEt: function(oEvent) {

			var model = this.getModel("mainModel");
			var that = this;
			var oDataModel = this.getOwnerComponent().getModel();
			var tableId = sap.ui.getCore().byId("tb_DahilEtlist");
			if (tableId.getSelectedItem() !== null) {
				var selectedPath = tableId.getSelectedItem().getBindingContext("mainModel").sPath;
				var selectedIndex = selectedPath.split("/")[2];
			}
			var items = model.getProperty("/BolumListDahilEt");
			var pernr = model.getProperty("/pernrDahilEt");
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var arbpl = model.getProperty("/notifHeader/ArbplT");
			//var arbpl = items[selectedIndex].Arbpl;

			if (pernr == undefined || pernr == "") {
				MessageBox.alert(
					"Personel No giriniz!", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Bilgi"
					}
				);
				return;
			}

			var selectedRowsIndex = sap.ui.getCore().byId("tb_DahilEtlist")._aSelectedPaths;
			for (var i = 0; i < selectedRowsIndex.length; i++) {
				if (items[parseInt(selectedRowsIndex[i].split("/")[2])].Arbpl == arbpl) {
					MessageBox.alert(
						"Sorumlu İşyeri tekrar seçilemez!('" + arbpl + "')", {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Hata"
						}
					);
					return;
				}

			}

			var oEntry = {};
			oEntry.EvMessage = "";
			oEntry.Qmnum = "";
			oEntry.EvSuccess = "";

			var NavAddWorkcenterItem = [];
			var selectedRowsIndex = sap.ui.getCore().byId("tb_DahilEtlist")._aSelectedPaths;

			if (selectedRowsIndex.length == 0) {
				MessageBox.alert(
					"En az bir satır seçiniz!", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Bilgi"
					}
				);
				return;
			}

			for (var i = 0; i < items.length; i++) {
				if (items[i].Aciklama == "" && items[i].Dahil == "X") {
					MessageBox.alert(
						"Seçili satırlarda ki Açıklama alanını doldurunuz!", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}

					);
					return;

				} else {
					NavAddWorkcenterItem.push({
						Qmnum: qmnum,
						Arbpl: items[i].Arbpl,
						Pernr: pernr,
						Aciklama: items[i].Aciklama,
						Dahil: items[i].Dahil
					});

				}
			}

			oEntry.NavNotifWorkcenterAddItem = NavAddWorkcenterItem;

			sap.ui.core.BusyIndicator.show(0);
			oDataModel.create("/notifWorkcenterAddHeaderSaveSet", oEntry, {
				success: function(oData, response) {
					//var returnList = oData.NavUpdateReturn.results;
					MessageBox.alert(
						oData.EvMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Bilgi"
						}
					);
					sap.ui.core.BusyIndicator.hide(0);
					sap.ui.getCore().byId("tb_DahilEtlist").removeSelections(true);
					that.onCancelIseDahilEt();

				},
				error: function(oError) {
					var errMessage = JSON.parse(oError.responseText);
					sap.ui.core.BusyIndicator.hide(0);

				}
			});

			this.onRefreshAuto();

			//İşe dahiletme fonksiyonu devamı burada yer alacak...

		},

		onBildirimiSil: function(oEvent) {
			var that = this;
			var model = this.getModel("mainModel");
			var qmnum = model.getProperty("/notifHeader/Qmnum");
			var aufnr = model.getProperty("/notifHeader/Aufnr");
			var selectedItem = this.getView().byId("tableListId")._aSelectedPaths;

			if (selectedItem.length === 0) {
				MessageBox.alert(
					"Bildirim Seçiniz!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Hata"
					}
				);
				return;
			}

			if (aufnr !== "") {
				MessageBox.alert("Bildirimin siparişi mevcuttur, silme işlemi yapılamaz!", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Hata"
				});

				return;
			}

			MessageBox.success("Seçili bildirimi silmek istediğinize emin misiniz ?", {
				title: "Bilgi", // default
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function(sButton) {
					if (sButton === "YES") {

						that.onBildirimiSilProcess(qmnum);
					}
				}
			});

		},
		//Bildirimi silme işlemi yapılır.
		onBildirimiSilProcess: function(qmnum) {
			var that = this;
			var Qmnum = qmnum;
			var oDataModel = this.getOwnerComponent().getModel();
			var status = "1";

			var oEntry = "/NotifDeletionSet(Qmnum='" + Qmnum + "',Status='" + status + "')";
			sap.ui.core.BusyIndicator.show(0);
			oDataModel.read(oEntry, {
				success: function(oData, oResponse) {
					sap.ui.core.BusyIndicator.hide(0);
					if (oData.Success == "X") {
						MessageBox.alert(oData.Message, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Başarılı"
						});
						that.listPress();

					} else {
						MessageBox.alert(oData.Message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Hata"
						});
					}
					sap.ui.core.BusyIndicator.hide(0);
				},
				failed: function(oError) {
					that.console.log(oError);
					sap.ui.core.BusyIndicator.hide(0);
				}
			});

		},

		//İşi Devret pop-up close işlemi
		onCancelIsiDevret: function() {
			this._addIsiDevretDialog.close();
			this.onClearDevret();

		},
		//İşe Dahil pop-up close işlemi
		onCancelIseDahilEt: function() {
			this._addIseDahilEtDialog.close();
			this.onClearDahilEt();

		},

		getZorunluAlanKontrol: function(oEvent) {

			var qmart = this.getView().byId("multiQmartId").getSelectedKeys();
			var werks = this.getView().byId("multiWerksId").getSelectedKeys();
			var bslDate = this.getView().byId("dateSId").getDateValue();
			var btsDate = this.getView().byId("dateFId").getDateValue();
			//var zFabrika = this.getView().byId("multiFabrikaList").getTokens();

			var Messages = [];

			if (qmart.length === 0) {
				Messages.push({
					Type: "E",
					Message: this.getOwnerComponent().getModel("i18n").getProperty("zorunluQmart")
				});
			}
			if (bslDate === null || bslDate === "") {
				Messages.push({
					Type: "E",
					Message: this.getOwnerComponent().getModel("i18n").getProperty("zorunlubslDate")
				});
			}
			if (btsDate === null || btsDate === "") {
				Messages.push({
					Type: "E",
					Message: this.getOwnerComponent().getModel("i18n").getProperty("zorunlubtsDate")
				});
			}

			if (Messages.length > 0) {
				this.handleShowMessage(Messages);
				return false;
			} else {
				return true;
			}
		},

		getZorunluAlanKontrolForTuketim: function(thisView) {

			var view = sap.ui.getCore();

			var result = true;

			var inputs = [
				view.byId("idDamageConsume"),
				view.byId("idDamageCodeConsume"),
				view.byId("idCauseCodeConsume"),
				view.byId("damageDescIdConsume")
			];

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(inputs, function(k, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
					result = false;
				} else {
					input.setValueState("None");
				}
			});

			//Eksik alan var ise
			if (!result) {
				var zorunluMesaj = "Zorunlu Alanları Giriniz";
				var title = "Hata";
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
					zorunluMesaj, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: title,
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

			return result;

		},

		//Genel mesajları buradan verdiririz.
		handleShowMessage: function(messages) {
			var oModel = this.getView().getModel("mainModel");
			if (!this.MessageListDialog) {
				this.MessageListDialog = sap.ui.xmlfragment("ZVESTELPM1.view.MessageList", this);
				this.MessageListDialog.setModel(oModel);
			}
			var messageList = [];
			for (var i in messages) {
				if (messages[i].Message !== "") {
					messageList.push(messages[i]);
				}
			}
			if (messageList != "") {
				oModel.setProperty("/MessageList", messageList);
				this.MessageListDialog.open();
			}
		},

		onMessageDialogCloseButton: function() {

			this.MessageListDialog.close();
		},

		onClearDahilEt: function() {
			var model = this.getModel("mainModel");
			model.setProperty("/BolumListDahilEt", []);
			model.setProperty("/pernrDevret", "");
			model.setProperty("/pernrDahilEt", "");
			//sap.ui.getCore().byId("tb_Devretlist").removeSelections(true);
			sap.ui.getCore().byId("tb_DahilEtlist").removeSelections(true);

		},

		onClearDevret: function() {
			var model = this.getModel("mainModel");
			model.setProperty("/BolumList", []);
			model.setProperty("/pernrDevret", "");
			model.setProperty("/pernrDahilEt", "");
			sap.ui.getCore().byId("tb_Devretlist").removeSelections(true);
			//sap.ui.getCore().byId("tb_DahilEtlist").removeSelections(true);

		},

		//Satırda ki işlevi gerçekleştirir.
		onMenuAction: function(oEvent) {
			var oItemKey = oEvent.getParameter("item").getKey();

			if (oItemKey === "mBut_IseDahilEt") {
				this.onIseDahilEtPopUp();

			} else if (oItemKey === "mBut_IsiDevret") {

				this.onIsiDevretPopUp();
			} else if (oItemKey === "mBut_IsiTamamla") {

				this.onIsiTamamlaPopUp();

			} else if (oItemKey === "mBut_Sil") {

				this.onBildirimiSil();
			} else if (oItemKey === "mBut_CheckList") {

				this.onChecklist();
			}

		},

		onSearchToList: function(oEvent) {
			var table = this.getView().byId("tableListId");
			var filters = [];
			//----------------------------------------
			var sQuery = oEvent.getParameter("query");
			filters.push(new Filter("Aufnr", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Qmart", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Qmnum", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Equnr", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Zlocation", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Eqktx", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Qmtxt", FilterOperator.Contains, sQuery));
			filters.push(new Filter("ArbplT", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Qmnam", FilterOperator.Contains, sQuery));
			filters.push(new Filter("Zdurum", FilterOperator.Contains, sQuery));
			filters.push(new Filter("NoOfArbpl", FilterOperator.Contains, sQuery));

			table.getBinding("items").filter(new Filter(filters, false), "Application");

		},

		detailPress: function() {
			var oModel = this.getView().getModel("mainModel");
			var selectedFlag = oModel.getProperty("/selectedFlag");
			if (selectedFlag == true) {
				this.getRouter().navTo("s2");
			} else {
				MessageBox.alert(
					"Listeden bir satır seçiniz!", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Bilgi"
					}
				);
				return;

			}
		},

		clear: function(oEvent) {

			// sap.ui.getCore().byId("descId").setValue("");
			// sap.ui.getCore().byId("totalTempId").setValue("");

			// sap.ui.getCore().byId("thereIsConsume").setSelected(false);
			// sap.ui.getCore().byId("lastConfirm").setSelected(false);
			sap.ui.getCore().byId("damageDescIdConsume").setValue("");
			sap.ui.getCore().byId("idDamageConsume").setSelectedKey();
			sap.ui.getCore().byId("idDamageCodeConsume").setValue("");
			// sap.ui.getCore().byId("idCauseCodeConsume").setSelectedKey();

			// sap.ui.getCore().byId("lastConfirm").setSelected(false);
			sap.ui.getCore().byId("damageDescId").setValue("");
			sap.ui.getCore().byId("idDamage").setSelectedKey();
			sap.ui.getCore().byId("idDamageCode").setSelectedKey();
			sap.ui.getCore().byId("idCause").setSelectedKey();
			sap.ui.getCore().byId("idCauseCode").setSelectedKey();
			sap.ui.getCore().byId("causeDescId").setValue("");

		},

		testPress: function() {
			if (!this.confirmPopUp) {
				this.confirmPopUp = sap.ui.xmlfragment("ZVESTELPM1.view.fragments.confirmPopUp2", this);
			}
			this.getView().addDependent(this.confirmPopUp);
			$.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.confirmPopUp);
			this.confirmPopUp.open();
		}

		// onManage : function(oEvent){
		// 	console.log("manage");
		// },

		// onSelect : function(oEvent){
		// 	console.log("select");
		// },

		// onSave : function(oEvent){
		// 	console.log("save");
		// }
	});
});