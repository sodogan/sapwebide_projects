sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		getDateFormat: function(sValue) {
			if (!sValue) {
				return sValue;
			}
			if (sValue.length > 8) { //23.08.2016
				sValue = sValue.substring(0, 4) + "-" + sValue.substring(5, 7) + "-" + sValue.substring(8, 10) + "T00:00:00";
				return sValue;
			} else { //20160823

				return sValue; //= EndDate.substring(0,4)+"-"+ EndDate.substring(4,6)+"-"+EndDate.substring(6,8)+"T00:00:00";
			}

		},
		getDateTextFormat: function(date) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			return dateFormat.format(date);
		},

		formatTime: function(time) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var timeStr = timeFormat.format(new Date(time + TZOffsetMs));
			return timeStr;
		},
		formatTime1: function(time) {
			if(time  == null) {
				return "";
			}
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var timeStr = timeFormat.format(new Date(time.ms + TZOffsetMs));
			return timeStr;
		},
		
		RadioButtonControl : function(sValue) {
			if (!sValue) {
				return sValue;
			}
			if (sValue == "@SR@") { 
				
				return false;
			}
			else {
				return true;
			}
		},
		
		setRadioButtons : function(sValue) { 

			if (sValue == false) { 
				
				return "@SR@";
			}
			else {
				return "@R6@";
			}
			
		},
		
		durumButtonControl : function(sValue) {
			if (sValue == "1") { 
				
				return "sap-icon://forward";
			}
			else if(sValue == "2") {
				
				return "sap-icon://add-employee";
			}
			else if(sValue == "3") {
				
				return "sap-icon://employee-rejections";
			}
			
			
			
		},
		
		iconVisible : function(sValue) {
			if (sValue == "1") { 
				
				return "sap-icon://forward";
			}
			else if(sValue == "2") {
				
				return "sap-icon://add-employee";
			}
			else if(sValue == "3") {
				
				return "sap-icon://employee-rejections";
			}
			
		},

		getTimeFormat: function(timeValue) {
			//return "PT" + timeValue.substr(0, 2) + "H" + timeValue.substr(3, 2) + "M00S";
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm "
			});
			var time = timeFormat.format(timeValue).trim();
			return "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M00S";

		},
		messageTypeFormatter: function(value) {
			switch (value) {
				case "E":
					return "Error";
				case "S":
					return "Success";
				case "W":
					return "Warning";
			}
		},
		
		formatZzdorukMachNo : function(value){
			return "Doruk :" + value;
		}

	};

});