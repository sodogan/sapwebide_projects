sap.ui.define([], function () {
	"use strict";

	return {
		selectedCheckbox: function(selected){
			if(selected ){
				return false;
			}else{
				return true;
			}
		},
		yetkiVarmi: function(bYetki){
			if (!bYetki){
				return sap.m.LoadState.Disabled;	
			}
		}

	};

});