/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/bozankaya/ZBZ_HYM/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});