sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"com/bozankaya/ZBZ_HYM/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/library",
	"sap/ui/core/routing/History",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Button",
	'sap/ui/export/Spreadsheet',
	'sap/ui/export/library',
	'sap/ui/core/util/MockServer',
	'sap/ui/model/odata/v2/ODataModel',
	'sap/m/MessageToast'
], function(BaseController, formatter, Filter, FilterOperator, JSONModel, mobileLibrary, History, Dialog, Label, Button, Spreadsheet,
	exportLibrary, MockServer, ODataModel, MessageToast) {
	"use strict";
	var ButtonType = mobileLibrary.ButtonType;
	var EdmType = exportLibrary.EdmType;

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.HazirEdim", {
		formatter: formatter,
		onInit: function() {
			var oViewModel = this._createViewModel();
			this.getView().setModel(oViewModel, "viewModel");

			var oView = this.getView();
			oView.addEventDelegate({
				onAfterShow: function(oEvent) {
					oView.getModel().refresh();
				}
			}, oView);

			this.aHedim = [];
			this.sSasino = "";

		},
		_createViewModel: function() {
			return new sap.ui.model.json.JSONModel({
				busy: false,
				editable: false,
				enabled: true
			});
		},
		onSearch: function(oEvent) {

			var sQuery = oEvent.getParameter("query");
			this.sSasino = sQuery;
			this.getView().byId("iconTabBar").setSelectedKey("All");

			this._searchHedim(sQuery);

		},
		createColumnConfig: function() {
			var aCols = [];

			aCols.push({
				label: "Kapak No",
				property: "KapakNo",
				type: EdmType.String
			});
			aCols.push({
				label: "Kapak Adı",
				property: "Maktx",
				type: EdmType.String
			});
			aCols.push({
				label: "M Kapak No",
				property: "MkapakNo",
				type: EdmType.String
			});
			aCols.push({
				label: "Miktar",
				property: "Omeng",
				type: EdmType.Number,
				scale: 2,
				delimiter: true
			});
			aCols.push({
				label: "Birim",
				property: "Meins",
				type: EdmType.String
			});
			return aCols;
		},

		onExport: function() {
			var aCols;
			aCols = this.createColumnConfig();

			var aHazirEdim = this.getView().getModel("Haziredim").getProperty("/");
			
			var d = new Date();
			var n = d.toLocaleDateString();
			
			var sFilename = "Şasino" + this.sSasino + " - " + n + ".xlsx" ;
			
			
			var oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: aHazirEdim.results,
				fileName: sFilename
			};

			var oSheet = new Spreadsheet( oSettings );
			oSheet.build().finally(function() {
				oSheet.destroy();
			});

		},
		_searchHedim: function(sQuery) {
			var oDataModel = new JSONModel();
			var oModel = this.getModelAndSetHeaders("ZBZ_HYM_SRV");
			var oViewModel = this.getView().getModel("viewModel");
			var that = this;
			var aKey = this.getView().byId("iconTabBar").getSelectedKey();

			oDataModel.setSizeLimit(999999);
			var aFilter = [];
			if (sQuery) {
				aFilter.push(new Filter("SasiNo", FilterOperator.EQ, sQuery));
			} else {
				oDataModel.setData(null);
				this.getView().setModel(oDataModel, "Haziredim");
				this.aHedim = [];
				return;
			}
			oViewModel.setProperty("/busy", true);
			oModel.read("/haziredimSet", {
				filters: aFilter,
				success: function(oData) {
					oDataModel.setData(oData);
					that.getView().setModel(oDataModel, "Haziredim");
					that._setInfoToolbar(false, "");
					that.aHedim = that._copyArray(oData.results);
					oViewModel.setProperty("/busy", false);

					that._filterHaziredim(aKey);
					that.getView().byId("iconTabBar").setSelectedKey(aKey);
				},
				error: function(oError) {
					that._errorMessages(oError, that);
					that._setInfoToolbar(false, "");

					oViewModel.setProperty("/busy", false);
				}
			});
		},
		onLoad: function() {
			// disable checkboxes
			var tbl = this.getView().byId("idHazirEdimTable");

			var sKey = this.getView().byId("iconTabBar").getSelectedKey();

			if (sKey !== 'K') {

				var header = tbl.$().find("thead");
				var selectAllCb = header.find(".sapMCb");
				selectAllCb.remove();
			}
			tbl.getItems().forEach(function(r) {
				var obj = r.getBindingContext("Haziredim").getObject();
				var oStatus = obj.CheckEn;
				var cb = r.$().find(".sapMCb");
				var oCb = sap.ui.getCore().byId(cb.attr("id"));
				if (oStatus === false) {
					oCb.setEditable(false);
					oCb.setEnabled(false);
					oCb.setSelected(true);
				} else {
					oCb.setEditable(true);
					oCb.setEnabled(true);
					oCb.setSelected(false);
				}
			});
		},
		onFilterHaziredim: function(oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			this._filterHaziredim(sKey);
		},
		_filterHaziredim: function(sKey) {
			if (sKey === 'K') {
				sKey = "";
			}
			var oHedim = this.getView().getModel("Haziredim");
			if (oHedim) {
				var aHedim = this._copyArray(this.aHedim);
				if (sKey !== "All") {
					var aHedim2 = [];
					for (var i = 0; i < this.aHedim.length; i++) {
						if (aHedim[i].Color === sKey) {
							aHedim2.push(aHedim[i]);
						}
					}
					if (aHedim2.length !== 0) {
						this._refreshModel(aHedim2, "Haziredim");
					} else {
						this._refreshModel([], "Haziredim");
					}
				} else {
					this._refreshModel(this.aHedim, "Haziredim");
				}
			}
		},
		_copyArray: function(array) {
			var arr2 = [];
			for (var i = 0; i < array.length; i++) {
				arr2.push(array[i]);
			}
			return arr2;
		},
		onDetailPress: function(oEvent) {},

		onNavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Menu");
			// sayfa refresh etme
			var oSearchField = this.getView().byId("searchField");
			oSearchField.clear();
			this._clearModel("Haziredim");
			this._setInfoToolbar(false, "");

		},
		onDelete: function(oEvent) {
			var Question = 'Form silinecek. Onaylıyor musunuz?';

			var that = this;
			var oDialog = new Dialog({
				title: 'Sil Onay',
				type: 'Message',
				content: [
					new Label({
						text: Question,
						labelFor: 'rejectDialogTextarea'
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: 'Onayla',
					press: function() {
						that._deleteSasi();

						oDialog.close();
					}
				}),
				endButton: new Button({
					text: 'İptal',
					press: function() {
						oDialog.close();
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});

			oDialog.open();
		},
		_deleteSasi: function() {

			this.oCreateArray = {};
			this.oCreateArray.Islem = "3";
			this.oCreateArray.SasiNo = this.getView().byId("searchField").getValue();
			this._saveData(this.oCreateArray);
		},
		onSave: function(oEvent) {
			var aSelList = this.getView().byId("idHazirEdimTable").getSelectedContexts(true);
			var aList2 = [];
			var aHaz = this.getView().getModel("Haziredim").getData().results;

			var fTop = "0";
			// seçilebilen matnr'leri gönderiyoruz.
			for (var i = 0; i < aSelList.length; i++) {
				if (aSelList[i].getObject().CheckEn === true) {
					for (var j = 0; j < aHaz.length; j++) {
						if (aHaz[j].KapakNo === aSelList[i].getObject().KapakNo) {
							fTop = parseFloat(fTop) + parseFloat(aHaz[j].Omeng);
						}
					}
					aSelList[i].getObject().Gmiktar = fTop;
					aList2.push(aSelList[i].getObject());
				}
			}

			var oList2 = {};
			oList2.results = aList2;

			var jsonData = JSON.stringify(oList2);
			var encodedString = btoa(unescape(encodeURIComponent(jsonData)));

			this.oCreateArray = {};
			this.oCreateArray.String = encodedString;
			this.oCreateArray.Islem = "1";
			this.oCreateArray.SasiNo = this.getView().byId("searchField").getValue();
			this._saveData(this.oCreateArray);
		},

		_saveData: function(pData) {
			var that = this;

			var oViewModel = this.getView().getModel("viewModel");
			oViewModel.setProperty("/busy", true);

			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources.ZBZ_HYM_SRV.uri;

			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});

			oModel.create("/hedimTableSet", pData, {
				success: function(oData, oResponse) {
					var sCompleteMessage = oResponse.headers["sap-message"];
					if (sCompleteMessage) {
						var oMessage = JSON.parse(sCompleteMessage);
						that.showSuccessMessage("", oMessage.message);

					}
					var sSasiNo = pData.SasiNo;
					that._searchHedim(sSasiNo);

					that._setInfoToolbar(false, "");

					that.onLoad();

					oViewModel.setProperty("/busy", false);
				},
				error: function(oError) {
					var sSasiNo = pData.SasiNo;
					// that._changeColorRows(oError, that);
					that._errorMessages(oError, that);
					that._searchHedim(sSasiNo);
					that._setInfoToolbar(false, "");

					that.onLoad();

					oViewModel.setProperty("/busy", false);
				}
			});

		},
		onSelectionChange: function(oEvent) {},
		onPrint: function(oEvent) {
			var aList2 = [];
			var aSelList = this.getView().getModel("Haziredim").getData().results;
			// seçilebilen matnr'leri gönderiyoruz.
			for (var i = 0; i < aSelList.length; i++) {
				if (aSelList[i].CheckEn === false) {
					aList2.push(aSelList[i]);
				}
			}
			if (!aList2) {
				// hata versin
				this.showErrorMessage("Hata", "Kaydedilmiş malzeme bulunamadı!");
				return;
			} else {
				var oList2 = {};
				oList2.results = aList2;
			}

			var jsonData = JSON.stringify(oList2);
			var encodedString = btoa(unescape(encodeURIComponent(jsonData)));

			this.oCreateArray = {};
			this.oCreateArray.String = encodedString;
			this.oCreateArray.Islem = "2";
			this.oCreateArray.SasiNo = this.getView().byId("searchField").getValue();
			this._saveData(this.oCreateArray);
		},
		onAfterRendering: function() {},
		onExit: function() {},

		_setInfoToolbar: function(bSelected, sText) {
			var oLabel = this.byId("idFilterLabel");
			var oInfoToolbar = this.byId("idInfoToolbar");
			oInfoToolbar.setVisible(bSelected);
			oLabel.setText(sText);
		},
		_changeColorRows: function(oError, that) {
			var aList2 = [];
			var aList = [];
			var aSelList = this.getView().getModel("Haziredim").getData().results;
			// Seçtiğimiz Kapakları aldık
			for (var i = 0; i < aSelList.length; i++) {
				if (aSelList[i].CheckEn === true && aSelList[i].CheckSel === true) {
					aList2.push(aSelList[i].KapakNo);
					aList2.push(aSelList[i].MkapakNo);
				}
			}
			var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
			// hata mesajındaki kapakları aldık
			if (oMessage.length > 0) {
				for (i = 0; i < oMessage.length; i++) {
					var sMsg = oMessage[i].message;
					var a = sMsg.split(":");
					a = sMsg.split(",");
					for (var j = 0; j < a.length; j++) {
						aList.push(a[j]);
					}
				}
				// seçtiğimiz kapakların hatanın içinde olup olmadığına bakıyoruz
				// for (i = 0; i < aList2.length; i++){
				// }
			}
		},
		_errorMessages: function(oError, that) {
			var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
			var aMockMessages = [];

			if (oMessage.length > 0) {

				for (var i = 0; i < oMessage.length; i++) {
					var sMsg = oMessage[i].message;

					var oArray = {
						type: sap.ui.core.MessageType.Error,
						title: sMsg
					};
					aMockMessages.push(oArray);
				}
				that.getOwnerComponent().oMessageDialog.open(that, aMockMessages);

			}
		}
	});
});