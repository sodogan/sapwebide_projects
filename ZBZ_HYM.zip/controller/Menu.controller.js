sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/BusyIndicator",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"com/bozankaya/ZBZ_HYM/model/formatter"
], function (BaseController, JSONModel, BusyIndicator, Filter, FilterOperator, Fragment, formatter) {
	"use strict";

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.Menu", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.bozankaya.ZBZ_HYMview.Menu
		 */
		onInit: function () {
			
		},

		onPressHazirEdim: function(oEvent){
	
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HazirEdim");
			
		},
		
		_configDialog: function (oButton) {
			// Set custom text for the confirmation button
			var sCustomConfirmButtonText = oButton.data("confirmButtonText");
			this._oDialog.setConfirmButtonText(sCustomConfirmButtonText);

			this.getView().addDependent(this._oDialog);

		},
		
		onPressYapistirma: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Yapistirma");	
		},
		onPressMontaj:function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Montaj");
		},
		onPressNakil:function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Nakil");
		}

	});

});