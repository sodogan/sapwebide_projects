sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"com/bozankaya/ZBZ_HYM/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (BaseController, formatter, Filter, FilterOperator, JSONModel, MessageBox) {
	"use strict";

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.Montaj", {
		formatter: formatter,

		onInit: function () {
			var oView = this.getView();
			oView.addEventDelegate({
				onAfterShow: function (oEvent) {
					oView.getModel().refresh();
				}
			}, oView);
		},

		onNavBack: function () {
			// history.go(-1);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Menu");
			
			// sayfa refresh etme
			var oSearchField = this.getView().byId("sasino");
			oSearchField.setValue();
			this._clearModel("Montaj");
			
		},
		onPressSasinoDialog: function (oEvent) {
			this.getOwnerComponent().oSasinoValueHelp.open(this.getView(), this, oEvent.getSource());
		},
		onSearch: function (oEvent) {
			// build filter array
			var that = this;
			var aFilter = [];
			var sQuery = this.getView().byId( "sasino" ).getValue();
			var oDataModel = new JSONModel();
			var oModel = this.getModelAndSetHeaders("ZBZ_HYM_SRV");

			oDataModel.setSizeLimit(999999);

			if (sQuery) {
				aFilter.push(new Filter("SasiNo", FilterOperator.EQ, sQuery));
			} else {
				this._clearModel("Montaj");
				return;
			}

			sap.ui.core.BusyIndicator.show();
			oModel.read("/montajSet", {
				filters: aFilter,
				success: function (oData) {
					oDataModel.setData(oData);
					that.getView().setModel(oDataModel, "Montaj");
					
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
					that.showErrorMessage("Hata", sErrorMessage);
					
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		onPressTeyitBtn: function (oEvent) {
			var that = this;
			// var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["ZBZ_HYM_SRV"].uri;
			// var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			// oModel.setHeaders({
			// 	"X-Requested-With": "XMLHttpRequest",
			// 	"Content-Type": "application/atom+xml",
			// 	"DataServiceVersion": "2.0",
			// 	"X-CSRF-Token": "Fetch"
			// });
			var oModel = this.getModelAndSetHeaders("ZBZ_HYM_SRV");
			var oObject = oEvent.getSource().getBindingContext("Montaj").getObject();

			var sPath = "/montajSet(SasiNo='" + oObject.SasiNo + "',KapakNo='" + oObject.KapakNo + "',UrtSip='" + oObject.UrtSip + "')";
			var oEntry = {};
			var sBtnTxt = oEvent.getSource().getText();

			oEntry = this._setEntry(sBtnTxt, oEntry, true, false, oObject.IskColor);
			oEntry.Miktar = oObject.Miktar;
			
			sap.ui.core.BusyIndicator.show();
			oModel.update(sPath, oEntry, {
				success: function (data, oResponse) {
					// butonları güncelle
					that.oObject = that._setObject(sBtnTxt, oObject, false, true, false);
					that.getView().getModel("Montaj").refresh(true) ;
					
					var sCompleteMessage = oResponse.headers["sap-message"];
					var oMessage = JSON.parse(sCompleteMessage);
					// MessageBox.success(oMessage.message, {
					// 	onClose: function (sAction) {

					// 	}
					// });

					var aMessage = oMessage.message.split("-");
					var msg = "";
					for (var k = 0; k < aMessage.length; k++) {
						msg = msg + aMessage[k] + "\n";
					}

					MessageBox.success(msg);
					
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					// butonları güncelle
					that.oObject = that._setObject(sBtnTxt, oObject, true, false, false);
					that.getView().getModel("Montaj").refresh(true) ;
					// hata göster
					that._errorMessages(oError, that);
					sap.ui.core.BusyIndicator.hide();
				}

			});
		},
		_setObject: function(sBtn, oObj, bVer, bIpt, bFail ){
			if (sBtn === "Teyit Ver") {
				oObj.MonTyt = bVer;
				oObj.TytIpt = bIpt;
				oObj.IskTyt = bVer;
			} else if (sBtn === "Teyit İptal") {
				oObj.MonTyt = bIpt;
				oObj.TytIpt = bVer;
				oObj.IskTyt = bIpt;
				if (oObj.IskColor){
					if (!bVer){
						oObj.IskColor = "";
					}
				}
			} else if (sBtn === "Iskarta Teyit") {
				oObj.MonTyt = bVer;
				oObj.TytIpt = bFail;
				oObj.IskTyt = bVer;
				if (!bVer){
					oObj.IskColor = "P";
				}
			}
			return oObj;
		},
		_setEntry: function(sBtn, oEnt, bVer, bIpt, sColor ){
			if (sBtn === "Teyit Ver") {
				oEnt.MonTyt = bVer;
				oEnt.TytIpt = bIpt;
			} else if (sBtn === "Teyit İptal") {
				oEnt.MonTyt = bIpt;
				oEnt.TytIpt = bVer;
				if (sColor){
					oEnt.IskTyt = bVer;
				}
			} else if (sBtn === "Iskarta Teyit") {
				oEnt.IskTyt = bVer;
			}
			return oEnt;
		},

		_errorMessages: function (oError, that) {
			var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
			var aMockMessages = [];

			if (oMessage.length > 0) {

				for (var i = 0; i < oMessage.length; i++) {
					var sMsg = oMessage[i].message;

					var oArray = {
						type: sap.ui.core.MessageType.Error,
						title: sMsg
					};
					aMockMessages.push(oArray);
				}
				that.getOwnerComponent().oMessageDialog.open(that, aMockMessages);

			}
		}
	});
});