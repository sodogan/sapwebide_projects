sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.dialog.SasinoValueHelp", {

		open: function(oView, oController, pSource) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.Input = pSource;
			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
				
			oController.getView().addDependent(oDialog);
			oDialog.open();
			
			this._selectTytHelp("1");
		},

		_getDialog: function() {
			if (!this.oSasinoValueHelp) {
				this.oSasinoValueHelp = sap.ui.xmlfragment("com.bozankaya.ZBZ_HYM.view.fragment.SasinoValueHelp", this);
			}
			return this.oSasinoValueHelp;
		},
		
		onCloseDialog: function () {
			this._getDialog().close();
		},
		
		onDialogAfterClose: function () {
			this.oSasinoValueHelp.destroy();
			this.oSasinoValueHelp = undefined;
		},

		onSasinoSelect: function (oEvent) {
			// var that = this;
			var oItem = oEvent.getSource();
			var oObject = oItem.getBindingContext().getObject();

			if (this.Input) { 
				this.Input.setValue(oObject.SasiNo);
				this.Input.setValueState(sap.ui.core.ValueState.None);
			} 
			this._getDialog().close();
		},
		onChangeSegmendButton: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			this._selectTytHelp(sKey);		
		},

		onSearch: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				this._searchFilter = new Filter("SasiNo", FilterOperator.EQ, sQuery);
			} else {
				this._searchFilter = null;
			}
			this._applyFilterSearch();
		},
		_selectTytHelp: function (sKey){
			var sConName = this.oController.getView().getControllerName();
			
			if ( sConName === "com.bozankaya.ZBZ_HYM.controller.Montaj" ){
				 sKey = this.parseToInt(sKey) + 2;
			}
			this._durumFilter = new Filter("Durum", FilterOperator.EQ, sKey );
			this._applyFilterSearch();
		},

		_applyFilterSearch: function () {
			var aFilter = [];
			if (this._durumFilter) {
				aFilter.push(this._durumFilter);
			}
			if (this._searchFilter) {
				aFilter.push(this._searchFilter);
			}
			var oTable = sap.ui.getCore().byId("sasiVHTab");
			oTable.getBinding("items").filter(aFilter, "Application" );
		}
	});
});