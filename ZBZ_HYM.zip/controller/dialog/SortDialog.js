sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function (BaseController, Filter, FilterOperator, Sorter) {
	"use strict";

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.dialog.SortDialog", {

		open: function(oView, oController, pSource) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.Input = pSource;
			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
				
			oController.getView().addDependent(oDialog);
			oDialog.open();
			
		},

		_getDialog: function() {
			if (!this.oSortDialog) {
				this.oSortDialog = sap.ui.xmlfragment("com.bozankaya.ZBZ_HYM.view.fragment.SortDialog", this);
			}
			return this.oSortDialog;
		},
		
		onCloseDialog: function () {
			this._getDialog().close();
		},
		
		onDialogAfterClose: function () {
			this.oSortDialog.destroy();
			this.oSortDialog = undefined;
		},
		handleSortDialogConfirm: function (oEvent) {
			
			var oTable = this.byId("idYapistirmaTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		}
		
	});
});