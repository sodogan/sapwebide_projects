sap.ui.define([
	"com/bozankaya/ZBZ_HYM/controller/BaseController",
	"com/bozankaya/ZBZ_HYM/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/library",
	"sap/ui/core/routing/History",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Button",
	'sap/ui/export/Spreadsheet',
	'sap/ui/export/library',
	'sap/ui/core/util/MockServer',
	'sap/ui/model/odata/v2/ODataModel',
	'sap/m/MessageToast'
], function(BaseController, formatter, Filter, FilterOperator, JSONModel, mobileLibrary, History, Dialog, Label, Button, Spreadsheet,
	exportLibrary, MockServer, ODataModel, MessageToast) {
	"use strict";
	var ButtonType = mobileLibrary.ButtonType;
	var EdmType = exportLibrary.EdmType;

	return BaseController.extend("com.bozankaya.ZBZ_HYM.controller.Nakil", {
		formatter: formatter,
		onInit: function() {
			var oViewModel = this._createViewModel();
			this.getView().setModel(oViewModel, "nakilModel");

			var oView = this.getView();
			oView.addEventDelegate({
				onAfterShow: function(oEvent) {
					oView.getModel().refresh();
				}
			}, oView);

			this.aNakil = [];
			this.sSasino = "";

		},
		_createViewModel: function() {
			return new sap.ui.model.json.JSONModel({
				busy: false,
				editable: false,
				enabled: true
			});
		},
		onSearch: function() {

			var sQuery = this.byId("searchField").getValue();
			// this.getView().byId("iconTabBar").setSelectedKey("All");

			this._searchNakil(sQuery);

		},
		_searchNakil: function(sQuery) {
			var oDataModel1 = new JSONModel();
			var oDataModel2 = new JSONModel();
			var oDataModel3 = new JSONModel();
			var oModel = this.getModelAndSetHeaders("ZBZ_HYM_SRV");
			var oViewModel = this.getView().getModel("nakilModel");
			var that = this;
			var aKey = this.getView().byId("iconTabBar").getSelectedKey();

			oDataModel1.setSizeLimit(999999);
			oDataModel2.setSizeLimit(999999);
			oDataModel3.setSizeLimit(999999);
			var aFilter = [];
			if (sQuery) {
				aFilter.push(new Filter("SasiNo", FilterOperator.EQ, sQuery));
			} else {
				oDataModel1.setData(null);
				oDataModel2.setData(null);
				oDataModel3.setData(null);
				this.getView().setModel(oDataModel1, "uretimDeposuModel");
				this.getView().setModel(oDataModel2, "iadeEtModel");
				this.getView().setModel(oDataModel3, "kullanilmayanIadeEtModel");
				this.aNakil = [];
				return;
			}

			// if (aKey === "uretimDeposunaCek") {
			oViewModel.setProperty("/busy", true);
			oModel.read("/uretimDeposuSet", {
				filters: aFilter,
				success: function(oData1) {
					oViewModel.setProperty("/busy", false);
					oDataModel1.setData(oData1.results);
					that.getView().setModel(oDataModel1, "uretimDeposuModel");
				},
				error: function(oError) {
					oViewModel.setProperty("/busy", false);
					that._errorMessages(oError, that);
					// that._setInfoToolbar(false, "");

				}
			});
			// } else if (aKey === "geriIadeEt") {
			oViewModel.setProperty("/busy", true);
			oModel.read("/geriIadeEtSet", {
				filters: aFilter,
				success: function(oData2) {
					oViewModel.setProperty("/busy", false);
					oDataModel2.setData(oData2.results);
					that.getView().setModel(oDataModel2, "geriIadeEtModel");
				},
				error: function(oError) {
					oViewModel.setProperty("/busy", false);
					that._errorMessages(oError, that);
					// that._setInfoToolbar(false, "");

				}
			});
			// } else if (aKey === "KullanilmayanlariIadeEt") {
			oViewModel.setProperty("/busy", true);
			oModel.read("/kullanilmayanIadeEtSet", {
				filters: aFilter,
				success: function(oData3) {
					oViewModel.setProperty("/busy", false);
					oDataModel3.setData(oData3.results);
					that.getView().setModel(oDataModel3, "kullanilmayanIadeEtModel");
				},
				error: function(oError) {
					oViewModel.setProperty("/busy", false);
					that._errorMessages(oError, that);
					// that._setInfoToolbar(false, "");

				}
			});
			// }
		},
		uretimDeposunaCekOnPress: function(oEvt) {
			var that = this;

			var selectedContexts = this.byId("uretimDeposuTableId").getSelectedContexts();

			var mParameters = {
				groupId: "UretDepoGr",
				success: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					that.onSearch();
				},
				error: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					// var obj = JSON.parse(odata.responseText);
					// sap.m.MessageBox.error(obj.error.innererror.errordetails[0].message);
					that._errorMessages(odata, that);
				}
			};

			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources.ZBZ_HYM_SRV.uri;

			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["UretDepoGr"]);

			for (var i = 0; i < selectedContexts.length; i++) {
				// var sObjectPath = oModel.createKey("/uretimDeposuSet", {
				// 	Matnr: selectedContexts[i].getObject().Matnr
				// });
				oModel.create("/uretimDeposuSet", selectedContexts[i].getObject(), mParameters);
			}

			that.getModel("nakilModel").setProperty("/busy", true);
			oModel.submitChanges(mParameters);

		},
		geriIadeEtOnPress: function(oEvt) {
			var that = this;

			var selectedContexts = this.byId("geriIadeEtTableId").getSelectedContexts();

			var mParameters = {
				groupId: "GeriIadeGrp",
				success: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					that.onSearch();
				},
				error: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					// var obj = JSON.parse(odata.responseText);
					// sap.m.MessageBox.error(obj.error.innererror.errordetails[0].message);
					that._errorMessages(odata, that);
				}
			};

			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources.ZBZ_HYM_SRV.uri;

			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["GeriIadeGrp"]);

			for (var i = 0; i < selectedContexts.length; i++) {
				oModel.create("/geriIadeEtSet", selectedContexts[i].getObject(), mParameters);
			}

			that.getModel("nakilModel").setProperty("/busy", true);
			oModel.submitChanges(mParameters);
		},
		uretimDeposuExcPress: function() {
			this.onExport("uretimDeposuModel");
		},
		GeriIadeEtExcPress: function() {
			this.onExport("geriIadeEtModel");
		},
		kullanilmayanIadeEtExcPress: function() {
			this.onExport("kullanilmayanIadeEtModel");
		},
		createColumnConfig: function(oModelName) {
			var i18nBundle = this.getView().getModel("i18n").getResourceBundle();
			var array = [];

			switch (oModelName) {
				case "uretimDeposuModel":
					array = ["SasiNo",
						"Matnr",
						"Aufnr", ["Bdmng", "number"],
						["Labst", "number"],
						["CekilenMiktar", "number"],
						"Meins",
						"Werks"
					];
					break;
				case "geriIadeEtModel":
					array = [
						"SasiNo",
						"Matnr",
						"Aufnr", ["Menge", "number"],
						"Meins",
						"Lgort",
						"Werks"
					];
					break;
				case "kullanilmayanIadeEtModel":
					break;
				default:
					// code block
			}

			function returnCol(arr) {
				var x = 0;
				var typeStr = '',
					labelStr = '',
					property = '',
					z = [];
				for (x in arr) {
					if (typeof(arr[x]) === "string") {
						labelStr = arr[x];
						property = arr[x];
						typeStr = 'string';
					} else {
						labelStr = arr[x][0];
						property = arr[x][0];
						typeStr = arr[x][1];
					}
					z.push({
						label: i18nBundle.getText(labelStr),
						property: property,
						type: typeStr
					});
				}
				return z;
			}
			return returnCol(array);
		},
		onExport: function(oModelName) {
			var aCols;
			aCols = this.createColumnConfig(oModelName);

			var dataSource = this.getView().getModel(oModelName).getProperty("/");

			var d = new Date();
			var n = d.toLocaleDateString();

			var sFilename = "Şasino" + this.byId("searchField").getValue() + " - " + n + ".xlsx";

			var oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: dataSource,
				fileName: sFilename
			};

			var oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
			});

		},
		kullanilmayanIadeEtOnPress: function(oEvt) {
			var that = this;

			var selectedContexts = this.byId("kullanilmayanIadeEtTableId").getSelectedContexts();

			var mParameters = {
				groupId: "KullanilmayanIadeGrp",
				success: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					that.onSearch();
				},
				error: function(odata, resp) {
					that.getModel("nakilModel").setProperty("/busy", false);
					// var obj = JSON.parse(odata.responseText);
					// sap.m.MessageBox.error(obj.error.innererror.errordetails[0].message);
					that._errorMessages(odata, that);
				}
			};

			var serviceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources.ZBZ_HYM_SRV.uri;

			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["KullanilmayanIadeGrp"]);

			for (var i = 0; i < selectedContexts.length; i++) {
				oModel.create("/kullanilmayanIadeEtSet", selectedContexts[i].getObject(), mParameters);
			}

			that.getModel("nakilModel").setProperty("/busy", true);
			oModel.submitChanges(mParameters);
		},

		_errorMessages: function(oError, that) {
			var oMessage = JSON.parse(oError.responseText).error.innererror.errordetails;
			var aMockMessages = [];

			if (oMessage.length > 0) {

				for (var i = 0; i < oMessage.length - 1; i++) {
					var sMsg = oMessage[i].message;

					var oArray = {
						type: sap.ui.core.MessageType.Error,
						title: sMsg
					};
					aMockMessages.push(oArray);
				}
				that.getOwnerComponent().oMessageDialog.open(that, aMockMessages);

			}
		}

	});

});