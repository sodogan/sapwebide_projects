sap.ui.define([], function() {
	"use strict";

	return {


	formatterCountDate : function (value) {

  if((value!=null) && (value!="0000-00-00"))

  {

  if (value) {

  var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd,MM,yyyy"});

  return oDateFormat.format(new Date(value));

  }

else {  return value; }

  }

  else return "";

  },
  
		convertToStringTime: function(dTime, bFlag) {
			var retVal = "";
			if (dTime != null) {
				if (dTime.ms != null) {
					if (dTime.ms === 0) {
						return "";
					}
					var offset = new Date().getTimezoneOffset();
					var dTemp = new Date(dTime.ms + (offset * 60000));
					var sHrs = dTemp.getHours();
					var sMin = dTemp.getMinutes();
					sHrs = ("0" + sHrs).slice(-2);
					sMin = ("0" + sMin).slice(-2);
					if (bFlag) {
						retVal = sHrs + ":" + sMin + ":00";
					} else {
						retVal = sHrs + ":" + sMin;
					}
				} else {
					var aTempTimeArray = dTime.split("PT");
					var sTempVal = aTempTimeArray[1];
					aTempTimeArray = sTempVal.split("H");
					retVal = aTempTimeArray[0];
					sTempVal = aTempTimeArray[1];
					aTempTimeArray = sTempVal.split("M");
					retVal = retVal + ":" + aTempTimeArray[0];
				}
			}
			return retVal;
		},
			formatToInt: function(sInt) {
			if (!sInt) {
				return sInt;
			}
			return parseInt(sInt);
		}

				
	};

});