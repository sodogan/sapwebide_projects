sap.ui.define([
	"zbz_zimmet_onay/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"zbz_zimmet_onay/model/formatter"

], function(BaseController, JSONModel, MessageBox, History, FilterOperator, Filter, formatter) {
	"use strict";

	return BaseController.extend("zbz_zimmet_onay.controller.Main", {
		formatter: formatter,
		onInit: function() {

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				routeLen: 0
			});
			this.getView().setModel(oViewModel, "mainView");

			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("Main").attachMatched(this._onRouteMatched, this);

		},
		_onRouteMatched: function(oEvent) {
			var oView, oArgs;
			oArgs = oEvent.getParameter("arguments");

			this.getView().byId("idIconTabBar").setSelectedKey("Wait");

			/*	var sToday = new Date();
			this.getView().byId("mesaidate").setDateValue(sToday);
			this.getView().byId("mesaiTbdPicker").setDateValue(sToday);
*/
			/*	var username = oArgs.EFullname;
				var zdepartmanx = oArgs.Zdepartmanx;*/
			this.pernr = oArgs.Pernr;
			this._bindTable(oArgs.Pernr);
			//Mesai tablosuna giriş yapılan personel ve sy-datum ile select atar.

			/*	oView = this.getView();*/
			/*	oView.byId("gelyaz").setValue(this.pernr);*/
			/*	oView.byId("departmanid").setText(zdepartmanx);
			 */
		},

		onNavButtonPress: function() {
			var oLoginController = this;
			var oPernrValue = oLoginController.getOwnerComponent()._LoginController.getView().byId("pernr");
			var oPasswordValue = oLoginController.getOwnerComponent()._LoginController.getView().byId("password");
			oPernrValue.setValue("");
			oPasswordValue.setValue("");

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Login");

		},

		saveBtn: function(oEvent) {
			var oOnay = [];
			var sMessage = "";
			var oInputId = oEvent.getSource().getId();
			debugger;
			if (oInputId.indexOf('saveBtnId') > -1) {
				oOnay.Onay = "";
				sMessage = this.getView().getModel("i18n").getResourceBundle().getText("sucsSaveItems");
			} else if (oInputId.indexOf('redBtnId') > -1) {
				oOnay.Onay = "R";
				sMessage = this.getView().getModel("i18n").getResourceBundle().getText("sucsRejectItems");
			}

			var that = this;
			var oTable = this.getView().byId("zimmetTable");
			var aContexts = oTable.getSelectedContexts();
			var sSelectedItems = oTable.getSelectedItems();
			if (sSelectedItems.length === 0) {
				that.showErrorMessage("loginErrorTitle", "noSelectedRows");
				return;
			}
			var oViewModel = this.getView().getModel("mainView");
			oViewModel.setProperty("/busy", true);
			var oObject = "";

			var serviceUrl = that.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources["ZBZ_ZIMMET_ONAY_SRV"].uri;
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			for (var i = 0; i < aContexts.length; ++i) {
				var oArray = [];
				oObject = aContexts[i].getObject();
				oArray.Fisno = oObject.Fisno;
				oArray.Fisklmno = oObject.Fisklmno;
				oArray.Onay = oOnay.Onay;
				oModel.create("/mainSet", oArray, {
					changeSetId: i,
					success: function() {
						that._bindTable();
						oViewModel.setProperty("/busy", false);
						oViewModel.refresh(true);
						that.showMessage(sMessage);
						// that.getView().byId("idIconTabBar").setSelectedKey("Ok");
						// that.handleIconTabBarSelect();
					},
					error: function(oError) {
						var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
						that.showErrorMessage("loginErrorTitle", sErrorMessage);
						oViewModel.setProperty("/busy", false);
						oViewModel.refresh(true);
					}
				});

			}
			oTable.removeSelections(true);

		},

		_bindTable: function() {
			var oTable = this.getView().byId("zimmetTable");
			var oTemplate = oTable.getBindingInfo("items").template;
			oTable.unbindAggregation("items");
			var sOnay = "";
			if (oTable) {
				var oFilter = new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
						new sap.ui.model.Filter("Onay", sap.ui.model.FilterOperator.EQ, sOnay)
					],
					true);
				oTable.bindItems({
					path: "/mainSet",
					template: oTemplate,
					filters: [oFilter]
				});
			}
		},
		handleIconTabBarSelect: function(oEvent) {

			var sKey = oEvent.getParameter("key");
			var oTable = "";
			var oTemplate = "";
			var oFilter = "";
			var oDurum = "";

			var oInputId = oEvent.getSource().getId();
			debugger;
			if (sKey === "Wait") {
				oTable = this.getView().byId("zimmetTable");
				oTemplate = oTable.getBindingInfo("items").template;
				// oTemplate = this.getView().byId("zimmetTable").getBindingInfo("items").template;
				oTable.unbindAggregation("items");
				oDurum = "";
				this.getView().byId("saveBtnId").setEnabled(true);
				this.getView().byId("redBtnId").setEnabled(true);
			} else if (sKey === "Ok") {
				oTable = this.getView().byId("zimmetTable2");
				// oTemplate = oTable.getBindingInfo("items").template;
				oTemplate = this.getView().byId("zimmetTable").getBindingInfo("items").template;
				oTable.unbindAggregation("items");
				this.getView().byId("saveBtnId").setEnabled(false);
				this.getView().byId("redBtnId").setEnabled(false);
				oDurum = "X";
			} else if (sKey === "Red") {
				oTable = this.getView().byId("zimmetTable3");
				// oTemplate = oTable.getBindingInfo("items").template;
				oTemplate = this.getView().byId("zimmetTable").getBindingInfo("items").template;
				oTable.unbindAggregation("items");
				this.getView().byId("saveBtnId").setEnabled(false);
				this.getView().byId("redBtnId").setEnabled(false);
				oDurum = "R";
			}

			if (oTable) {
				oFilter = new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
						new sap.ui.model.Filter("Onay", sap.ui.model.FilterOperator.EQ, oDurum)
					],
					true);
				oTable.bindItems({
					path: "/mainSet",
					template: oTemplate,
					filters: [oFilter]
				});
			}

			// if (sKey === "Ok") {
			// 	this.getView().byId("saveBtnId").setEnabled(false);
			// 	this.getView().byId("redBtnId").setEnabled(false);
			// 	oTable = this.getView().byId("zimmetTable2");
			// 	// oTemplate = oTable.getBindingInfo("items").template;
			// 	oTemplate = this.getView().byId("zimmetTable").getBindingInfo("items").template;
			// 	oTable.unbindAggregation("items");
			// 	if (oTable) {
			// 		oFilter = new sap.ui.model.Filter([
			// 				new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ,this.pernr),
			// 				new sap.ui.model.Filter("Onay", sap.ui.model.FilterOperator.EQ, "X")
			// 			],
			// 			true);
			// 		oTable.bindItems({
			// 			path: "/mainSet",
			// 			template: oTemplate,
			// 			filters: [oFilter]
			// 		});
			// 	}
			// } else if (sKey === "Wait") {
			// 	this.getView().byId("saveBtnId").setEnabled(true);
			// 	this.getView().byId("redBtnId").setEnabled(true);
			// 	oTable = this.getView().byId("zimmetTable");
			// 	oTemplate = oTable.getBindingInfo("items").template;
			// 	oTable.unbindAggregation("items");
			// 	if (oTable) {
			// 		oFilter = new sap.ui.model.Filter([
			// 				new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ,this.pernr),
			// 				new sap.ui.model.Filter("Onay", sap.ui.model.FilterOperator.EQ, "")
			// 			],
			// 			true);
			// 		oTable.bindItems({
			// 			path: "/mainSet",
			// 			template: oTemplate,
			// 			filters: [oFilter]
			// 		});
			// 	}
			// }
			// else if (sKey === "Red") {
			// 	this.getView().byId("saveBtnId").setEnabled(false);
			// 	this.getView().byId("redBtnId").setEnabled(false);
			// 	oTable = this.getView().byId("zimmetTable3");
			// 	oTemplate = this.getView().byId("zimmetTable").getBindingInfo("items").template;
			// 	oTable.unbindAggregation("items");
			// 	if (oTable) {
			// 		oFilter = new sap.ui.model.Filter([
			// 				new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ,this.pernr),
			// 				new sap.ui.model.Filter("Onay", sap.ui.model.FilterOperator.EQ, "R")
			// 			],
			// 			true);
			// 		oTable.bindItems({
			// 			path: "/mainSet",
			// 			template: oTemplate,
			// 			filters: [oFilter]
			// 		});
			// 	}
			// }

		}

	});
});