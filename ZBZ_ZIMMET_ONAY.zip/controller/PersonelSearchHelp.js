sap.ui.define([
	"zbz_zimmet_onay/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController,Filter,FilterOperator) {
	"use strict";

	return BaseController.extend("zbz_zimmet_onay.PersonelSearchHelp", {


		_getDialog: function() {
			if (!this.oPersonelSearchHelp) {
				this.oPersonelSearchHelp = sap.ui.xmlfragment("zbz_zimmet_onay.view.PersonelSearchHelp", this);
			}
			return this.oPersonelSearchHelp;
		},
		open: function(oView,oController,oItemId) {
			var oDialog = this._getDialog();
			this.oView = oView;
			this.oController = oController;
			this.oItemId = oItemId;
			jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), oView, oDialog);
			oController.getView().addDependent(oDialog);
			oDialog.open();
		},
		onClosePersonelDialog: function() {
			this._getDialog().close();
		},
		onDialogAfterClose: function() {
			this.oPersonelSearchHelp.destroy();
			this.oPersonelSearchHelp = undefined;
		},

		onPersonelItemSelect: function(oEvent) {
			var that = this;
			var oItem = oEvent.getSource();
			var oObject = oItem.getBindingContext().getObject();
			oObject.Pernr = that.parseToFloat(oObject.Pernr);

			if (this.oItemId.indexOf('pernr') > -1){
					
			this.oView.byId("pernr").setValue(oObject.Pernr);
			this.oView.byId("pernr").setValueState(sap.ui.core.ValueState.None);
			this._getDialog().close();
			
			}
		
			
		

		},

		onPersonelTableSearch: function(oEvent) {
			debugger;
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
			var	oFilter = new Filter([
						new Filter("Pernr", FilterOperator.EQ,sQuery),
						new Filter("Ename", FilterOperator.Contains,sQuery)
					],
					true);
			}
			var oTable = sap.ui.getCore().byId("personelVHTable");
			oTable.getBinding("items").filter(oFilter, "Application");
			
		}

	});

});