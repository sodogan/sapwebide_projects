sap.ui.define([
	"zbz_zimmet_onay/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, MessageBox) {
	"use strict";

	return BaseController.extend("zbz_zimmet_onay.controller.Login", {

		onInit: function() {

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				routeLen: 0
			});
			this.getView().setModel(oViewModel, "loginView");
			this.getOwnerComponent()._LoginController = this;

		},

		onLoginBtn: function() {

			var that = this;
			var sPernr = this.getView().byId("pernr");
			var sPassword = this.getView().byId("password");
			var sPernrValue = sPernr.getValue();
			var sPasswordValue = sPassword.getValue();
			var sMessageStrip = this.getView().byId("loginWarningMsg");

			if (!sPernrValue) {
				sPernr.setValueState(sap.ui.core.ValueState.Error);
				sMessageStrip.setVisible(true);
			}
			if (!sPasswordValue) {
				sPassword.setValueState(sap.ui.core.ValueState.Error);
				sMessageStrip.setVisible(true);
			}
			if (sPernrValue && sPasswordValue) {

				sPernr.setValueState(sap.ui.core.ValueState.None);
				sPassword.setValueState(sap.ui.core.ValueState.None);
				sMessageStrip.setVisible(false);

				var oViewModel = this.getView().getModel("loginView");
				oViewModel.setProperty("/busy", true);

				var oModel = this.getView().getModel();
				var sPath = "/loginSet(Pernr='" + sPernrValue + "',Password='" + sPasswordValue + "')";

				oModel.read(sPath, {
					success: function(oData) {
						if (oData.EResult === "1") {
							var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
							oData.Pernr = that.parseToFloat(oData.Pernr);
							oRouter.navTo("Main", {
								Pernr: oData.Pernr
							});
							oViewModel.setProperty("/busy", false);
							oViewModel.refresh(true);
						} else if (oData.EResult === "2") {
							that.showErrorMessage("loginErrorTitle", "loginError");
							oViewModel.setProperty("/busy", false);
							oViewModel.refresh(true);
						}
							else if (oData.EResult === "3") {
							that.getOwnerComponent().oNewPassword.open(that.getView(), that,oData);
							oViewModel.setProperty("/busy", false);
							oViewModel.refresh(true);
						}
					},
					error: function(oError) {
						var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
						that.showErrorMessage("loginErrorTitle", sErrorMessage);
						oViewModel.setProperty("/busy", false);
						oViewModel.refresh(true);
					}
				});

			}

		},

		loginLiveChange: function(oEvent) {
			var oInputId = oEvent.getSource().getId();
			var _oInput = oEvent.getSource();

			if (oInputId.indexOf('pernr') > -1) {
				this.getView().byId("pernr").setValueState(sap.ui.core.ValueState.None);
				var val = _oInput.getValue();
				val = val.replace(/[^\d]/g, '');
				_oInput.setValue(val);
			} else if (oInputId.indexOf('password') > -1) {
				this.getView().byId("password").setValueState(sap.ui.core.ValueState.None);
			}

		},
		onPressUserDialog: function(oEvent) {
			var oItem = oEvent.getSource();
			var oItemId = oItem.getId();
			this.getOwnerComponent().oPersonelSearchHelp.open(this.getView(), this, oItemId);
		}

	});
});