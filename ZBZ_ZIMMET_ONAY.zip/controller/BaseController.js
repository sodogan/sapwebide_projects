/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	'sap/m/MessageBox'
], function(Controller, History, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("zbz_zimmet_onay.controller.BaseController", {

		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		showMessage: function(sMessage, aVals) {
			var sTempMessage = this.getResourceBundle().getText(sMessage, aVals);
			MessageToast.show(sTempMessage, {
				closeOnBrowserNavigation: false,
				width: "25em"
			});
		},

		showSuccessMessage: function(pTitle, pMsg) {
			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText(pTitle);
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(pMsg);
			if (!pMBMessage) {
				pMBMessage = pMsg;
			}
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.SUCCESS,
					actions: [sap.m.MessageBox.Action.OK]
				}
			);
		},

		showErrorMessage: function(pTitle, pMsg) {
			var bCompact = this.getOwnerComponent().getContentDensityClass() === "sapUiSizeCompact";
			var pMBTitle = this.getView().getModel("i18n").getResourceBundle().getText(pTitle);
			var pMBMessage = this.getView().getModel("i18n").getResourceBundle().getText(pMsg);
			if (!pMBMessage) {
				pMBMessage = pMsg;
			}
			MessageBox.confirm(
				pMBMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					title: pMBTitle,
					icon: sap.m.MessageBox.Icon.ERROR,
					actions: [sap.m.MessageBox.Action.OK]
				}
			);
		},

		formatDateValue: function(pDate) {
			var oDateFormat = sap.ui.core.format.DateFormat
				.getDateTimeInstance({
					pattern: "yyyy-MM-ddThh:mm:ss"
				});
			pDate = oDateFormat.format(new Date(pDate));
			return pDate;
		},

		formatTimeValue: function(pTime) {
			var oTimeFormat = sap.ui.core.format.DateFormat
				.getTimeInstance({
					pattern: "PTHH:mm:ss"
				});
			var aTempTimeArray = oTimeFormat.format(new Date(pTime)).split(":");
			pTime = aTempTimeArray[0] + "H" + aTempTimeArray[1] + "M" + aTempTimeArray[2] + "S";
			return pTime;
		},

		parseToFloat: function(pValue) {
			return parseFloat(pValue);
		},
			_getSelectedPropFromTable: function(pTable, pProp) {
			var aSelectedContexts = pTable.getSelectedContexts();
			if (aSelectedContexts.length <= 0) {
				return this.showErrorMessage("loginErrorTitle","noSelectedRows" );
			}
			return aSelectedContexts[0].getProperty(pProp);
		},
		
				parseToInt: function(sInt) {
			return parseInt( sInt);

		},
			getModelAndSetHeaders: function(pDataSource) {
			var oModel, sServiceUrl;
			if (pDataSource) {
				sServiceUrl = this.getOwnerComponent().getMetadata().getManifestEntry("sap.app").dataSources[pDataSource].uri;
				oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			} else {
				oModel = this.getView().getModel();
			}
			oModel.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			return oModel;
		}
		
		
	});

});